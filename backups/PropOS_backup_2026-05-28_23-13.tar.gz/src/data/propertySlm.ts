// PropOS Property SLM (Small Language Model / Property Brain)
// 100-data-point structured knowledge store per property
// Property 101: Narre Warren South VIC 3805 | Properties 102+: Berwick VIC 3806

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface PropertyQA {
  question: string
  answer: string
  category: "physical" | "legal" | "financial" | "location" | "features" | "planning"
  keywords: string[]
}

export interface PropertySLM {
  propertyId: number
  address: string
  suburb: string
  status: "active" | "sold"
  soldDate?: string
  soldPrice?: number

  // PHYSICAL (20 fields)
  beds: number | "TBD"
  baths: number | "TBD"
  cars: number | "TBD"
  landSqm: number | "TBD"
  houseSqm: number | "TBD"
  yearBuilt: number | "TBD"
  propertyType: string | "TBD"
  frontageMetre: number | "TBD"
  depthMetre: number | "TBD"
  propertyShape: string | "TBD"
  orientation: string | "TBD"
  pool: boolean | "TBD"
  gardenSqm: number | "TBD"
  shed: boolean | "TBD"
  outdoorEntertaining: boolean | "TBD"
  alfrescoSqm: number | "TBD"
  roofType: string | "TBD"
  externalCladding: string | "TBD"
  construction: string | "TBD"
  floorplanConfig: string | "TBD"

  // LEGAL & TITLE (15 fields)
  titleType: string | "TBD"
  easements: string | "TBD"
  covenants: string | "TBD"
  overlays: string | "TBD"
  s32Status: string | "TBD"
  encumbrances: string | "TBD"
  ownerOccupied: boolean | "TBD"
  zoning: string | "TBD"
  rightOfWay: string | "TBD"
  sewerEasement: string | "TBD"
  contaminatedLand: boolean | "TBD"
  buildingPermitsOutstanding: string | "TBD"
  ownerBuilderWork: boolean | "TBD"
  titlesOfficeReady: boolean | "TBD"
  section32CompletionDate: string | "TBD"

  // FINANCIAL (15 fields)
  priceMin: number | "TBD"
  priceMax: number | "TBD"
  vendorReserve: number | "TBD"
  settlementTermsDays: number | "TBD"
  depositPct: number | "TBD"
  rentalAppraisalLow: number | "TBD"
  rentalAppraisalHigh: number | "TBD"
  grossYieldAtAsk: number | "TBD"
  councilRates: number | "TBD"
  waterRates: number | "TBD"
  bodyCorporateFees: number | "TBD"
  stampDutyEstimate: number | "TBD"
  landTaxThreshold: string | "TBD"
  depreciationYear1Est: number | "TBD"
  capitalGainsHistory: string | "TBD"

  // LOCATION & SUBURB (15 fields)
  primarySchool: string | "TBD"
  primarySchoolRating: string | "TBD"
  secondarySchool: string | "TBD"
  secondarySchoolRating: string | "TBD"
  schoolZoneCatchment: string | "TBD"
  distanceToTrainKm: number | "TBD"
  trainLine: string | "TBD"
  distanceToFreewayKm: number | "TBD"
  distanceToShoppingKm: number | "TBD"
  nearestHospitalKm: number | "TBD"
  suburb5yrGrowthPct: number | "TBD"
  suburbMedianPrice: number | "TBD"
  daysOnMarketAvg: number | "TBD"
  clearanceRatePct: number | "TBD"
  comparableSales: Array<{ address: string; price: number; date: string; beds: number }> | "TBD"

  // FEATURES & CONDITION (15 fields)
  kitchenRenovated: string | "TBD"
  bathroomRenovated: string | "TBD"
  flooringType: string | "TBD"
  airConType: string | "TBD"
  heatingType: string | "TBD"
  solarKw: number | "TBD"
  batteryStorage: boolean | "TBD"
  evCharging: boolean | "TBD"
  nbnType: string | "TBD"
  waterTank: boolean | "TBD"
  alarmSystem: boolean | "TBD"
  smartHome: boolean | "TBD"
  disabilityAccess: boolean | "TBD"
  petsAllowed: boolean | "TBD"
  outdoorFeatures: string | "TBD"

  // PLANNING & VENDOR (20 fields)
  subdivisionPotential: boolean | "TBD"
  dualOccupancyPotential: boolean | "TBD"
  grannyFlatApproved: boolean | "TBD"
  extensionPotential: string | "TBD"
  councilDevelopmentHistory: string | "TBD"
  neighbourhoodDescription: string | "TBD"
  trafficNoiseLevel: string | "TBD"
  flightPathFlag: boolean | "TBD"
  futureInfrastructure: string | "TBD"
  floodZone: boolean | "TBD"
  vendorMotivation: string | "TBD"
  vendorTimelineDays: number | "TBD"
  previousOffers: boolean | "TBD"
  daysOnMarket: number | "TBD"
  priceReductionHistory: string | "TBD"
  tenantInPlace: boolean | "TBD"
  tenantLeaseEndDate: string | "TBD"
  vendorPreferredSettlement: string | "TBD"
  vendorFlexOnInclusions: string | "TBD"
  inclusions: string | "TBD"

  // Q&A (25+ entries per property)
  qa: PropertyQA[]
}

// ---------------------------------------------------------------------------
// SLM Data
// ---------------------------------------------------------------------------

export const SLM_DATA: Record<number, PropertySLM> = {

  // -------------------------------------------------------------------------
  // 101 — 48 President Road, Narre Warren South (ACTIVE LISTING — $780K–$850K, auction 7 Jun 2026)
  // SLM data: Extracted from Section 32 / COS (Ideal Conveyancing, 06/05/2026)
  // Title: Vol 10427 Folio 211 | Lot 598 PS416514Y | Springfield Stage 21
  // -------------------------------------------------------------------------
  101: {
    propertyId: 101,
    address: "48 President Road",
    suburb: "Narre Warren South VIC 3805",
    status: "active",

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 630,
    houseSqm: 210,
    yearBuilt: 2007,
    propertyType: "House",
    frontageMetre: 17.96,
    depthMetre: 35.06,
    propertyShape: "Rectangular",
    orientation: "South",
    pool: false,
    gardenSqm: 200,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 22,
    roofType: "Colorbond",
    externalCladding: "Brick veneer",
    construction: "Brick veneer — standard construction for Springfield Stage 21 (est. 2007). S173 covenant V896188Q requires all dwellings to comply with the neighbourhood design plan.",
    floorplanConfig: "4 bed, 2 bath, double garage",

    // LEGAL & TITLE
    titleType: "Torrens — Vol 10427 Folio 211 (Lot 598 PS416514Y)",
    easements: "E-3 drainage and sewerage easement — in favour of Casey City Council and South East Water Ltd (per PS416514Y Sheet 6)",
    covenants: "Section 173 Agreement V896188Q (16/02/1999, Berwick Planning Scheme): development must comply with Springfield Stage 21 neighbourhood design plan; maximum one dwelling per lot; minimum 3 off-street car spaces (at least 1 covered). Covenants run with the land.",
    overlays: "None",
    s32Status: "Signed — vendor Laura Ah Choy, dated 08/05/2026. Prepared by Ideal Conveyancing (ref RC:LL:26/13932).",
    encumbrances: "Section 173 Planning Agreement V896188Q (16/02/1999, Casey City Council / Avjennings Holdings Ltd)",
    ownerOccupied: true,
    zoning: "GRZ1 — General Residential Zone Schedule 1 (Casey Planning Scheme)",
    rightOfWay: "None",
    sewerEasement: "Yes — E-3 drainage and sewerage easement on title (Casey City Council / South East Water Ltd)",
    contaminatedLand: false,
    buildingPermitsOutstanding: "No building permits issued in preceding 7 years (vendor's knowledge as at 08/05/2026)",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "08/05/2026",

    // FINANCIAL
    priceMin: 780000,
    priceMax: 850000,
    vendorReserve: 815000,
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 430,
    rentalAppraisalHigh: 470,
    grossYieldAtAsk: 2.7,
    councilRates: 1950,
    waterRates: 910,
    bodyCorporateFees: 0,
    stampDutyEstimate: 44070,
    landTaxThreshold: "Vendor exempt as PPOR at time of sale. Purchaser liability depends on intended use — investor purchasers will be assessed under the Land Tax Act 2005 (Vic) from settlement date.",
    depreciationYear1Est: 7200,
    capitalGainsHistory: "Vendor (Laura Ah Choy) purchased 04/12/2007. If selling at $815K guide midpoint, estimated capital gain approx $250K–$280K over 18.5 years — partial CGT discount applies (PPOR exemption likely; confirm with vendor's accountant).",

    // LOCATION & SUBURB
    primarySchool: "Strathaird Primary School (357m)",
    primarySchoolRating: "Good (NAPLAN above state average in reading & numeracy, 2025)",
    secondarySchool: "Narre Warren South P-12 College (1016m)",
    secondarySchoolRating: "Average — large campus P-12 school. Many families opt for private secondary (Haileybury 6.5km, Nossal HS selective entry 8km).",
    schoolZoneCatchment: "Strathaird Primary School and Narre Warren South P-12 College (confirm with Casey Council)",
    distanceToTrainKm: 4.8,
    trainLine: "Pakenham Line — Narre Warren Station (4.8km); Berwick Station (5.2km). Both ~30 min to Flinders Street.",
    distanceToFreewayKm: 1.6,
    distanceToShoppingKm: 3.9,
    nearestHospitalKm: 5.8,
    suburb5yrGrowthPct: 26,
    suburbMedianPrice: 855000,
    daysOnMarketAvg: 31,
    clearanceRatePct: 67,
    comparableSales: [
      { address: "52 President Road, Narre Warren South", price: 835000, date: "Mar 2026", beds: 4 },
      { address: "11 Kershaw Drive, Narre Warren South",  price: 797000, date: "Jan 2026", beds: 4 },
      { address: "38 Outlook Drive, Narre Warren South",  price: 862000, date: "Apr 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Original 2007 kitchen — functional, not recently renovated. Stone-look benchtops, stainless appliances (dishwasher included per inclusions).",
    bathroomRenovated: "Original 2007 bathrooms — tiled, full ensuite to master, main bathroom with bath and shower.",
    flooringType: "Carpet to bedrooms; tiles to living, kitchen, and wet areas (per vendor).",
    airConType: "Ducted reverse cycle cooling — zoned (per property description)",
    heatingType: "Ducted gas heating — zoned (per property description)",
    solarKw: 0,
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTP (Fibre to the Premises) — confirmed for Springfield Estate, NW South precinct",
    waterTank: false,
    alarmSystem: false,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Alfresco entertaining area approx 22m². Low-maintenance rear garden, lawn area ~200m². No pool or spa.",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Yes — GRZ1 allows extensions subject to council permit and S173 neighbourhood design plan setbacks",
    councilDevelopmentHistory: "No building permits recorded in preceding 7 years (vendor statement, 08/05/2026)",
    neighbourhoodDescription: "Springfield Estate Stage 21 — established family precinct on President Road, Narre Warren South. South-facing 630m² rectangular lot with 18m frontage. Strathaird Primary School 357m walk. Fountain Gate Westfield 3.9km. Casey Hospital 5.8km. Narre Warren Station 4.8km (Pakenham Line). Quiet residential street, low traffic, all owner-occupied homes throughout estate.",
    trafficNoiseLevel: "Low — residential estate, President Road is a local street",
    flightPathFlag: false,
    futureInfrastructure: "Casey growth corridor — active development contributions plans in surrounding areas (Lyndhurst DCP and Cranbourne East LSP, per Casey Planning Scheme amendments C303case/C302case 2026). No road or infrastructure works directly impacting this property identified in vendor statement or planning certificate.",
    floodZone: false,
    vendorMotivation: "Owner Laura Ah Choy — family home owned since 2007, upsizing. Motivated to sell prior to auction. Vendor cooperative and responsive per Cameron's notes.",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 14,
    priceReductionHistory: "No reductions — fresh to market, listed May 2026",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement",
    vendorPreferredSettlement: "Flexible (confirmed in contract particulars)",
    vendorFlexOnInclusions: "Standard inclusions only — all fixed floor coverings, light fittings, window furnishings and permanent fixtures as inspected",
    inclusions: "All fixed floor coverings, light fittings, window furnishings, dishwasher, and all fixtures and fittings of a permanent nature as inspected",

    qa: [
      {
        question: "How big is the land?",
        answer: "630 square metres — rectangular block, 17.96m frontage by 35.06m deep. Confirmed from Plan of Subdivision PS416514Y.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "frontage", "depth"],
      },
      {
        question: "How many bedrooms?",
        answer: "4 bedrooms, 2 bathrooms, double garage. Exact floorplan configuration to be confirmed on inspection.",
        category: "physical",
        keywords: ["bed", "bedroom", "rooms", "layout", "floorplan"],
      },
      {
        question: "What direction does the property face?",
        answer: "South-facing — confirmed from the planning certificate (orientation: South). Consider this for natural light and garden planning.",
        category: "physical",
        keywords: ["orientation", "facing", "north", "south", "light", "aspect"],
      },
      {
        question: "What school zone is this in?",
        answer: "Strathaird Primary School (357m away) and Narre Warren South P-12 College (1016m). Confirm exact catchment with Casey Council on 03 9705 5190.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "strathaird"],
      },
      {
        question: "Are there any easements or covenants on the title?",
        answer: "Yes — two items. First, an E-3 drainage and sewerage easement in favour of Casey City Council and South East Water. Second, a Section 173 Planning Agreement (V896188Q) binding all lots in Springfield Stage 21: one dwelling per lot maximum, minimum 3 off-street parking spaces (1 covered), and development must follow the neighbourhood design plan. These run with the land permanently.",
        category: "legal",
        keywords: ["easement", "covenant", "s173", "restriction", "title", "encumbrance", "sewer", "drainage"],
      },
      {
        question: "What is the zoning?",
        answer: "GRZ1 — General Residential Zone Schedule 1 under the Casey Planning Scheme. No planning overlays apply. The zone supports single dwellings, extensions, and a limited range of community uses. Note: the S173 covenant restricts to one dwelling per lot.",
        category: "planning",
        keywords: ["zone", "zoning", "grz", "residential", "planning", "overlay", "development"],
      },
      {
        question: "Is the Section 32 ready?",
        answer: "Yes — vendor statement signed by Laura Ah Choy on 08/05/2026. Prepared by Ideal Conveyancing (ref RC:LL:26/13932). Title is clean, no charges, no owners corporation, no GAIC, no bushfire overlay. GST withholding not required.",
        category: "legal",
        keywords: ["s32", "section 32", "contract", "vendor statement", "ready", "signed"],
      },
      {
        question: "What are the council rates?",
        answer: "Casey City Council rates plus South East Water charges combined do not exceed $4,500 per annum (per vendor statement). Individual amounts to be confirmed from rate notices.",
        category: "financial",
        keywords: ["council", "rates", "annual", "fees", "outgoings", "water", "casey"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "Approximately $430–$470 per week based on comparable 4-bedroom rentals in Narre Warren South. At the $815K guide midpoint, that's a gross yield of around 2.7%. Strong rental demand from families — Strathaird Primary and NWS P-12 College are a drawcard.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "Can this property be subdivided?",
        answer: "No — the Section 173 Agreement (V896188Q) restricts the lot to one dwelling only. At 630m², the block is also below the minimum size typically required for subdivision in GRZ1. No subdivision potential.",
        category: "planning",
        keywords: ["subdivide", "subdivision", "dual occupancy", "split", "develop", "potential"],
      },
      {
        question: "What services are connected?",
        answer: "All services connected — electricity, gas, water, sewerage, and telephone (confirmed in vendor statement). NBN type to be confirmed.",
        category: "features",
        keywords: ["services", "utilities", "electricity", "gas", "water", "sewer", "nbn", "internet"],
      },
      {
        question: "Is the property in a bushfire prone area?",
        answer: "No — confirmed in the vendor statement. Not in a designated bushfire prone area under section 192A of the Building Act 1993.",
        category: "planning",
        keywords: ["bushfire", "fire", "prone", "bap", "risk", "overlay"],
      },
      {
        question: "What is the suburb like?",
        answer: "Springfield Estate in Narre Warren South — established family-oriented precinct on a quiet residential street. Owner-occupied homes throughout. Strathaird Primary School is a 357m walk. Adjacent to roundabout at Kershaw Drive. Distances to Fountain Gate Westfield and Casey Hospital TBD — confirm locally.",
        category: "location",
        keywords: ["suburb", "area", "neighbourhood", "narre warren", "community", "springfield", "estate"],
      },
      {
        question: "What is the stamp duty on this property?",
        answer: "Approximately $52,800 at standard Victorian transfer duty rates for a $962,000 purchase (non-PPOR, non-FHB). First home buyers and owner-occupiers may be eligible for significant concessions — confirm with a conveyancer.",
        category: "financial",
        keywords: ["stamp duty", "transfer duty", "tax", "purchase costs", "fhb", "concession"],
      },
      {
        question: "Can I build a granny flat or second dwelling?",
        answer: "No — Section 173 Agreement V896188Q clause 1.3 is an absolute restriction: no more than one dwelling house may be erected on this lot. This covenant runs with the land permanently and cannot be removed without a Planning Scheme amendment. Dual occupancy and dependent person's units are also not permitted.",
        category: "planning",
        keywords: ["granny flat", "second dwelling", "dpu", "dependent person", "dual occ", "extra dwelling"],
      },
      {
        question: "How long has the vendor owned the property?",
        answer: "Laura Ah Choy has been registered as proprietor since 04/12/2007 (per Register Search Statement, Vol 10427 Folio 211). Approximately 18.5 years of ownership at time of sale in April 2026.",
        category: "legal",
        keywords: ["vendor", "owner", "how long", "ownership", "history", "title"],
      },
      {
        question: "What is the crime rate in this area?",
        answer: "Below average — the 3805 postcode records 1 burglary per 110 homes, compared to the Victorian state average of 1 in 76 homes and Casey council average of 1 in 82 homes (source: Ideal Conveyancing Property Report, 06/05/2026).",
        category: "location",
        keywords: ["crime", "safety", "burglary", "security", "postcode", "statistics"],
      },
      {
        question: "What is the council property number?",
        answer: "Casey Council property number 69788 (per planning certificate, 06/05/2026). Casey Council contact: 03 9705 5190 / caseycc@casey.vic.gov.au / casey.vic.gov.au",
        category: "legal",
        keywords: ["council", "property number", "reference", "casey", "contact"],
      },
      {
        question: "How far is the train station?",
        answer: "Narre Warren Station is approximately 4.8km away — about 8 minutes by car. It's on the Pakenham Line, roughly 30 minutes to Flinders Street. Berwick Station is slightly further at 5.2km.",
        category: "location",
        keywords: ["train", "station", "public transport", "narre warren", "pakenham", "commute", "distance"],
      },
      {
        question: "What are the comparable sales in the area?",
        answer: "Recent 4-bedroom sales in Narre Warren South: 52 President Road sold $835,000 (Mar 2026), 11 Kershaw Drive sold $797,000 (Jan 2026), 38 Outlook Drive sold $862,000 (Apr 2026). These support the $780K–$850K price guide.",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold", "market", "price", "similar"],
      },
      {
        question: "Does the property have heating and cooling?",
        answer: "Yes — ducted gas heating and ducted reverse cycle cooling throughout. Both systems are zoned. All fixed floor coverings and window furnishings are included in the sale.",
        category: "features",
        keywords: ["heating", "cooling", "air con", "ducted", "climate", "hvac"],
      },
      {
        question: "What outdoor entertaining is there?",
        answer: "Alfresco entertaining area of approximately 22m² — covered and accessible from the living area. Low-maintenance rear garden with lawn of around 200m². No pool.",
        category: "features",
        keywords: ["outdoor", "alfresco", "entertaining", "garden", "backyard", "pool", "pergola"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 102 — 3 Thirlmere Court, Berwick (SOLD $941K, 02 May 2026)
  // -------------------------------------------------------------------------
  102: {
    propertyId: 102,
    address: "3 Thirlmere Court",
    suburb: "Berwick VIC 3806",
    status: "sold",
    soldDate: "02 May 2026",
    soldPrice: 941000,

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 612,
    houseSqm: 240,
    yearBuilt: 2008,
    propertyType: "House",
    frontageMetre: 17,
    depthMetre: 36,
    propertyShape: "Rectangular",
    orientation: "North-facing living",
    pool: false,
    gardenSqm: 220,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 18,
    roofType: "Colorbond",
    externalCladding: "Brick veneer",
    construction: "Brick veneer with feature render panel",
    floorplanConfig: "4 bed, 2 bath, open plan living, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "No easements on title",
    covenants: "Estate covenant: no caravan or commercial vehicles in driveway",
    overlays: "No planning overlays",
    s32Status: "Section 32 issued",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "Neighbourhood Residential Zone (NRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "April 2026",

    // FINANCIAL
    priceMin: 941000,
    priceMax: 941000,
    vendorReserve: "TBD",
    settlementTermsDays: 45,
    depositPct: 10,
    rentalAppraisalLow: 500,
    rentalAppraisalHigh: 540,
    grossYieldAtAsk: 2.97,
    councilRates: 1850,
    waterRates: 900,
    bodyCorporateFees: 0,
    stampDutyEstimate: 51330,
    landTaxThreshold: "Above threshold for single investment property, land tax applies",
    depreciationYear1Est: 8500,
    capitalGainsHistory: "TBD",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School",
    primarySchoolRating: "Above average (MySchool rating 7/10)",
    secondarySchool: "Berwick Secondary College",
    secondarySchoolRating: "7.5/10 (MySchool)",
    schoolZoneCatchment: "Berwick Primary School, Berwick Secondary College",
    distanceToTrainKm: 0.8,
    trainLine: "Pakenham Line, Berwick Station",
    distanceToFreewayKm: 3.5,
    distanceToShoppingKm: 1.8,
    nearestHospitalKm: 4.2,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "7 Thirlmere Court, Berwick", price: 910000, date: "Feb 2026", beds: 4 },
      { address: "14 Clive Court, Berwick", price: 955000, date: "Mar 2026", beds: 4 },
      { address: "22 Fairway Drive, Berwick", price: 890000, date: "Jan 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Updated 2020, stone benchtops, stainless steel appliances, breakfast bar",
    bathroomRenovated: "Main bathroom updated 2020, ensuite original 2008",
    flooringType: "Hybrid timber look flooring in living areas, carpet in bedrooms",
    airConType: "Ducted evaporative cooling",
    heatingType: "Ducted gas heating",
    solarKw: 3.5,
    batteryStorage: false,
    evCharging: false,
    nbnType: "NBN FTTN (Fibre to the Node)",
    waterTank: false,
    alarmSystem: true,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Covered alfresco 18sqm, lawn area, garden beds",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Potential to extend to rear and add pergola within existing setbacks",
    councilDevelopmentHistory: "Kitchen reno 2020, no building permits outstanding",
    neighbourhoodDescription: "Quiet court position, family neighbourhood close to Berwick village and train station",
    trafficNoiseLevel: "Low, court position",
    flightPathFlag: false,
    futureInfrastructure: "Berwick Station precinct upgrade in planning",
    floodZone: false,
    vendorMotivation: "Downsizing, children have left home",
    vendorTimelineDays: 45,
    previousOffers: false,
    daysOnMarket: 18,
    priceReductionHistory: "No price reduction",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A",
    vendorPreferredSettlement: "45 days preferred",
    vendorFlexOnInclusions: "All kitchen appliances and window coverings included",
    inclusions: "Dishwasher, rangehood, oven, all window coverings, alarm system",

    qa: [
      {
        question: "What is the land size?",
        answer: "612 square metres, a well-proportioned suburban block in a court position.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square"],
      },
      {
        question: "How large is the home?",
        answer: "Approximately 240 square metres of living space across 4 bedrooms and open-plan living.",
        category: "physical",
        keywords: ["house", "size", "area", "internal", "sqm", "living"],
      },
      {
        question: "When was it built?",
        answer: "Built in 2008 with kitchen and main bathroom updated in 2020.",
        category: "physical",
        keywords: ["built", "year", "age", "when", "old", "construction"],
      },
      {
        question: "Is there outdoor entertaining?",
        answer: "Yes. A covered alfresco of 18 square metres opens to a lawn area with garden beds.",
        category: "physical",
        keywords: ["outdoor", "alfresco", "entertaining", "pergola", "deck", "garden"],
      },
      {
        question: "What is the orientation?",
        answer: "The living areas face north, providing good natural light through winter.",
        category: "physical",
        keywords: ["orientation", "north", "north-facing", "sun", "aspect", "light"],
      },
      {
        question: "Are there any easements?",
        answer: "No easements on title.",
        category: "legal",
        keywords: ["easement", "easements", "restriction", "title"],
      },
      {
        question: "Are there any covenants?",
        answer: "Yes, an estate covenant restricting caravans and commercial vehicles in the driveway.",
        category: "legal",
        keywords: ["covenant", "covenants", "restriction", "estate", "rules"],
      },
      {
        question: "What is the zoning?",
        answer: "Neighbourhood Residential Zone NRZ1.",
        category: "legal",
        keywords: ["zone", "zoning", "planning", "nrz", "residential"],
      },
      {
        question: "What are the council rates?",
        answer: "Approximately $1,850 per year with Casey Council.",
        category: "financial",
        keywords: ["council", "rates", "annual", "per year", "fees"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "A 4-bedroom home in this location would rent for approximately $500 to $540 per week.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "What gross yield does this represent?",
        answer: "At the sold price of $941K and mid-rental of $520 per week, the gross yield is approximately 2.97%.",
        category: "financial",
        keywords: ["yield", "gross", "return", "investment return"],
      },
      {
        question: "What stamp duty would apply?",
        answer: "Stamp duty for a principal place of residence purchase at $941K in Victoria is approximately $51,330.",
        category: "financial",
        keywords: ["stamp duty", "duty", "transfer", "government", "cost"],
      },
      {
        question: "What school zone is this property in?",
        answer: "Zoned for Berwick Primary School and Berwick Secondary College.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "berwick"],
      },
      {
        question: "How far to the train station?",
        answer: "Berwick Station on the Pakenham Line is approximately 800 metres, an easy walk.",
        category: "location",
        keywords: ["train", "station", "walk", "commute", "transport", "pakenham", "distance"],
      },
      {
        question: "How far to shopping?",
        answer: "Eden Rise shopping centre with Coles and specialty stores is about 1.8km away. Fountain Gate Westfield is about 8km.",
        category: "location",
        keywords: ["shopping", "shops", "centre", "coles", "supermarket", "eden rise", "westfield"],
      },
      {
        question: "How far is Casey Hospital?",
        answer: "Casey Hospital in Berwick is approximately 4.2km from the property.",
        category: "location",
        keywords: ["hospital", "casey", "medical", "health", "emergency"],
      },
      {
        question: "What is the suburb growth history?",
        answer: "Berwick has delivered approximately 28% median price growth over the past 5 years.",
        category: "location",
        keywords: ["growth", "capital", "appreciation", "suburb", "5 year", "market"],
      },
      {
        question: "Has the kitchen been renovated?",
        answer: "Yes, updated in 2020 with stone benchtops, stainless steel appliances, and a breakfast bar.",
        category: "features",
        keywords: ["kitchen", "bench", "appliance", "renovated", "stone", "updated"],
      },
      {
        question: "What type of air conditioning is installed?",
        answer: "Ducted evaporative cooling throughout with ducted gas heating.",
        category: "features",
        keywords: ["air con", "ducted", "cooling", "heating", "evaporative", "climate"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes. A 3.5kW solar system is installed.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "power", "kw"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No. NRZ1 zoning and the 612sqm lot size do not meet subdivision minimums.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split"],
      },
      {
        question: "What inclusions are provided?",
        answer: "Dishwasher, rangehood, oven, all window coverings, and the alarm system are included.",
        category: "legal",
        keywords: ["inclusions", "included", "dishwasher", "blind", "curtain", "alarm"],
      },
      {
        question: "Why is the vendor selling?",
        answer: "The vendor is downsizing as their children have moved out.",
        category: "planning",
        keywords: ["vendor", "motivation", "why selling", "motivated", "downsizing", "reason"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 103 — 5 Ascot Rise, Berwick (SOLD $1,265,000, 03 Jul 2023) — confirmed
  // -------------------------------------------------------------------------
  103: {
    propertyId: 103,
    address: "5 Ascot Rise",
    suburb: "Berwick VIC 3806",
    status: "sold",
    soldDate: "03 Jul 2023",
    soldPrice: 1265000,

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 754,
    houseSqm: 310,
    yearBuilt: 2001,
    propertyType: "House",
    frontageMetre: 20,
    depthMetre: 37,
    propertyShape: "Rectangular",
    orientation: "North-facing rear garden",
    pool: false,
    gardenSqm: 300,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 35,
    roofType: "Concrete tile",
    externalCladding: "Double brick",
    construction: "Double brick prestige build",
    floorplanConfig: "4 bed, 2 bath, master ensuite, theatre room, formal lounge, alfresco, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "No easements",
    covenants: "Berwick Grammar proximity covenant: no commercial use",
    overlays: "No planning overlays",
    s32Status: "Section 32 issued",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "Neighbourhood Residential Zone (NRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "March 2026",

    // FINANCIAL
    priceMin: 1265000,
    priceMax: 1265000,
    vendorReserve: "TBD",
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 580,
    rentalAppraisalHigh: 640,
    grossYieldAtAsk: 2.51,
    councilRates: 2050,
    waterRates: 920,
    bodyCorporateFees: 0,
    stampDutyEstimate: 69575,
    landTaxThreshold: "Above threshold, land tax applies for investors",
    depreciationYear1Est: 11500,
    capitalGainsHistory: "TBD",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School",
    primarySchoolRating: "Above average (MySchool rating 7/10)",
    secondarySchool: "Berwick Secondary College",
    secondarySchoolRating: "7.5/10 (MySchool)",
    schoolZoneCatchment: "Berwick Primary School, Berwick Secondary College. Walking distance to Berwick Grammar (independent).",
    distanceToTrainKm: 0.9,
    trainLine: "Pakenham Line, Berwick Station",
    distanceToFreewayKm: 3.8,
    distanceToShoppingKm: 1.5,
    nearestHospitalKm: 4.0,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "12 Ascot Rise, Berwick", price: 1270000, date: "Jan 2026", beds: 4 },
      { address: "8 Grand Arch Way, Berwick", price: 1310000, date: "Feb 2026", beds: 4 },
      { address: "3 Brookfield Drive, Berwick", price: 1250000, date: "Dec 2025", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Fully renovated 2019, 40mm stone benchtops, Bosch appliances, butler's pantry",
    bathroomRenovated: "Master ensuite renovated 2019, main bathroom updated 2021",
    flooringType: "Solid timber floors in living areas, carpet in bedrooms",
    airConType: "Ducted refrigerated cooling (Daikin)",
    heatingType: "Ducted gas heating",
    solarKw: 5.0,
    batteryStorage: false,
    evCharging: false,
    nbnType: "NBN FTTP (Fibre to the Premises)",
    waterTank: true,
    alarmSystem: true,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Alfresco 35sqm with outdoor kitchen, manicured rear garden, room for pool addition",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Room to add pool and extend alfresco; rear garden 300sqm provides space",
    councilDevelopmentHistory: "Kitchen and ensuite reno permits 2019, no outstanding permits",
    neighbourhoodDescription: "Prestigious Ascot Rise address walking distance to Berwick Grammar, Berwick Village, and Berwick Station. Tree-lined street, elevated position with park views.",
    trafficNoiseLevel: "Low, residential street with good setback from Clyde Road",
    flightPathFlag: false,
    futureInfrastructure: "Berwick Station precinct upgrade in planning; potential high-speed rail future corridor nearby",
    floodZone: false,
    vendorMotivation: "Relocating to Queensland",
    vendorTimelineDays: 60,
    previousOffers: true,
    daysOnMarket: 24,
    priceReductionHistory: "No price reduction, sold at auction above reserve",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A",
    vendorPreferredSettlement: "60 days",
    vendorFlexOnInclusions: "Outdoor kitchen negotiable, all internal inclusions included",
    inclusions: "All light fittings, window coverings, dishwasher, outdoor kitchen, water tank, alarm system",

    qa: [
      {
        question: "What is the land size?",
        answer: "754 square metres, a generous block within walking distance of Berwick Grammar.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square"],
      },
      {
        question: "What is the house size?",
        answer: "Approximately 310 square metres including 4 bedrooms, theatre room, formal lounge, and alfresco.",
        category: "physical",
        keywords: ["house", "size", "area", "internal", "sqm", "living", "floor"],
      },
      {
        question: "What is the construction quality?",
        answer: "Double brick prestige construction built in 2001, known for solid build quality and good thermal mass.",
        category: "physical",
        keywords: ["construction", "brick", "double brick", "quality", "build", "materials"],
      },
      {
        question: "Is there outdoor entertaining?",
        answer: "Yes. A 35 square metre alfresco with an outdoor kitchen, opening to a manicured rear garden.",
        category: "physical",
        keywords: ["outdoor", "alfresco", "entertaining", "deck", "kitchen", "garden"],
      },
      {
        question: "Is there a theatre room?",
        answer: "Yes. A dedicated theatre room is part of the floorplan.",
        category: "physical",
        keywords: ["theatre", "media", "room", "cinema", "entertainment", "floorplan"],
      },
      {
        question: "What are the easements and covenants?",
        answer: "No easements on title. There is a covenant restricting commercial use, common in the Berwick Grammar precinct.",
        category: "legal",
        keywords: ["easement", "covenant", "restriction", "title", "legal"],
      },
      {
        question: "Is the Section 32 ready?",
        answer: "Yes. Section 32 was issued in March 2026.",
        category: "legal",
        keywords: ["s32", "section 32", "contract", "vendor statement", "ready"],
      },
      {
        question: "What are the council rates?",
        answer: "Approximately $2,050 per year with Casey Council.",
        category: "financial",
        keywords: ["council", "rates", "annual", "per year", "fees"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "A prestige 4-bedroom near Berwick Grammar would rent for approximately $580 to $640 per week.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "What school zone does this fall in?",
        answer: "Zoned for Berwick Primary School and Berwick Secondary College. It is also walking distance to Berwick Grammar (independent school).",
        category: "location",
        keywords: ["school", "zone", "catchment", "grammar", "berwick", "primary", "secondary"],
      },
      {
        question: "How far is the train station?",
        answer: "Berwick Station on the Pakenham Line is approximately 900 metres away.",
        category: "location",
        keywords: ["train", "station", "commute", "walk", "transport", "pakenham"],
      },
      {
        question: "Has the kitchen been renovated?",
        answer: "Yes. Full renovation in 2019 with 40mm stone benchtops, Bosch appliances, and a butler's pantry.",
        category: "features",
        keywords: ["kitchen", "bench", "appliance", "renovated", "stone", "butler", "pantry"],
      },
      {
        question: "What is the NBN connection type?",
        answer: "NBN FTTP (Fibre to the Premises), the fastest connection type.",
        category: "features",
        keywords: ["nbn", "internet", "fibre", "broadband", "fttp", "connection"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes. A 5kW solar system is installed.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "power", "kw"],
      },
      {
        question: "Is there pool potential?",
        answer: "Yes. The 300sqm rear garden has room for a pool subject to council approval under NRZ1.",
        category: "planning",
        keywords: ["pool", "swimming", "spa", "potential", "add", "garden"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No. NRZ1 zoning restricts subdivision on a 740sqm lot in this precinct.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split"],
      },
      {
        question: "What is the neighbourhood like?",
        answer: "Prestigious Ascot Rise address. Tree-lined street, elevated position with park views, walking distance to Berwick Village and Berwick Grammar.",
        category: "planning",
        keywords: ["neighbourhood", "street", "area", "suburb", "community", "prestige"],
      },
      {
        question: "What is the suburb 5-year growth?",
        answer: "Berwick has delivered approximately 28% median price growth over the past 5 years.",
        category: "location",
        keywords: ["growth", "capital", "appreciation", "suburb", "5 year", "market"],
      },
      {
        question: "What inclusions are provided?",
        answer: "All light fittings, window coverings, dishwasher, outdoor kitchen (negotiable), water tank, and alarm system.",
        category: "legal",
        keywords: ["inclusions", "included", "dishwasher", "blind", "alarm", "outdoor kitchen"],
      },
      {
        question: "Why is the vendor selling?",
        answer: "The vendor is relocating to Queensland.",
        category: "planning",
        keywords: ["vendor", "motivation", "why selling", "motivated", "reason", "relocating"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 104 — 3 Yemaya Place, Berwick (SOLD $1,100,000, 11 May 2026)
  // SLM data: Extracted from Section 32/COS (John Conquest Lawyers, 04/05/2026)
  // Title: Vol 10933 Folio 708 | Lot 14 PS537252C | Casey Council prop no. 95724
  // Restrictive covenant AE322439C | ME Bank mortgage AU406181L to discharge
  // -------------------------------------------------------------------------
  104: {
    propertyId: 104,
    address: "3 Yemaya Place",
    suburb: "Berwick VIC 3806",
    status: "sold",
    soldDate: "11 May 2026",
    soldPrice: 1100000,

    // PHYSICAL
    beds: "TBD",
    baths: "TBD",
    cars: "TBD",
    landSqm: 806,
    houseSqm: "TBD",
    yearBuilt: "TBD",
    propertyType: "House",
    frontageMetre: "TBD",
    depthMetre: "TBD",
    propertyShape: "Irregular — trapezoidal cul-de-sac position with curved frontage (end of Yemaya Place)",
    orientation: "South — frontage faces south toward Yemaya Place (confirmed from planning certificate lot map and SEW asset plans, April 2026)",
    pool: "TBD",
    gardenSqm: "TBD",
    shed: "TBD",
    outdoorEntertaining: "TBD",
    alfrescoSqm: "TBD",
    roofType: "TBD",
    externalCladding: "TBD",
    construction: "TBD",
    floorplanConfig: "TBD",

    // LEGAL & TITLE
    titleType: "Torrens — Vol 10933 Folio 708 (Lot 14 PS537252C)",
    easements: "E-1 Crown Grant reservation V8876 F474 (4.02m wide, drainage and other purposes — in favour of Casey City Council and South East Water Ltd) and E-2 Drainage and Sewerage easement (origin PS537252C, width 'see diagram' — in favour of Casey City Council and South East Water Ltd). SEW Sewer & Drainage asset plan (case 51958648, 21 April 2026) shows the 150 UPVC sewer main runs along Yemaya Place (the road), not through Lot 14 itself. Depth limitation: 15.24m below surface applies to ALL land in PS537252C — restricts deep excavation and underground works across the entire subdivision. Confirm exact E-2 boundary position on Lot 14 with a licensed surveyor before any underground construction works.",
    covenants: "Restrictive Covenant AE322439C (registered 01/05/2006 — Transfer of Land, Arleon Holdings Pty Ltd to Christopher Yue; applies to all lots in PS537252C, PS537253A and PS537251E): single dwelling only per lot; minimum floor area 160sqm (excluding garage, carport, terrace, pergola, verandah); external walls brick, brick veneer, concrete, stone, glass or timber (timber max 30%, all materials new); roof concrete or terracotta tiles, slate, or non-reflective Colourbond at minimum 22-degree pitch; garage or covered carport for minimum 1 vehicle using same materials, built simultaneously with dwelling; no fences within 5m of front boundary unless max 1m height; side and rear fences 1.8m-2.0m; driveway installed at Certificate of Occupancy (concrete, bitumen or pavers); no boats, caravans, trailers or vehicles 1 tonne or more stored forward of building line outside business hours; front landscaping within 6 months of occupation. Covenant runs with land permanently.",
    overlays: "None — confirmed from Planning Certificate (Ref 1247581, 21 April 2026, Minister for Planning Sonya Kilkenny). Casey Planning Scheme GRZ1 only, no additional overlays.",
    s32Status: "Signed (e-signed) — vendor Christopher Yue, 04/05/2026 at 9:35 AM GMT. Vendor Statement AMENDED 04.05.2026. Prepared by John Conquest Lawyers (ref SB:YUE). Executed via Adobe Acrobat Sign (Transaction ID: CBJCHBCAABAAU0Q8EZh838obCgFZRiDjaIPZkt0btyea). No owners corporation. Not bushfire prone. No building permits outstanding. All services connected. GAIC: not applicable — Berwick is an established suburb; no GAIC disclosure in Vendor Statement. ME Bank mortgage AU406181L must be discharged at settlement.",
    encumbrances: "1. Mortgage AU406181L (01/06/2021) — Members Equity Bank Ltd (ME Bank, ACN 070887679) — must be formally discharged at or before settlement; eCT currently held by Galilee Solicitors Pty Ltd (ref 20486E). 2. Restrictive Covenant AE322439C (01/05/2006) — runs with land permanently; see covenants field for full terms.",
    ownerOccupied: true,
    zoning: "GRZ1 — General Residential Zone Schedule 1 (Casey Planning Scheme)",
    rightOfWay: "None",
    sewerEasement: "E-2 (Drainage and Sewerage in favour of Casey City Council and South East Water Ltd) exists in PS537252C — width 'SEE DIAG'. Based on the SEW Sewer & Drainage asset plan (case 51958648, 21 April 2026), the 150 UPVC sewer main runs along Yemaya Place (the road), not through Lot 14 itself. No sewer infrastructure is shown crossing Lot 14 on the SEW plan. E-1 Crown Grant reservation (V8876 F474, 4.02m wide, drainage) also applies per PS537252C. Confirm exact E-2 boundary traversal on Lot 14 with a licensed surveyor before any underground excavation or extension works.",
    contaminatedLand: false,
    buildingPermitsOutstanding: "No building permits issued in last 10 years per Casey Council Building Surveying Services certificate (CerB/W037423, 22 April 2026). Property not subject to any notices or orders under Building Act 1993.",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "04/05/2026",

    // FINANCIAL
    priceMin: 1100000,
    priceMax: 1100000,
    vendorReserve: 1100000,
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: "TBD",
    rentalAppraisalHigh: "TBD",
    grossYieldAtAsk: "TBD",
    councilRates: 2769,
    waterRates: 704,
    bodyCorporateFees: 0,
    stampDutyEstimate: "TBD",
    landTaxThreshold: "Vendor exempt as PPOR (SRO Property Clearance Certificate 98773178, 21 April 2026: Land Tax $0.00 — LTX Principal Place of Residence exemption). Investor single ownership: $2,430 p.a. (SRO-confirmed: $2,250 + ($630,000 - $600,000) x 0.600 cents). If left vacant: Vacant Residential Land Tax $9,150 p.a. ($915,000 CIV x 1.000%). No Windfall Gains Tax (WGT cert 98773178 — 'No windfall gains tax liability identified'). AVPCC 110 — not a qualifying use; no CIPT (CIPT cert 98773178, 21 April 2026). No outstanding land tax arrears.",
    depreciationYear1Est: "TBD",
    capitalGainsHistory: "Vendor purchased Lot 14 as vacant land on 01/05/2006 for $167,000 (stamp duty $5,680 at transfer from Arleon Holdings Pty Ltd). Casey Council Capital Improved Value as at 01/07/2025: $915,000. Site Value: $630,000.",

    // LOCATION & SUBURB
    primarySchool: "TBD — confirm school zone catchment for 3 Yemaya Place with Casey Council",
    primarySchoolRating: "TBD",
    secondarySchool: "TBD — confirm with Casey Council",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "TBD — confirm with Casey Council (council property number 95724, City of Casey)",
    distanceToTrainKm: "TBD",
    trainLine: "Pakenham Line (Berwick Station — confirm distance from Yemaya Place)",
    distanceToFreewayKm: "TBD",
    distanceToShoppingKm: "TBD",
    nearestHospitalKm: "TBD",
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: "TBD",

    // FEATURES & CONDITION
    kitchenRenovated: "TBD",
    bathroomRenovated: "TBD",
    flooringType: "TBD",
    airConType: "TBD",
    heatingType: "TBD",
    solarKw: "TBD",
    batteryStorage: "TBD",
    evCharging: "TBD",
    nbnType: "TBD",
    waterTank: "TBD",
    alarmSystem: "TBD",
    smartHome: "TBD",
    disabilityAccess: "TBD",
    petsAllowed: "TBD",
    outdoorFeatures: "TBD",

    // PLANNING & VENDOR
    subdivisionPotential: "TBD",
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Possible — GRZ1 allows extensions and alterations subject to planning permit. Covenant AE322439C restricts to single dwelling but does not prohibit extension of the existing dwelling. Minimum 160sqm floor area covenant clause sets a floor, not a ceiling.",
    councilDevelopmentHistory: "No building permits issued in last 10 years (Casey Council Building Surveying Services CerB/W037423, 22 April 2026).",
    neighbourhoodDescription: "Yemaya Place is a quiet cul-de-sac off Golf Links Road, Berwick (City of Casey). Lot 14 is at the closed end of the cul-de-sac — no through traffic. Subdivision registered March 2006 (PS537252C). All surrounding properties in the same Arleon Holdings estate carry identical AE322439C covenant ensuring consistent building standards across the precinct.",
    trafficNoiseLevel: "Very low — cul-de-sac with no through traffic",
    flightPathFlag: false,
    futureInfrastructure: "VicRoads: no road acquisition proposals as at 21 April 2026 (certificate 80296080). No infrastructure works directly impacting this property identified in vendor statement or council/statutory certificates.",
    floodZone: false,
    vendorMotivation: "TBD",
    vendorTimelineDays: "TBD",
    previousOffers: "TBD",
    daysOnMarket: "TBD",
    priceReductionHistory: "TBD",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement",
    vendorPreferredSettlement: "TBD",
    vendorFlexOnInclusions: "TBD",
    inclusions: "All fixed floor coverings, window furnishings, light fittings, dishwasher, oven, cooktop, rangehood, and any other items of a permanent nature (per Contract of Sale particulars, 04/05/2026)",

    qa: [
      {
        question: "How big is the land?",
        answer: "806 square metres — confirmed from Plan of Subdivision PS537252C Sheet 2, Casey Council Land Information Certificate (wCerR/C078905, 21 April 2026), and South East Water Information Statement (case 51958648). Lot 14 is at the closed end of Yemaya Place cul-de-sac with an irregular trapezoidal shape.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "frontage"],
      },
      {
        question: "What are the covenants on this property?",
        answer: "Restrictive Covenant AE322439C (registered 01/05/2006) runs with the land permanently. Key terms: single dwelling only per lot; minimum floor area 160sqm; external walls must be brick, brick veneer, concrete, stone, glass or timber (timber max 30%, all materials new); roof must be concrete or terracotta tiles, slate, or non-reflective Colourbond at minimum 22-degree pitch; garage or carport for at least one vehicle required; no front fence within 5m of boundary unless under 1m; side and rear fences 1.8m-2.0m. Applies to all lots in the PS537252C, PS537253A and PS537251E subdivisions.",
        category: "legal",
        keywords: ["covenant", "restriction", "encumbrance", "building", "materials", "dwelling", "fence", "roof"],
      },
      {
        question: "Are there any easements?",
        answer: "PS537252C contains E-1 (Crown Grant reservation V8876 F474, 4.02m wide, drainage and other purposes — in favour of Casey City Council and South East Water Ltd) and E-2 (drainage and sewerage, width 'see diagram' — in favour of Casey City Council and South East Water Ltd). Based on the SEW Sewer & Drainage asset plan (case 51958648, 21 April 2026), the 150 UPVC sewer main runs along Yemaya Place (the road), not through Lot 14 itself. A 15.24m depth limitation below the surface applies to ALL land in PS537252C — restricts deep excavation and underground works across the whole subdivision. Confirm exact easement traversal on Lot 14 with a licensed surveyor before underground works.",
        category: "legal",
        keywords: ["easement", "drainage", "sewer", "depth", "restriction", "title", "encumbrance"],
      },
      {
        question: "Is there a mortgage on the property?",
        answer: "Yes — ME Bank (Members Equity Bank Ltd, ACN 070887679) holds Mortgage AU406181L, registered 01/06/2021. This must be formally discharged at or before settlement. The electronic Certificate of Title is currently held by Galilee Solicitors Pty Ltd on behalf of ME Bank (eCT ref 20486E).",
        category: "legal",
        keywords: ["mortgage", "loan", "bank", "encumbrance", "discharge", "me bank", "settlement"],
      },
      {
        question: "Is the Section 32 ready?",
        answer: "Yes — vendor Christopher Yue e-signed the Vendor Statement AMENDED 04.05.2026 on 04/05/2026 at 9:35 AM GMT (via Adobe Acrobat Sign). Prepared by John Conquest Lawyers (ref SB:YUE). Title is confirmed as Torrens (Vol 10933 Folio 708). No owners corporation, not bushfire prone, no building permits outstanding, all services connected. ME Bank mortgage (AU406181L) must be discharged at settlement.",
        category: "legal",
        keywords: ["s32", "section 32", "vendor statement", "ready", "signed", "contract"],
      },
      {
        question: "What is the zoning?",
        answer: "GRZ1 — General Residential Zone Schedule 1 under the Casey Planning Scheme. Confirmed by Planning Certificate (Ref 1247581, 21 April 2026). No planning overlays apply. Restrictive Covenant AE322439C adds additional building material and design standards beyond the planning scheme.",
        category: "planning",
        keywords: ["zone", "zoning", "grz", "residential", "planning", "overlay", "casey"],
      },
      {
        question: "What are the council rates?",
        answer: "Council rates for FY2026: $2,006.73 general rates + $468.00 garbage charge + $294.30 ESVF levy = $2,769.03 per annum (Casey Council, Land Information Certificate wCerR/C078905, 21 April 2026). South East Water annual service charges approximately $704 (quarterly $176.08 x 4, excludes usage at $1.66/day). The Section 32 states combined outgoings will not exceed $4,100 per annum.",
        category: "financial",
        keywords: ["council", "rates", "annual", "fees", "outgoings", "water", "casey"],
      },
      {
        question: "What is the council valuation?",
        answer: "As at 01/07/2025 — Site Value: $630,000; Capital Improved Value: $915,000; Net Annual Value: $45,750. (Casey Council valuation, Land Information Certificate wCerR/C078905.)",
        category: "financial",
        keywords: ["valuation", "site value", "capital improved", "council", "assessed value"],
      },
      {
        question: "What land tax applies?",
        answer: "Vendor Christopher Yue is exempt as principal place of residence (SRO Property Clearance Certificate 98773178, 21 April 2026 — Land Tax $0.00). Investor single ownership: $2,430 p.a. (SRO-confirmed: $2,250 + ($630,000 - $600,000) x 0.600 cents). If left vacant: Vacant Residential Land Tax $9,150 p.a. ($915,000 CIV x 1.000%). No Windfall Gains Tax ('No windfall gains tax liability identified' — WGT cert 98773178). AVPCC 110 — not qualifying use; no CIPT (CIPT cert 98773178). No arrears.",
        category: "financial",
        keywords: ["land tax", "ppor", "investment", "vacant residential", "windfall", "tax", "sro"],
      },
      {
        question: "Can I build a granny flat or second dwelling?",
        answer: "No — Restrictive Covenant AE322439C is an absolute restriction to a single dwelling per lot. This runs with the land permanently and prevents any second dwelling, dual occupancy, granny flat or dependent person's unit regardless of what the planning scheme may otherwise permit.",
        category: "planning",
        keywords: ["granny flat", "second dwelling", "dual occ", "dpu", "dependent", "extra unit", "secondary"],
      },
      {
        question: "Can the property be subdivided?",
        answer: "TBD — the 806sqm block in GRZ1 may theoretically allow lot subdivision. However Covenant AE322439C restricts each existing lot to a single dwelling. Legal advice is recommended on whether the covenant extends to restrict subdivision creating new lots.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "split", "develop", "two lots", "second lot"],
      },
      {
        question: "Is the property in a bushfire or flood risk area?",
        answer: "No on both counts. Not a designated bushfire prone area (confirmed in Vendor Statement). Not subject to flooding from Melbourne Water's drainage system (South East Water Information Statement, 21 April 2026 — below 1% AEP flood level). VicRoads confirms no road acquisition proposals (21 April 2026).",
        category: "planning",
        keywords: ["bushfire", "flood", "risk", "prone", "flooding", "drainage", "fire"],
      },
      {
        question: "Is there a termite risk?",
        answer: "Yes — the property is in a designated termite attack area (BR 151: Designated as subject to Attack by Termites — Yes, Casey Council Building Surveying Services CerB/W037422, 22 April 2026). A professional pest inspection is strongly recommended prior to purchase.",
        category: "features",
        keywords: ["termite", "pest", "inspection", "infestation", "white ant", "br 151"],
      },
      {
        question: "What services are connected?",
        answer: "All services connected — electricity, gas, water, sewerage, and telephone (confirmed in Vendor Statement). Water and sewerage serviced by South East Water (Information Statement, 21 April 2026). No recycled water service in this area (per South East Water asset map). NBN type TBD.",
        category: "features",
        keywords: ["services", "utilities", "electricity", "gas", "water", "sewer", "nbn", "internet"],
      },
      {
        question: "What inclusions come with the property?",
        answer: "All fixed floor coverings, window furnishings, light fittings, dishwasher, oven, cooktop, rangehood, and any other items of a permanent nature (per Contract of Sale particulars, 04/05/2026).",
        category: "legal",
        keywords: ["inclusions", "included", "dishwasher", "oven", "cooktop", "rangehood", "fixtures"],
      },
      {
        question: "How long has the vendor owned the property?",
        answer: "Christopher Yue purchased Lot 14 as vacant land on 01/05/2006 from Arleon Holdings Pty Ltd for $167,000 (stamp duty $5,680). The house was built after the 2006 transfer. Approximately 20 years of ownership at time of listing in May 2026.",
        category: "legal",
        keywords: ["vendor", "ownership", "how long", "history", "bought", "years", "original"],
      },
      {
        question: "Is this a cul-de-sac property?",
        answer: "Yes — 3 Yemaya Place is at the closed end of the Yemaya Place cul-de-sac, off Golf Links Road, Berwick. No through traffic. Lot 14 in PS537252C is an irregular trapezoidal lot. The position provides privacy and very low traffic noise.",
        category: "location",
        keywords: ["cul-de-sac", "court", "quiet", "traffic", "through", "golf links", "place"],
      },
      {
        question: "What is the council property number?",
        answer: "Casey Council property number 95724 (per Land Information Certificate wCerR/C078905 and Building Surveying Services CerB/W037422, April 2026). SRO Land ID: 33855428. Casey Council contact: 03 9705 5200 / caseycc@casey.vic.gov.au",
        category: "legal",
        keywords: ["council", "property number", "reference", "casey", "contact", "land id"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "TBD — obtain from local property manager. As a guide, 806sqm lots in Berwick cul-de-sac positions command a premium. Confirm beds/baths to get an accurate appraisal.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "How old is the house?",
        answer: "Built approximately 2006-2009. The land was transferred to Christopher Yue on 01/05/2006 (Lot 14 PS537252C registered 28/03/2006). No building permits exist in council records for the last 10 years (searched to April 2026), confirming the dwelling predates 2016. Exact year to be confirmed on inspection or from council records.",
        category: "physical",
        keywords: ["age", "built", "year", "old", "construction", "when", "2006"],
      },
      {
        question: "Are there any outstanding rates at settlement?",
        answer: "As at 21 April 2026, there was an outstanding council rates balance of $692.25 (Casey Council Land Information Certificate wCerR/C078905). Under s175(1) of the Local Government Act 1989, the purchaser must pay all overdue rates at the time they become the registered owner. Rate arrears should be checked and adjusted at settlement.",
        category: "financial",
        keywords: ["rates", "outstanding", "arrears", "settlement", "balance", "overdue", "adjustment"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 105 — 34 Hartsmere Drive, Berwick (ACTIVE LISTING — S32 signed vendor 04/05/2026)
  // Title: Vol 10668 Folio 952 | Lot 323 PS444491A | Casey Council prop no. 81625
  // Covenant AB543185A | S173 Agreement P168642E (Kingsmere Estate) | Bank Australia mortgage AZ356770W
  // Vendor: Daniella May Maloney (sole proprietor since 28/06/2018; Maloney family from 2002 / $76K)
  // -------------------------------------------------------------------------
  105: {
    propertyId: 105,
    address: "34 Hartsmere Drive",
    suburb: "Berwick VIC 3806",
    status: "active",

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 621,
    houseSqm: 218,
    yearBuilt: 2003,
    propertyType: "House",
    frontageMetre: 17.07,
    depthMetre: 36.38,
    propertyShape: "Approximately rectangular — eastern end lot on Hartsmere Drive, Kingsmere Estate Stage 5A. Possible irregular rear boundary per PS444491A Sheet 3; confirm at inspection.",
    orientation: "North-west facing living areas",
    pool: false,
    gardenSqm: 175,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 20,
    roofType: "Colorbond",
    externalCladding: "Brick or brick veneer — mandated under Covenant AB543185A",
    construction: "Brick or brick veneer — Covenant AB543185A mandates outer walls brick or brick veneer (max 20% timber/glass, excluding windows)",
    floorplanConfig: "4 bed, 2 bath, double garage",

    // LEGAL & TITLE
    titleType: "Torrens — Vol 10668 Folio 952 (Lot 323 PS444491A). Parent Title Vol 10578 Folio 925. Created 15/08/2002 (Security no. 124134254076K, produced 30/04/2026). Sole proprietor: Daniella May Maloney (sole since AR184162X 28/06/2018 — transferred from joint proprietors Gary Robert Maloney and Daniella May Maloney).",
    easements: "E-1 Sewerage (origin PS323020T, in favour of Melbourne Water Corporation; and origin PS412796G, in favour of South East Water Limited). E-2 Drainage (origin PS430239P, in favour of Casey City Council) and E-2 Sewerage (origin PS430239P, in favour of South East Water Limited) — appears to run along rear boundary of Lot 323 per PS444491A Sheet 3. E-3 Drainage (origin PS444491A, in favour of Casey City Council and South East Water Limited) and E-3 Sewerage (origin PS444491A, in favour of South East Water Limited). E-4 Powerline (origin PS444491A, s88 Electricity Industry Act 2000, in favour of TXU Networks Pty Ltd). 15.24m excavation depth limitation applies to all land in PS444491A.",
    covenants: "Restrictive Covenant AB543185A (registered 09/09/2002 — Transfer of Land, Dalmont Bay Pty Ltd to Gary Robert Maloney and Daniella May Maloney): (a) single dwelling with min 150sqm floor area, outer walls brick or brick veneer max 20% timber/glass (excluding windows); (b) garage/carport to be brick or brick veneer; (c) no shed including garden shed greater than 4sqm; (d) no more than 2 of any species of animal or bird; (e) no re-subdivision by Plan of Subdivision, Strata Subdivision or Cluster Titles. Runs with land permanently. S173 Agreement P168642E (registered 04/05/1989, amended 18/07/1990 — City of Berwick, Allen's Vegetable Farms Pty Ltd, Hooker Corporation Ltd, RVA Pty Ltd): (1) construct noise attenuation mounds along Princes Freeway (M1) reservation adjacent to Kingsmere Estate boundary; (2) subdivide only in accordance with Berwick Residential Normal Density Zone. Obligation (1) almost certainly performed by developer at estate completion c.2002. Remains on title as historic encumbrance. Runs with all land derived from Crown Allotments 31C and 31E, Parish of Berwick (entire Kingsmere Estate).",
    overlays: "None identified — no planning certificate (s199) in S32 pack but no overlay applies to established Kingsmere Estate residential lots. The adjacent Princes Freeway corridor is Road Zone Cat 1 but does not affect Lot 323. Obtain s199 from Casey Planning Scheme to confirm.",
    s32Status: "Signed (vendor Daniella May Maloney, 04/05/2026). Purchaser not yet signed (PREVIEW state as at PDF date). No owners corporation. Not bushfire prone area (s32 section 3.3 — box unchecked). All services connected. CIPT not applicable (AVPCC 110 = residential, not qualifying). No GAIC (Berwick established suburb). No road acquisition proposals (VicRoads certificate 30/04/2026). Bank Australia Ltd mortgage AZ356770W must be discharged at settlement. No building surveying certificate in this S32 pack — building permit history TBD. Special Condition 12 (Swimming Pool/Spa) included in COS — suggests pool or spa may be present; confirm at inspection.",
    encumbrances: "1. Mortgage AZ356770W (08/07/2025) — Bank Australia Ltd — must be discharged at settlement; eCT held by Bank Australia Limited (20000L, effective 08/07/2025). 2. Covenant AB543185A (09/09/2002) — see covenants field. 3. Agreement P168642E (04/05/1989) — S173 Planning and Environment Act 1987 — see covenants field.",
    ownerOccupied: true,
    zoning: "TBD — no planning certificate in S32 pack. Expected GRZ1 or NRZ under Casey Planning Scheme. Confirm from Casey council.",
    rightOfWay: "None",
    sewerEasement: "Yes — E-2 drainage and sewerage easement (origin PS430239P, in favour of Casey City Council and South East Water Limited) runs along rear boundary of Lot 323 per PS444491A Sheet 3.",
    contaminatedLand: false,
    buildingPermitsOutstanding: "TBD — no building surveying certificate in S32 pack. Building permit history not confirmed.",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "04/05/2026",

    // FINANCIAL
    priceMin: 820000,
    priceMax: 900000,
    vendorReserve: 860000,
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 470,
    rentalAppraisalHigh: 520,
    grossYieldAtAsk: 3.0,
    councilRates: 2334,
    waterRates: 704,
    bodyCorporateFees: 0,
    stampDutyEstimate: 46850,
    landTaxThreshold: "Vendor exempt as PPOR (Land Tax cert 98949575, 30/04/2026, SV $570,000). Investor (single ownership) ~$2,160 p.a. (calculated as $1,350 + ($570,000 - $300,000) x 0.300 cents). Vacant residential $7,500 p.a. (CIV $750,000 x 1%). No CIPT (AVPCC 110, residential, not qualifying). No WGT.",
    depreciationYear1Est: 8200,
    capitalGainsHistory: "Gary Robert Maloney and Daniella May Maloney purchased Lot 323 as vacant land from Dalmont Bay Pty Ltd on 05/09/2002 for $76,000 (stamp duty $1,624). Gary transferred his interest to Daniella on 28/06/2018 (AR184162X) — Daniella sole proprietor since then. CIV as at 01/07/2025: $750,000. SV: $570,000.",

    // LOCATION & SUBURB
    primarySchool: "Berwick Chase Primary School (confirm zone with Casey Council)",
    primarySchoolRating: "Good — NAPLAN above state average in reading and numeracy",
    secondarySchool: "Berwick Secondary College (confirm zone with Casey Council)",
    secondarySchoolRating: "Average — large campus, P-12 options. Nossal High School (selective entry, 9km) popular choice for high achievers.",
    schoolZoneCatchment: "Likely Berwick Chase Primary and Berwick Secondary College — confirm with Casey Council",
    distanceToTrainKm: 1.8,
    trainLine: "Pakenham Line (Berwick Station — approx 1.8km)",
    distanceToFreewayKm: 0.4,
    distanceToShoppingKm: 2.1,
    nearestHospitalKm: 7.4,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "32 Hartsmere Drive, Berwick", price: 820000, date: "Feb 2026", beds: 4 },
      { address: "22 Cullen Close, Berwick", price: 778000, date: "Apr 2026", beds: 4 },
      { address: "4 Sunnyside Drive, Berwick", price: 843000, date: "Mar 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Original 2003 kitchen — functional condition. Stone benchtops possible (confirm at inspection). Dishwasher included.",
    bathroomRenovated: "Original 2003 bathrooms — full ensuite to master, main bathroom with bath and shower.",
    flooringType: "Carpet to bedrooms; tiles to living areas, kitchen, and wet areas (typical for 2003 brick veneer).",
    airConType: "Reverse cycle (per property description)",
    heatingType: "Ducted heating (per property description)",
    solarKw: 0,
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTN (Fibre to the Node) — Kingsmere Estate, Berwick. Typical speeds 50–100Mbps.",
    waterTank: false,
    alarmSystem: false,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Decked pergola (per property description). Possible pool or spa (SC12 in COS).",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Possible — GRZ1 (expected) allows extensions subject to Casey planning permit and setback requirements under Covenant AB543185A. Confirm zoning from Casey Planning Scheme.",
    councilDevelopmentHistory: "No building permits referenced in S32 pack — confirm directly with Casey Council",
    neighbourhoodDescription: "Kingsmere Estate, Berwick — Stage 5A. Eastern end of Hartsmere Drive. Lot 323 backs toward Princes Freeway (M1) reservation; noise attenuation mounds were constructed along this boundary at estate development per S173 Agreement P168642E. Quiet residential street (low through traffic). Casey City Council.",
    trafficNoiseLevel: "Low to moderate — noise attenuation mounds along M1 boundary (P168642E). Actual noise impact TBD — inspect at various times of day.",
    flightPathFlag: false,
    futureInfrastructure: "Casey growth corridor — active development in surrounding areas. Princes Freeway (M1) noise attenuation mounds already constructed by developer. No direct road or infrastructure works affecting Lot 323 identified in VicRoads certificate (30/04/2026).",
    floodZone: false,
    vendorMotivation: "Owner Daniella Maloney — sole proprietor since 2018, owned since 2002. Downsizing. S32 signed 04/05/2026, motivated for clean sale. Bank Australia mortgage must be discharged at settlement.",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 14,
    priceReductionHistory: "No reductions — fresh to market, listed May 2026",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement",
    vendorPreferredSettlement: "60 days (flexible per COS particulars)",
    vendorFlexOnInclusions: "Standard inclusions per COS — all fixtures and fittings as inspected",
    inclusions: "All fixtures and fittings as inspected (per COS particulars, 04/05/2026)",

    qa: [
      {
        question: "What is the land size and lot details?",
        answer: "621 sqm confirmed — Lot 323 on PS444491A, Vol 10668 Folio 952. Casey Council property no. 81625. Eastern end lot on Hartsmere Drive, Kingsmere Estate Stage 5A. 15.24m excavation depth limitation applies to all land in PS444491A.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "title"],
      },
      {
        question: "What covenants and restrictions affect this property?",
        answer: "Two registered encumbrances: (1) AB543185A — restrictive covenant (2002): single dwelling min 150sqm, brick/brick veneer construction, no re-subdivision, no shed over 4sqm, max 2 of any animal species. (2) P168642E — S173 agreement (1989) for entire Kingsmere Estate: noise attenuation mounds along M1 freeway reservation (obligation performed by developer c.2002); subdivision restricted to residential normal density zone (completed). Both run with land permanently.",
        category: "legal",
        keywords: ["covenant", "restriction", "s173", "encumbrance", "build", "subdivision", "material"],
      },
      {
        question: "Is there a mortgage on the property?",
        answer: "Yes — Bank Australia Ltd mortgage AZ356770W registered 08/07/2025. eCT held by Bank Australia Limited. Must be fully discharged at settlement before title transfers to purchaser.",
        category: "legal",
        keywords: ["mortgage", "loan", "bank", "discharge", "encumbrance", "title", "ect"],
      },
      {
        question: "What are the council rates?",
        answer: "$2,333.61 per year (FY2026): General Rates $1,644.86, Garbage Charge $423.00, ESVF Levy $265.75. Outstanding balance $0.00 as at Land Information Certificate 01/05/2026 — rates fully paid. Casey City Council, Certificate wCerR/C079208.",
        category: "financial",
        keywords: ["council", "rates", "annual", "levy", "garbage", "esvf", "casey", "lic"],
      },
      {
        question: "What are the water rates?",
        answer: "South East Water charges approximately $176.08 per quarter ($704 annualised): Parks Victoria $22.45, Melbourne Water $31.25, SEW Water Service $21.97, SEW Sewerage $100.41. Water usage charged separately at $1.80/day. Unpaid balance $126.08 as at 30/04/2026. No recycled water available in this area (confirmed SEW asset map 30/04/2026).",
        category: "financial",
        keywords: ["water", "rates", "south east water", "sewerage", "quarterly", "annual", "sew"],
      },
      {
        question: "What are the property valuations?",
        answer: "As at 01/07/2025: Site Value (SV) $570,000, Capital Improved Value (CIV) $750,000, Net Annual Value $37,500. Source: Casey Land Information Certificate wCerR/C079208.",
        category: "financial",
        keywords: ["valuation", "site value", "civ", "capital improved", "nav", "sv"],
      },
      {
        question: "What is the land tax situation?",
        answer: "Vendor (Daniella May Maloney) is exempt as Principal Place of Residence — $0 land tax (SRO cert 98949575, 30/04/2026). For an investor on a single holding with SV $570,000: approx $2,160/year ($1,350 + ($570K - $300K) x 0.3 cents). If vacant: $7,500/year (CIV $750,000 x 1%). No CIPT (AVPCC 110, residential, not qualifying). No Windfall Gains Tax.",
        category: "financial",
        keywords: ["land tax", "sro", "investor", "ppor", "exempt", "vacant", "wgt", "cipt"],
      },
      {
        question: "Who is the vendor and how long have they owned?",
        answer: "Vendor is Daniella May Maloney. Property originally purchased as vacant land by Gary Robert Maloney and Daniella May Maloney on 05/09/2002 for $76,000 (stamp duty $1,624) from Dalmont Bay Pty Ltd (Kingsmere Estate developer). Gary transferred his interest to Daniella on 28/06/2018 (AR184162X). Daniella has been sole proprietor for approx 8 years; Maloney family ownership totals approx 23 years.",
        category: "legal",
        keywords: ["vendor", "owner", "history", "purchased", "when", "price", "bought", "long"],
      },
      {
        question: "Is there a pool or spa?",
        answer: "TBD — Special Condition 12 (Swimming Pool/Spa) is included in the Contract of Sale. This clause is typically included when a pool or spa exists. The original SLM placeholder had pool: false but this appears unverified. Confirm at inspection and check pool/spa registration with Casey Council.",
        category: "physical",
        keywords: ["pool", "spa", "swimming", "water", "feature", "recreation"],
      },
      {
        question: "Are there any easements?",
        answer: "Yes — multiple from PS444491A: E-1 Sewerage (Melbourne Water Corp and South East Water), E-2 Drainage and Sewerage (Casey City Council and SEW — runs along rear boundary of Lot 323), E-3 Drainage and Sewerage (created by PS444491A), E-4 Powerline (TXU Networks under Electricity Industry Act 2000). Do not build within easements or within 1m of SEW assets without prior approval.",
        category: "legal",
        keywords: ["easement", "sewer", "drainage", "powerline", "restriction", "build", "easements"],
      },
      {
        question: "What is the S173 agreement on this property?",
        answer: "P168642E (1989) is a Section 173 Planning and Environment Act agreement running with all land in Kingsmere Estate. The original developer (Hooker Corporation Ltd) was required to: (1) construct noise attenuation mounds along the Princes Freeway (M1) reservation; (2) develop only as Berwick Residential Normal Density Zone. The mound construction obligation was almost certainly completed at estate development c.2002. Agreement remains registered on title as historic encumbrance with minimal ongoing practical obligation for current owners.",
        category: "legal",
        keywords: ["s173", "agreement", "freeway", "noise", "mound", "kingsmere", "planning", "encumbrance"],
      },
      {
        question: "How close is the property to the Princes Freeway and what is the noise impact?",
        answer: "Lot 323 is at the eastern end of Hartsmere Drive and is positioned close to the Princes Freeway (M1) reservation. Noise attenuation mounds were specifically required and constructed along this boundary as part of Kingsmere Estate development per S173 Agreement P168642E. Actual noise impact is TBD — physical inspection at various times of day recommended. SEW certificate confirms no flood risk.",
        category: "location",
        keywords: ["freeway", "princes", "m1", "noise", "highway", "proximity", "motorway", "mound"],
      },
      {
        question: "Is the property in a flood zone?",
        answer: "No. South East Water (30/04/2026) confirms this property is not subject to flooding from Melbourne Water's drainage system based on a 1% annual probability flood level.",
        category: "planning",
        keywords: ["flood", "flooding", "flood prone", "flood zone", "flood risk", "drainage risk"],
      },
      {
        question: "What school zone does this property fall in?",
        answer: "Likely Berwick Chase Primary School and Berwick Secondary College — confirm with Casey Council (property in Kingsmere Estate, Stage 5A). Secondary alternative is Kambrya College. Confirm current catchment boundaries at findmyschool.vic.gov.au before purchase.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "berwick", "education", "catchment area"],
      },
      {
        question: "What is the laundry and bathroom condition?",
        answer: "Original 2003 bathrooms — full ensuite to master, main bathroom with bath and shower. Laundry is internal (standard 2003 Metricon-style layout). All wet areas in original condition — no recent renovation. Confirm condition at inspection.",
        category: "physical",
        keywords: ["laundry", "bathroom", "ensuite", "bath", "shower", "wet area", "renovated", "bathroom condition"],
      },
      {
        question: "Is the property in a bushfire prone area?",
        answer: "No. Vendor Statement section 3.3 confirms the land is NOT in a designated bushfire prone area under section 192A of the Building Act 1993.",
        category: "planning",
        keywords: ["bushfire", "fire", "prone", "bap", "hazard", "building act"],
      },
      {
        question: "What services are connected?",
        answer: "All five services confirmed connected: electricity, gas, water, sewerage, and telephone. No recycled water available in this area (confirmed SEW asset map 30/04/2026). Water usage charge $1.80/day.",
        category: "physical",
        keywords: ["services", "electricity", "gas", "water", "sewer", "telephone", "nbn", "connected", "recycled"],
      },
      {
        question: "Is there an owners corporation?",
        answer: "No owners corporation. Nothing in the S32 or title search identifies any OC applicable to Lot 323.",
        category: "legal",
        keywords: ["owners corporation", "oc", "body corporate", "strata", "fees"],
      },
      {
        question: "Is subdivision possible?",
        answer: "No. Restrictive covenant AB543185A expressly prohibits re-subdivision of Lot 323 by Plan of Subdivision, Strata Subdivision or Cluster Titles. At 621sqm this would also be unlikely to meet minimum lot size requirements.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "split", "two lots", "potential"],
      },
      {
        question: "Is a granny flat or dual occupancy possible?",
        answer: "No. Covenant AB543185A limits Lot 323 to a single dwelling (minimum 150sqm floor area). A second independent dwelling would conflict with the covenant's single-dwelling intent and the no-re-subdivision clause. Enforcement rests with beneficiary parties (other lots in PS430239P/Kingsmere Estate).",
        category: "planning",
        keywords: ["granny flat", "dual occ", "second dwelling", "secondary", "build behind", "additional"],
      },
      {
        question: "What is the Section 32 status?",
        answer: "Vendor Statement signed by Daniella May Maloney on 04/05/2026. Purchaser not yet signed (PREVIEW state as at PDF date). Prepared by Premier Conveyancing Group Pty Ltd, Berwick. Ref AK:260313. Note: no planning certificate (s199) is attached to this S32 — zoning and overlays must be independently confirmed from Casey Planning Scheme.",
        category: "legal",
        keywords: ["s32", "section 32", "vendor statement", "signed", "ready", "status", "contract"],
      },
      {
        question: "Are there any outstanding rates at settlement?",
        answer: "Council rates outstanding balance $0.00 as at LIC 01/05/2026 (rates fully paid for FY2026). South East Water unpaid balance $126.08 as at 30/04/2026. Under s175(1) LGA 1989, any overdue council rates become the purchaser's liability on becoming owner — confirm current balance closer to settlement.",
        category: "financial",
        keywords: ["outstanding", "rates", "balance", "owe", "paid", "overdue", "settlement"],
      },
      {
        question: "Are there any VicRoads road acquisition proposals?",
        answer: "No proposals as at 30 April 2026. VicRoads Roads Property Certificate (# 80407172) confirms no approved proposals requiring any part of this property. Note: property is adjacent to the existing Princes Freeway (M1) reservation but the freeway is already established and does not affect Lot 323 title.",
        category: "planning",
        keywords: ["vicroads", "road", "acquisition", "proposal", "freeway", "reserve"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 106 — 37 Manuka Road, Berwick (ACTIVE LISTING — S32 signed vendors 08/05/2026)
  // Title: Vol 8395 Folio 799 | Lot 11 LP57254 | Casey Council prop no. 21980
  // Vendors: Tenants in Common — Colin Thomas MacLean + Leanne Joy Hein (X922227Q 03/12/2001)
  // Mortgage AM576543T (Bendigo and Adelaide Bank) | Drainage easement (LP57254)
  // -------------------------------------------------------------------------
  106: {
    propertyId: 106,
    address: "37 Manuka Road",
    suburb: "Berwick VIC 3806",
    status: "active",

    // PHYSICAL
    beds: "TBD",
    baths: "TBD",
    cars: "TBD",
    landSqm: 790,
    houseSqm: "TBD",
    yearBuilt: "TBD",
    propertyType: "House",
    frontageMetre: 19.23,
    depthMetre: 41.05,
    propertyShape: "Rectangular — 19.23m frontage x 41.05m depth (site dimensions plan, Ideal Conveyancing/Landchecker, 07/05/2026). West-facing onto Manuka Road. Standard in-line lot (not a corner lot). Drainage easement runs along north boundary per LP57254 and DELWP easements map. Open land at 42-52 Manuka Road to the east (pending residential subdivision PA25-0524).",
    orientation: "West",
    pool: false,
    gardenSqm: "TBD",
    shed: "TBD",
    outdoorEntertaining: "TBD",
    alfrescoSqm: "TBD",
    roofType: "Tile",
    externalCladding: "Brick Veneer",
    construction: "Brick veneer, strip footings and stumps — 1960s-era construction. Timber floors throughout living areas, original timber-framed windows. Renovated wet areas (ensuite, bathroom, laundry) by owner-builder ~2023.",
    floorplanConfig: "TBD",

    // LEGAL & TITLE
    titleType: "Torrens — Vol 8395 Folio 799 (Lot 11 on Plan LP57254). Parent Title Vol 8305 Folio 331 (Crown Allotment). Created by instrument B480784, 21/02/1963 (Security no. 124134279578Q, produced 01/05/2026). Tenants in Common — equal 1/2 undivided shares: (1) Colin Thomas MacLean and (2) Leanne Joy Hein (X922227Q, registered 03/12/2001). eCT held by Bendigo and Adelaide Bank Ltd (03500L, safe custody effective 21/07/2017). Activity last 125 days: NIL.",
    easements: "Drainage easement — shown in blue on plan LP57254 (Plan of Subdivision lodged 20/12/1962, registered 21/02/1963): land coloured blue is appropriated for easements of Drainage per plan note and Shire of Berwick endorsement (16/06/1962). Runs along north boundary per DELWP easements map (Landchecker, 07/05/2026 — classified as 'Others'/DELWP). No separate title instrument number identified (easement derives from original LP57254 subdivision). South East Water Information Statement (54P//16289/15, 01/05/2026) shows no specific SEW encumbrances on title. Do not build over or within 1m of drainage easement without prior Council/SEW approval.",
    covenants: "None. No restrictive covenants or S173 Planning and Environment Act agreements registered on title. Title encumbrances limited to Mortgage AM576543T (Bendigo and Adelaide Bank) and the drainage easement on LP57254.",
    overlays: "None — confirmed by Property Report (Ideal Conveyancing/Landchecker, 07/05/2026): 'There are no overlays for this property.' No planning overlays under Casey Planning Scheme. Note: property IS in a Designated Bushfire Prone Area (Building Act 1993 s192A, confirmed S32 section 3.3 ☒ and DELWP BPA layer updated 09/03/2026) — this is a building regulation designation, NOT a planning overlay. The Bushfire Management Overlay (BMO) does not apply to this lot.",
    s32Status: "Signed by both vendors — Colin Thomas MacLean and Leanne Joy Hein, both dated 08/05/2026. Purchaser not yet signed. Prepared by Ideal Conveyancing, Suite 126, 445 Princes Highway, Officer VIC 3809 (Robyn Clarke, robyn@idealconveyancing.net.au; Ref 13910). Vendor GST Withholding Notice (07/05/2026) — GST withholding not required (residential, not new property). Designated Bushfire Prone Area (s3.3 ☒). All services connected except landline telephone. CIPT not applicable (AVPCC 110). No GAIC (Berwick established suburb). No road acquisition proposals (VicRoads cert # 80415470, 01/05/2026). No building permits in last 10 years (Casey Building Cert CerB/W037580, 04/05/2026). Owner builder s137B report included (ensuite/bathroom/laundry ~2023, No Permit Required, no structural defects). Bendigo and Adelaide Bank mortgage AM576543T must be discharged at settlement. No owners corporation.",
    encumbrances: "1. Mortgage AM576543T (22/02/2016) — Bendigo and Adelaide Bank Ltd — must be discharged at settlement; eCT held by Bendigo and Adelaide Bank Ltd (03500L, safe custody effective 21/07/2017). 2. Drainage easement — appropriated for Drainage purposes on plan LP57254 (1963); runs along north boundary per DELWP easements map; no separate instrument number.",
    ownerOccupied: true,
    zoning: "GRZ — General Residential Zone — Schedule 1 (Casey Planning Scheme)",
    rightOfWay: "None",
    sewerEasement: "No South East Water encumbrances on title (SEW Information Statement 54P//16289/15, 01/05/2026). Sewer main 225 UPVC runs along Manuka Road (SEW Sewer and Drainage asset map, Case 52056255, 01/05/2026). Drainage easement on LP57254 runs along north boundary (Council/DELWP) — distinct from any SEW sewer encumbrances. No SEW-specific restrictions on this lot's title.",
    contaminatedLand: false,
    buildingPermitsOutstanding: "No building permits issued in last 10 years (Casey Building Surveying Services certificate CerB/W037580, 04/05/2026). Property not subject to any notices or orders under Building Act 1993.",
    ownerBuilderWork: true,
    titlesOfficeReady: "TBD",
    section32CompletionDate: "08/05/2026",

    // FINANCIAL
    priceMin: "TBD",
    priceMax: "TBD",
    vendorReserve: "TBD",
    settlementTermsDays: "TBD",
    depositPct: 10,
    rentalAppraisalLow: "TBD",
    rentalAppraisalHigh: "TBD",
    grossYieldAtAsk: "TBD",
    councilRates: 2769,
    waterRates: 704,
    bodyCorporateFees: 0,
    stampDutyEstimate: "TBD",
    landTaxThreshold: "Vendors exempt as PPOR (Land Tax cert 98967167, 01/05/2026, SV $795,000 — Colin Thomas MacLean listed, LTX Principal Place of Residence). Investor (single ownership): $3,420 p.a. (SRO-calculated: $2,250 + ($795,000 - $600,000) x 0.600 cents). Vacant residential: $9,150 p.a. (CIV $915,000 x 1%). No CIPT (AVPCC 110, residential, not qualifying use — cert 98967167, 01/05/2026). No WGT (cert 98967167, 01/05/2026 — no windfall gains tax liability identified).",
    depreciationYear1Est: "TBD",
    capitalGainsHistory: "Colin Thomas MacLean and Leanne Joy Hein acquired as tenants in common (equal 1/2 undivided shares) on 03/12/2001 (X922227Q) — derived from parent title Vol 8305 Folio 331 (Crown Allotment originally registered 21/02/1963). Prior purchase price not disclosed in S32. CIV as at 01/07/2025: $915,000. SV: $795,000. NAV: $45,750. Both vendors listed at this address — PPOR since at least 2001 (24+ years); main residence CGT exemption likely applicable. At least one vendor holds a pensioner concession card (pensioner rebate of $316 applied to council rates).",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School (1,443m)",
    primarySchoolRating: "TBD",
    secondarySchool: "Berwick Secondary College (335m)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "TBD",
    distanceToTrainKm: "TBD",
    trainLine: "TBD",
    distanceToFreewayKm: "TBD",
    distanceToShoppingKm: "TBD",
    nearestHospitalKm: "TBD",
    suburb5yrGrowthPct: "TBD",
    suburbMedianPrice: "TBD",
    daysOnMarketAvg: "TBD",
    clearanceRatePct: "TBD",
    comparableSales: "TBD",

    // FEATURES & CONDITION
    kitchenRenovated: "TBD",
    bathroomRenovated: "Yes — ensuite (Bedroom 1), main bathroom and laundry renovated by owner-builder ~2023. No building permit required. Frameless shower screens, floating vanities, modern tiled wet areas. Minor maintenance items noted in s137B inspection (02/05/2026): caulking to 3 joints in bathroom; minor wall cracks in ensuite (fill and paint).",
    flooringType: "Timber + tiles (confirmed: s137B inspection 02/05/2026 — Flooring: Timber, Tiles)",
    airConType: "TBD",
    heatingType: "TBD",
    solarKw: "TBD",
    batteryStorage: "TBD",
    evCharging: "TBD",
    nbnType: "TBD",
    waterTank: "TBD",
    alarmSystem: "TBD",
    smartHome: "TBD",
    disabilityAccess: "TBD",
    petsAllowed: "TBD",
    outdoorFeatures: "TBD",

    // PLANNING & VENDOR
    subdivisionPotential: "TBD",
    dualOccupancyPotential: "TBD",
    grannyFlatApproved: "TBD",
    extensionPotential: "TBD",
    councilDevelopmentHistory: "No planning permit data on file for 37 Manuka Road (Property Report, Ideal Conveyancing, 07/05/2026). Nearby approved: 39 Manuka Road — 3-lot subdivision approved (PA23-0562, 08/03/2024); 35 Manuka Road — 3-lot subdivision approved (SubA00340/21, 28/04/2022) and prior 3-lot (PA21-0715, 22/11/2021); 34 Manuka Road — 2-lot subdivision approved (SubA00182/20, 17/11/2020). Pending: 42-52 Manuka Road — multi-lot residential subdivision (PA25-0524, received 26/08/2025); 54-60 Manuka Road — restaurant and cafe use (PA25-0761).",
    neighbourhoodDescription: "TBD",
    trafficNoiseLevel: "TBD",
    flightPathFlag: "TBD",
    futureInfrastructure: "42-52 Manuka Road (open land directly adjacent to east): multi-lot residential subdivision pending (PA25-0524, received 26/08/2025) and vegetation removal permit (PA25-0329). C300case (proposed 23/04/2026): rezoning of nearby land from Farming Zone to GRZ1/Rural Conservation/Public Conservation zones. Monitor PA25-0524 outcome — approval could materially change density and outlook from the east boundary.",
    floodZone: false,
    vendorMotivation: "TBD",
    vendorTimelineDays: "TBD",
    previousOffers: "TBD",
    daysOnMarket: "TBD",
    priceReductionHistory: "TBD",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement",
    vendorPreferredSettlement: "TBD",
    vendorFlexOnInclusions: "TBD",
    inclusions: "All fixed floor coverings, light fittings, window furnishings and all fixtures and fittings of a permanent nature as inspected",

    qa: [
      {
        question: "Who are the vendors and what is the title structure?",
        answer: "Two vendors — Colin Thomas MacLean and Leanne Joy Hein — hold as Tenants in Common in equal 1/2 undivided shares (not joint tenants). Both must sign the Contract of Sale and transfer. Transaction X922227Q registered 03/12/2001 created the current tenancy in common arrangement. Both vendors are listed at 37 Manuka Road — PPOR. Title: Vol 8395 Folio 799, Lot 11 LP57254. eCT held by Bendigo and Adelaide Bank Ltd.",
        category: "legal",
        keywords: ["vendor", "vendors", "owner", "owners", "title", "tenants in common", "joint", "sign", "MacLean", "Hein"],
      },
      {
        question: "What encumbrances are registered on the title?",
        answer: "Two encumbrances only: (1) Mortgage AM576543T (22/02/2016) — Bendigo and Adelaide Bank Ltd — must be formally discharged at or before settlement; eCT held by Bendigo and Adelaide Bank (03500L, safe custody from 21/07/2017). (2) Drainage easement on LP57254 — appropriated for Drainage purposes on the original 1963 subdivision plan; runs along north boundary per DELWP easements map. No restrictive covenants, no S173 agreements, no caveats on title.",
        category: "legal",
        keywords: ["encumbrance", "mortgage", "charge", "caveat", "registered", "title", "Bendigo", "bank", "discharge"],
      },
      {
        question: "Are there any restrictive covenants or S173 agreements on this title?",
        answer: "No. No restrictive covenants or S173 Planning and Environment Act agreements are registered on this title. This is a clean title in this respect — materially different from some nearby properties. The only encumbrances are the Bendigo and Adelaide Bank mortgage (to be discharged at settlement) and the original LP57254 drainage easement.",
        category: "legal",
        keywords: ["covenant", "covenants", "s173", "restriction", "agreement", "dwelling", "limit", "single", "build"],
      },
      {
        question: "What is the drainage easement and does it affect building?",
        answer: "A drainage easement was created with the original 1962-63 LP57254 subdivision, appropriated for Drainage purposes per the Shire of Berwick. It runs along the north boundary per the DELWP easements map. South East Water shows no SEW-specific encumbrances in the water information statement. Do not build over or within 1m of this easement without prior approval from Casey Council and South East Water. Confirm exact location and width with a licensed surveyor before any building or extension works near the north boundary.",
        category: "legal",
        keywords: ["easement", "drainage", "build", "boundary", "restriction", "north", "LP57254"],
      },
      {
        question: "What owner builder works were done and what did the inspection find?",
        answer: "The vendors completed owner-builder alterations to the ensuite, main bathroom and laundry approximately 3 years ago (~2023). These works did not require a building permit (confirmed in s137B report and Casey building certificate). Owner Builder Inspection Report (s137B, Job BI 1087-1, Glenn Dornbusch IN-U 1140, 02/05/2026) found: no structural defects; overall condition Average; workmanship Average. Minor maintenance items only: (1) caulking required to 3 wall and timber beading joints in main bathroom; (2) minor wall cracks in 2 sections of ensuite — fill and paint required. Sub-floor area and waterproofing were inaccessible at inspection.",
        category: "physical",
        keywords: ["owner builder", "renovation", "bathroom", "ensuite", "laundry", "inspection", "defects", "works", "permit", "s137B"],
      },
      {
        question: "Is the property in a bushfire prone area and does the BMO apply?",
        answer: "Yes — the property is in a Designated Bushfire Prone Area (BPA) under s192A of the Building Act 1993 (confirmed S32 section 3.3 ☒ and DELWP BPA layer updated 09/03/2026). Any new building works requiring a permit must comply with BAL (Bushfire Attack Level) construction standards — obtain a BAL assessment before planning any significant additions or extensions. However, the Bushfire Management Overlay (BMO) planning overlay does NOT apply to this specific lot (BMO is Unaffected per Landchecker, 09/03/2026). The BPA is a building regulation designation, not a planning overlay.",
        category: "planning",
        keywords: ["bushfire", "BPA", "BAL", "fire", "prone", "overlay", "BMO", "bushfire prone area", "construction standard"],
      },
      {
        question: "What is the zoning and are there any planning overlays?",
        answer: "GRZ — General Residential Zone — Schedule 1 (Casey Planning Scheme). No planning overlays apply to this property (Property Report: 'There are no overlays for this property'). GRZ1 encourages housing diversity and growth in locations with good access to services and transport, and permits single dwellings, dual occupancy, and residential uses. Nearby overlays (SLO, BMO, HO, DPO) do NOT affect this lot.",
        category: "planning",
        keywords: ["zone", "zoning", "GRZ", "overlay", "overlays", "planning", "residential", "general residential", "GRZ1"],
      },
      {
        question: "What is the subdivision potential of this property?",
        answer: "Strong potential — TBD for formal assessment. Positive indicators: GRZ1 zone, 790 sqm, 19.23m frontage, rectangular lot, no planning overlays, no restrictive covenant. Precedent on Manuka Road is strong: 39 Manuka Rd — 3-lot approved 2024; 35 Manuka Rd — 3-lot approved 2021-22; 34 Manuka Rd — 2-lot approved 2020. Aboriginal Cultural Heritage Sensitivity applies in the vicinity — a CHMP may be required for significant ground disturbance. Recommend a formal town planner assessment and pre-application meeting with Casey Council.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "potential", "develop", "development", "lots", "split", "GRZ", "2-lot", "3-lot"],
      },
      {
        question: "Is there granny flat or dual occupancy potential?",
        answer: "TBD — requires formal planning assessment. No title-level restrictions prevent secondary dwellings (no restrictive covenant — unlike 34 Hartsmere which has Covenant AB543185A limiting to single dwelling). GRZ1, 790 sqm and no overlays are positive indicators for granny flat (Dependent Persons Unit) and dual occupancy potential. VC304 (22/03/2026) extended temporary DPU provisions. Recommend assessment by a Casey-experienced town planner.",
        category: "planning",
        keywords: ["granny flat", "DPU", "dual occupancy", "second dwelling", "secondary", "dependent persons unit"],
      },
      {
        question: "What is the land tax position for an investor?",
        answer: "Vendors exempt: PPOR (Land Tax cert 98967167, 01/05/2026, SV $795,000 — Colin Thomas MacLean, LTX Principal Place of Residence). Investor single ownership: $3,420 p.a. (SRO-calculated: $2,250 + ($795,000 - $600,000) x 0.600 cents). If purchased as tenants in common (50/50), each co-owner assessed on $397,500: each approximately $1,643 p.a. ($1,350 + $97,500 x 0.300%). Vacant residential land tax: $9,150 p.a. (CIV $915,000 x 1%). No CIPT (AVPCC 110). No WGT.",
        category: "financial",
        keywords: ["land tax", "investor", "tax", "PPOR", "exempt", "annual", "holding cost", "CIPT", "WGT", "$3,420"],
      },
      {
        question: "What are the council rates and does a pensioner rebate apply?",
        answer: "Annual council rates FY2026: $2,769.03 (General Rates $2,006.73 + Garbage Charge $468.00 + ESVF Levy $294.30). The current owners receive a pensioner rebate of $316.00 — this is personal to them as concession card holders and does NOT transfer to a new owner. A purchaser without pensioner status pays the full $2,769.03. Balance outstanding as at LIC (04/05/2026): $301.25 — adjustable at settlement. Council property number: 21980. CIV: $915,000, SV: $795,000.",
        category: "financial",
        keywords: ["council rates", "rates", "pensioner", "rebate", "discount", "balance", "outstanding", "$2,769", "FY2026"],
      },
      {
        question: "Is there a pool or spa on the property?",
        answer: "No — no evidence of a pool or spa. There is no SC12 (Swimming Pool/Spa Special Condition) in the COS (unlike 34 Hartsmere Drive which included SC12). No building permit for pool construction in last 10 years. No pool or spa mentioned in the owner builder inspection report. The Casey building certificate pool note is standard boilerplate included on all Casey certificates. Confirm at inspection.",
        category: "features",
        keywords: ["pool", "spa", "swimming pool", "pool fence", "SC12"],
      },
      {
        question: "What services are connected to the property?",
        answer: "Electricity, gas, water and sewerage all connected (S32 section 8 — boxes unmarked = connected). Telephone landline NOT connected (box marked ☒ — no practical impact given NBN availability). No recycled water main available (recycled water asset map shows no service). South East Water services the property — 100 UPVC-CL12 water main from 19/05/1983 runs along Manuka Road; 225 UPVC sewer main runs along Manuka Road.",
        category: "physical",
        keywords: ["services", "gas", "electricity", "water", "sewerage", "NBN", "telephone", "internet", "recycled water", "connected"],
      },
      {
        question: "Is the property subject to flooding?",
        answer: "No. Melbourne Water confirms property not subject to flooding based on a 1-in-100-year flood probability (SEW Information Statement 01/05/2026). All DELWP flood designations (FO, FO1, FO2, FO3) and all storm/inundation overlays (LSIO, RFO, SBO, UFZ etc.) are Unaffected (Landchecker flood report, updated 23/02/2026). No Flood Overlay or Land Subject to Inundation Overlay (LSIO) applies.",
        category: "planning",
        keywords: ["flood", "flooding", "inundation", "LSIO", "Melbourne Water", "water risk", "1-in-100"],
      },
      {
        question: "Is there Aboriginal cultural heritage sensitivity?",
        answer: "Yes. Property Report (07/05/2026) confirms the property is within, or in the vicinity of, one or more areas of Aboriginal cultural heritage sensitivity. For development activities involving significant ground disturbance (excavation, foundations, major earthworks), a Cultural Heritage Management Plan (CHMP) may be required under the Aboriginal Heritage Act 2006. Confirm requirements with Casey Council and the relevant Registered Aboriginal Party before commencing any significant ground disturbing works.",
        category: "planning",
        keywords: ["cultural heritage", "aboriginal", "CHMP", "indigenous", "heritage sensitivity", "ground disturbance", "heritage"],
      },
      {
        question: "What is the nearby development activity?",
        answer: "Active subdivision pressure on Manuka Road: 39 Manuka Rd — 3-lot approved 2024 (PA23-0562); 35 Manuka Rd — 3-lot approved 2021-22; 34 Manuka Rd — 2-lot approved 2020. 42-52 Manuka Road (open land to the east — currently adjacent): multi-lot residential subdivision PENDING (PA25-0524, received 26/08/2025). If approved, this will materially change the outlook to the east and increase neighbourhood density. 54-60 Manuka Road: restaurant and cafe use pending (PA25-0761).",
        category: "planning",
        keywords: ["development", "nearby", "subdivision", "42-52", "Manuka", "planning permit", "outlook", "density"],
      },
      {
        question: "What is the Section 32 status?",
        answer: "Vendor Statement signed by both vendors (Colin Thomas MacLean and Leanne Joy Hein) on 08/05/2026. Purchaser not yet signed. Prepared by Ideal Conveyancing (Robyn Clarke, Ref 13910). Planning certificate (s199) is included via the Property Report (Landchecker/Ideal Conveyancing, 07/05/2026) — confirms GRZ1, no overlays. Owner builder s137B report (02/05/2026) included. All required certificates present: Land Tax, CIPT, WGT, VicRoads, Casey Building Cert, Land Information Certificate, SEW Information Statement.",
        category: "legal",
        keywords: ["s32", "section 32", "vendor statement", "signed", "ready", "status", "contract", "settlement", "complete"],
      },
      {
        question: "Are there any outstanding rates balances at settlement?",
        answer: "Council rates balance outstanding: $301.25 as at LIC date (04/05/2026) — adjustable at settlement under s175(1) Local Government Act 1989. South East Water total unpaid balance: $176.08 as at 01/05/2026 (full Apr-Jun 2026 quarter service charges). Both amounts are adjustable at settlement. Confirm balances closer to settlement date as interest accrues.",
        category: "financial",
        keywords: ["outstanding", "rates", "balance", "owe", "paid", "settlement", "adjustable", "council", "water"],
      },
      {
        question: "Are there any VicRoads road acquisition proposals?",
        answer: "No proposals. VicRoads Roads Property Certificate (# 80415470, issued 01/05/2026): 'NO PROPOSALS — as at 1 May 2026, VicRoads has no approved proposals requiring any part of the property.' No road widening or acquisition affecting this property.",
        category: "planning",
        keywords: ["vicroads", "road", "acquisition", "proposal", "widening", "reserve", "roads"],
      },
      {
        question: "What are the key physical features and construction of the house?",
        answer: "1960s-era construction: brick veneer external walls, tiled roof, original timber floors throughout living areas, timber-framed windows, strip footings and stumps (sub-floor structure — sub-floor inaccessible at s137B inspection). Owner-builder renovation ~2023 covered ensuite, main bathroom and laundry — modern frameless shower screens, floating vanities, tiled wet areas. Inspection photos (s137B, 02/05/2026) show open-plan living/kitchen with sliding door to rear garden and original timber floors. Overall condition: Average.",
        category: "physical",
        keywords: ["construction", "brick veneer", "timber floors", "features", "1960s", "stumps", "roof", "tile", "sub-floor", "renovation"],
      },
      {
        question: "When was the property acquired and what is the ownership history?",
        answer: "Colin Thomas MacLean and Leanne Joy Hein acquired as tenants in common (1/2 share each) on 03/12/2001 (X922227Q). Property derives from parent title Vol 8305 Folio 331 — a Crown Allotment first subdivided by LP57254 in 1962-63. Both vendors have lived at this address since acquisition — PPOR for 24+ years as at 2026. At least one vendor holds a pensioner concession card (pensioner rebate of $316 applied to council rates). Prior purchase price not disclosed in the S32.",
        category: "financial",
        keywords: ["ownership", "history", "acquired", "purchase", "when", "how long", "held", "pensioner", "CGT", "main residence", "PPOR"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 201 — 17 Grand Arch Way, Berwick (ACTIVE $1.1M-$1.25M)
  // -------------------------------------------------------------------------
  201: {
    propertyId: 201,
    address: "17 Grand Arch Way",
    suburb: "Berwick VIC 3806",
    status: "active",

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 680,
    houseSqm: 290,
    yearBuilt: 2006,
    propertyType: "House",
    frontageMetre: 18,
    depthMetre: 37,
    propertyShape: "Rectangular",
    orientation: "North-facing rear garden",
    pool: false,
    gardenSqm: 260,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 28,
    roofType: "Concrete tile",
    externalCladding: "Brick veneer with feature stone",
    construction: "Brick veneer, prestige Grand Arch estate build",
    floorplanConfig: "4 bed, 2 bath, master ensuite, theatre room, entertainers kitchen, formal and casual living, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "No registered easements on title — confirm with vendor conveyancer",
    covenants: "Grand Arch estate covenant: single dwelling, quality materials, no caravan storage",
    overlays: "No planning overlays",
    s32Status: "Section 32 in preparation",
    encumbrances: "Nil registered encumbrances — confirm with vendor conveyancer",
    ownerOccupied: true,
    zoning: "Neighbourhood Residential Zone (NRZ1)",
    rightOfWay: "None",
    sewerEasement: "No sewer easement on property boundaries — confirm with Land Use Victoria",
    contaminatedLand: false,
    buildingPermitsOutstanding: "No outstanding permits — ensuite renovation permit finalled 2023",
    ownerBuilderWork: false,
    titlesOfficeReady: false,
    section32CompletionDate: "Expected within 2 weeks of vendor instruction",

    // FINANCIAL
    priceMin: 1100000,
    priceMax: 1250000,
    vendorReserve: "TBD",
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 540,
    rentalAppraisalHigh: 600,
    grossYieldAtAsk: 2.50,
    councilRates: 2000,
    waterRates: 910,
    bodyCorporateFees: 0,
    stampDutyEstimate: 66000,
    landTaxThreshold: "Above threshold for investors",
    depreciationYear1Est: 10500,
    capitalGainsHistory: "Owner-occupied since 2006 — CGT main residence exemption likely applies, confirm with vendor accountant",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School",
    primarySchoolRating: "Above average (MySchool rating 7/10)",
    secondarySchool: "Berwick Secondary College",
    secondarySchoolRating: "7.5/10 (MySchool)",
    schoolZoneCatchment: "Berwick Primary School, Berwick Secondary College. Walking distance to Berwick Grammar.",
    distanceToTrainKm: 0.9,
    trainLine: "Pakenham Line, Berwick Station",
    distanceToFreewayKm: 3.8,
    distanceToShoppingKm: 1.6,
    nearestHospitalKm: 4.0,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "8 Grand Arch Way, Berwick", price: 1210000, date: "Feb 2026", beds: 4 },
      { address: "5 Ascot Rise, Berwick", price: 1300000, date: "Apr 2026", beds: 4 },
      { address: "12 Ascot Rise, Berwick", price: 1270000, date: "Jan 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Entertainers kitchen with stone benchtops, 900mm oven, walk-in pantry, island bench",
    bathroomRenovated: "Master ensuite fully renovated 2023, main bathroom updated 2021",
    flooringType: "Engineered timber in living areas, plush carpet in bedrooms",
    airConType: "Ducted refrigerated cooling (Daikin)",
    heatingType: "Ducted gas heating",
    solarKw: 6.6,
    batteryStorage: false,
    evCharging: false,
    nbnType: "NBN FTTP (Fibre to the Premises)",
    waterTank: true,
    alarmSystem: true,
    smartHome: true,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Alfresco 28sqm, north-facing rear garden, established gardens, feature lighting",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Room for pool addition in north-facing rear garden, subject to council approval",
    councilDevelopmentHistory: "Ensuite reno permit 2023, no outstanding permits",
    neighbourhoodDescription: "Premium Grand Arch estate, one of Berwick's most sought-after addresses. Tree-lined boulevard, executive homes throughout.",
    trafficNoiseLevel: "Low, quiet residential street within estate",
    flightPathFlag: false,
    futureInfrastructure: "Berwick Station precinct upgrade in planning stages",
    floodZone: false,
    vendorMotivation: "Upsizing — vendor purchasing a larger property, motivated for clean sale",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "No reductions, new listing",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A",
    vendorPreferredSettlement: "60 days preferred",
    vendorFlexOnInclusions: "Open to discussion — confirm with Cameron before quoting to buyers",
    inclusions: "All light fittings, window coverings, dishwasher, outdoor feature lighting, water tank, alarm, smart home hub",

    qa: [
      {
        question: "What is the land size?",
        answer: "680 square metres, a well-proportioned block in the premium Grand Arch estate.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square"],
      },
      {
        question: "What is the house size?",
        answer: "Approximately 290 square metres of living space comprising 4 bedrooms, theatre room, entertainers kitchen, and formal and casual living areas.",
        category: "physical",
        keywords: ["house", "size", "area", "internal", "sqm", "living", "floor"],
      },
      {
        question: "Does it have a theatre room?",
        answer: "Yes. A dedicated theatre room is included in the floorplan.",
        category: "physical",
        keywords: ["theatre", "media", "room", "cinema", "entertainment", "floorplan"],
      },
      {
        question: "Is there outdoor entertaining?",
        answer: "Yes. A 28 square metre alfresco area opens to a north-facing rear garden with established gardens and feature lighting.",
        category: "physical",
        keywords: ["outdoor", "alfresco", "entertaining", "deck", "garden", "feature"],
      },
      {
        question: "What is the price range?",
        answer: "The property is listed with a price range of $1,100,000 to $1,250,000.",
        category: "financial",
        keywords: ["price", "range", "asking", "listed", "cost", "how much", "budget"],
      },
      {
        question: "What school zone is this property in?",
        answer: "Zoned for Berwick Primary School and Berwick Secondary College, and is within walking distance of Berwick Grammar.",
        category: "location",
        keywords: ["school", "zone", "catchment", "berwick", "grammar", "primary", "secondary"],
      },
      {
        question: "How far is the train station?",
        answer: "Berwick Station on the Pakenham Line is approximately 900 metres away, a comfortable walk.",
        category: "location",
        keywords: ["train", "station", "commute", "walk", "transport", "pakenham"],
      },
      {
        question: "How far is the freeway?",
        answer: "The Princes Freeway M1 is approximately 3.8km from Grand Arch Way.",
        category: "location",
        keywords: ["freeway", "m1", "princes", "highway", "motorway", "distance"],
      },
      {
        question: "How far to shopping?",
        answer: "Eden Rise with Coles is about 1.6km. Fountain Gate Westfield is approximately 8km.",
        category: "location",
        keywords: ["shopping", "shops", "eden rise", "coles", "westfield", "supermarket"],
      },
      {
        question: "How far is Casey Hospital?",
        answer: "Casey Hospital is approximately 4km from the property.",
        category: "location",
        keywords: ["hospital", "casey", "medical", "health", "emergency", "distance"],
      },
      {
        question: "What is the kitchen like?",
        answer: "An entertainers kitchen with stone benchtops, a 900mm oven, walk-in pantry, and island bench.",
        category: "features",
        keywords: ["kitchen", "bench", "appliance", "island", "pantry", "stone", "oven", "entertainers"],
      },
      {
        question: "What air conditioning is installed?",
        answer: "Ducted refrigerated cooling (Daikin) and ducted gas heating.",
        category: "features",
        keywords: ["air con", "ducted", "cooling", "heating", "daikin", "refrigerated", "climate"],
      },
      {
        question: "Is there solar?",
        answer: "Yes. A 6.6kW solar system is installed.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
      {
        question: "Is there a smart home system?",
        answer: "Yes. The property has a smart home hub for lighting and security control.",
        category: "features",
        keywords: ["smart home", "automation", "hub", "lighting", "control", "tech"],
      },
      {
        question: "What is the NBN connection?",
        answer: "NBN FTTP (Fibre to the Premises), the fastest residential NBN technology.",
        category: "features",
        keywords: ["nbn", "internet", "fibre", "fttp", "broadband", "connection"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "A property of this calibre in Grand Arch would rent for approximately $540 to $600 per week.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "What are the council rates?",
        answer: "Approximately $2,000 per year with Casey Council.",
        category: "financial",
        keywords: ["council", "rates", "annual", "per year", "fees"],
      },
      {
        question: "What stamp duty applies?",
        answer: "At the midpoint of $1.175M, stamp duty for an owner-occupier in Victoria is approximately $66,000.",
        category: "financial",
        keywords: ["stamp duty", "duty", "transfer", "government", "cost"],
      },
      {
        question: "Is there pool potential?",
        answer: "Yes. The north-facing rear garden has room for a pool subject to Casey Council approval.",
        category: "planning",
        keywords: ["pool", "swimming", "spa", "potential", "add", "rear"],
      },
      {
        question: "What is the vacancy rate in the suburb?",
        answer: "Berwick vacancy is running below 1.5%, well under the Melbourne metro average. Strong tenant demand driven by school catchments, train access, and family-friendly amenity.",
        category: "financial",
        keywords: ["vacancy", "vacant", "tenant", "demand", "rental", "market", "suburb"],
      },
      {
        question: "What are the comparable sales in the last 90 days?",
        answer: "3 sales in Grand Arch Way and surrounding courts in the last 90 days, ranging $940K to $1.27M. Average 28 days on market. The most recent was 8 Grand Arch Way at $1.21M in February 2026.",
        category: "financial",
        keywords: ["comparable", "comps", "sales", "sold", "recent", "90 days", "similar", "comparables"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No. The Grand Arch estate covenant restricts single dwelling only.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split"],
      },
      {
        question: "What is the neighbourhood like?",
        answer: "Premium Grand Arch estate, one of Berwick's most sought-after addresses. Tree-lined boulevard with executive homes throughout.",
        category: "planning",
        keywords: ["neighbourhood", "estate", "grand arch", "street", "suburb", "prestige"],
      },
      {
        question: "What inclusions are provided?",
        answer: "All light fittings, window coverings, dishwasher, outdoor feature lighting, water tank, alarm, and smart home hub.",
        category: "legal",
        keywords: ["inclusions", "included", "dishwasher", "alarm", "smart", "water tank"],
      },
      {
        question: "Is the Section 32 ready?",
        answer: "The Section 32 is currently in preparation. Confirm the expected completion date with the agent.",
        category: "legal",
        keywords: ["s32", "section 32", "contract", "vendor statement", "ready"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 202 — 12 Broadway Street, Berwick (ACTIVE $820K-$920K)
  // -------------------------------------------------------------------------
  202: {
    propertyId: 202,
    address: "12 Broadway Street",
    suburb: "Berwick VIC 3806",
    status: "active",

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 601,
    houseSqm: 230,
    yearBuilt: 2010,
    propertyType: "House",
    frontageMetre: 15,
    depthMetre: 40,
    propertyShape: "Rectangular",
    orientation: "West-facing front, private rear garden",
    pool: false,
    gardenSqm: 210,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 16,
    roofType: "Colorbond",
    externalCladding: "Brick veneer",
    construction: "Brick veneer, double garage",
    floorplanConfig: "4 bed, 2 bath, open plan living and dining, separate lounge, private rear garden, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "No registered easements identified — confirm with vendor conveyancer",
    covenants: "No estate covenants — General Residential Zone, standard title",
    overlays: "No planning overlays",
    s32Status: "Section 32 in preparation — expected within 2 weeks",
    encumbrances: "Nil registered encumbrances — confirm with vendor conveyancer",
    ownerOccupied: true,
    zoning: "General Residential Zone (GRZ1)",
    rightOfWay: "None",
    sewerEasement: "No sewer easement on property boundaries — confirm with Land Use Victoria",
    contaminatedLand: false,
    buildingPermitsOutstanding: "No outstanding building permits",
    ownerBuilderWork: false,
    titlesOfficeReady: false,
    section32CompletionDate: "Expected within 2 weeks of vendor instruction",

    // FINANCIAL
    priceMin: 820000,
    priceMax: 920000,
    vendorReserve: "TBD",
    settlementTermsDays: 45,
    depositPct: 10,
    rentalAppraisalLow: 490,
    rentalAppraisalHigh: 530,
    grossYieldAtAsk: 3.02,
    councilRates: 1800,
    waterRates: 900,
    bodyCorporateFees: 0,
    stampDutyEstimate: 46700,
    landTaxThreshold: "Above threshold for investors",
    depreciationYear1Est: 8000,
    capitalGainsHistory: "Owner-occupied since 2010 — CGT main residence exemption likely applies, confirm with vendor accountant",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School",
    primarySchoolRating: "Above average (MySchool rating 7/10)",
    secondarySchool: "Berwick Secondary College",
    secondarySchoolRating: "7.5/10 (MySchool)",
    schoolZoneCatchment: "Berwick Primary School, Berwick Secondary College",
    distanceToTrainKm: 0.7,
    trainLine: "Pakenham Line, Berwick Station",
    distanceToFreewayKm: 3.5,
    distanceToShoppingKm: 1.4,
    nearestHospitalKm: 4.1,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "3 Thirlmere Court, Berwick", price: 941000, date: "May 2026", beds: 4 },
      { address: "47 Premier Drive, Berwick", price: 1005000, date: "Apr 2026", beds: 4 },
      { address: "22 Fairway Drive, Berwick", price: 890000, date: "Jan 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Updated kitchen 2022, stone benchtops, stainless appliances",
    bathroomRenovated: "Both bathrooms updated 2022",
    flooringType: "Hybrid timber look flooring living areas, carpet bedrooms",
    airConType: "Ducted evaporative cooling",
    heatingType: "Ducted gas heating",
    solarKw: 3.0,
    batteryStorage: false,
    evCharging: false,
    nbnType: "NBN FTTN (Fibre to the Node)",
    waterTank: false,
    alarmSystem: false,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Covered alfresco 16sqm, private rear garden, low-maintenance lawn",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Potential to extend at rear within GRZ1 setbacks",
    councilDevelopmentHistory: "Kitchen and bathroom permit 2022, no outstanding permits",
    neighbourhoodDescription: "Quiet residential street close to Berwick Station and Berwick Village. Family-friendly neighbourhood with good walkability.",
    trafficNoiseLevel: "Low to moderate, Broadway Street is a residential street with some through traffic to station",
    flightPathFlag: false,
    futureInfrastructure: "Berwick Station precinct upgrade in planning",
    floodZone: false,
    vendorMotivation: "Downsizing — vendor relocating interstate, clean straightforward sale preferred",
    vendorTimelineDays: 45,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "New listing, no reductions",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A",
    vendorPreferredSettlement: "45 days preferred",
    vendorFlexOnInclusions: "Open to discussion — confirm with Cameron",
    inclusions: "All light fittings, window coverings, dishwasher, alfresco furniture",

    qa: [
      {
        question: "What is the land size?",
        answer: "601 square metres, a compact and manageable block close to Berwick Station.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square"],
      },
      {
        question: "What is the home size?",
        answer: "Approximately 230 square metres with 4 bedrooms, open plan living and dining, and a separate lounge.",
        category: "physical",
        keywords: ["house", "size", "area", "internal", "sqm", "living"],
      },
      {
        question: "Is there outdoor entertaining?",
        answer: "Yes. A covered alfresco of 16 square metres opens to a private rear garden.",
        category: "physical",
        keywords: ["outdoor", "alfresco", "entertaining", "private", "garden", "rear"],
      },
      {
        question: "What is the price range?",
        answer: "Listed at $820,000 to $920,000.",
        category: "financial",
        keywords: ["price", "range", "asking", "listed", "cost", "how much", "budget"],
      },
      {
        question: "What school zone is this in?",
        answer: "Zoned for Berwick Primary School and Berwick Secondary College.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "berwick"],
      },
      {
        question: "How close is the train station?",
        answer: "Berwick Station on the Pakenham Line is approximately 700 metres, a very easy walk.",
        category: "location",
        keywords: ["train", "station", "walk", "commute", "transport", "pakenham", "distance"],
      },
      {
        question: "How far is shopping?",
        answer: "Eden Rise with Coles is approximately 1.4km. Berwick Village shops are also close.",
        category: "location",
        keywords: ["shopping", "shops", "eden rise", "village", "coles", "supermarket"],
      },
      {
        question: "Has the kitchen been updated?",
        answer: "Yes. The kitchen was updated in 2022 with stone benchtops and stainless steel appliances.",
        category: "features",
        keywords: ["kitchen", "bench", "appliance", "renovated", "stone", "updated"],
      },
      {
        question: "Have the bathrooms been renovated?",
        answer: "Yes. Both bathrooms were updated in 2022.",
        category: "features",
        keywords: ["bathroom", "ensuite", "renovated", "updated", "bath"],
      },
      {
        question: "What type of air conditioning is there?",
        answer: "Ducted evaporative cooling and ducted gas heating.",
        category: "features",
        keywords: ["air con", "ducted", "cooling", "evaporative", "heating", "climate"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes. A 3kW solar system is installed.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "A 4-bedroom home in this location would rent for approximately $490 to $530 per week.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "What is the gross yield?",
        answer: "At the midpoint of $870K and $510 per week rental, the gross yield is approximately 3.0%, which is competitive for Berwick.",
        category: "financial",
        keywords: ["yield", "gross", "return", "investment", "income"],
      },
      {
        question: "What are the council rates?",
        answer: "Approximately $1,800 per year with Casey Council.",
        category: "financial",
        keywords: ["council", "rates", "annual", "per year", "fees"],
      },
      {
        question: "What stamp duty applies?",
        answer: "At the midpoint of $870K, stamp duty for an owner-occupier is approximately $46,700.",
        category: "financial",
        keywords: ["stamp duty", "duty", "transfer", "government", "cost"],
      },
      {
        question: "What is the zoning?",
        answer: "General Residential Zone GRZ1, which allows greater development flexibility than NRZ.",
        category: "legal",
        keywords: ["zone", "zoning", "planning", "grz", "residential"],
      },
      {
        question: "Are there easements or covenants?",
        answer: "No estate covenants on this property. No registered easements have been identified — confirm with vendor conveyancer on Section 32.",
        category: "legal",
        keywords: ["easement", "covenant", "restriction", "title", "legal"],
      },
      {
        question: "Is the Section 32 ready?",
        answer: "Section 32 is in preparation and expected within 2 weeks. Contact Cameron for the latest status.",
        category: "legal",
        keywords: ["s32", "section 32", "contract", "vendor statement", "ready"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No. The 601sqm lot and GRZ1 setbacks do not support subdivision in this precinct.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split"],
      },
      {
        question: "What are the inclusions?",
        answer: "All light fittings, window coverings, dishwasher, and outdoor furniture on the alfresco. Confirm final inclusions with Cameron at inspection.",
        category: "legal",
        keywords: ["inclusions", "included", "dishwasher", "blind", "curtain", "fittings"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 203 — 5 Ashfield Drive, Berwick (ACTIVE $1.35M-$1.49M)
  // -------------------------------------------------------------------------
  203: {
    propertyId: 203,
    address: "5 Ashfield Drive",
    suburb: "Berwick VIC 3806",
    status: "active",

    // PHYSICAL
    beds: 5,
    baths: 3,
    cars: 2,
    landSqm: 820,
    houseSqm: 380,
    yearBuilt: 2005,
    propertyType: "House",
    frontageMetre: 22,
    depthMetre: 37,
    propertyShape: "Rectangular",
    orientation: "North-facing rear with pool",
    pool: true,
    gardenSqm: 280,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 45,
    roofType: "Concrete tile",
    externalCladding: "Double brick with rendered feature panels",
    construction: "Double brick prestige construction",
    floorplanConfig: "5 bed, 3 bath, master ensuite, home theatre, formal lounge, open plan family and meals, alfresco, pool, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "No registered easements identified — confirm with vendor conveyancer",
    covenants: "No estate covenants — standard residential title",
    overlays: "No planning overlays",
    s32Status: "Section 32 in preparation",
    encumbrances: "Nil registered encumbrances — confirm with vendor conveyancer",
    ownerOccupied: true,
    zoning: "Neighbourhood Residential Zone (NRZ1)",
    rightOfWay: "None",
    sewerEasement: "No sewer easement on property boundaries — confirm with Land Use Victoria",
    contaminatedLand: false,
    buildingPermitsOutstanding: "No outstanding building permits — pool installation finalled 2007",
    ownerBuilderWork: false,
    titlesOfficeReady: false,
    section32CompletionDate: "Expected within 2 weeks of vendor instruction",

    // FINANCIAL
    priceMin: 1350000,
    priceMax: 1490000,
    vendorReserve: "TBD",
    settlementTermsDays: 90,
    depositPct: 10,
    rentalAppraisalLow: 650,
    rentalAppraisalHigh: 720,
    grossYieldAtAsk: 2.62,
    councilRates: 2200,
    waterRates: 950,
    bodyCorporateFees: 0,
    stampDutyEstimate: 82650,
    landTaxThreshold: "Above threshold for investors",
    depreciationYear1Est: 15000,
    capitalGainsHistory: "Owner-occupied since 2005 — CGT main residence exemption likely applies, confirm with vendor accountant",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School",
    primarySchoolRating: "Above average (MySchool rating 7/10)",
    secondarySchool: "Berwick Secondary College",
    secondarySchoolRating: "7.5/10 (MySchool)",
    schoolZoneCatchment: "Berwick Primary School, Berwick Secondary College. Proximity to Berwick Grammar and Nossal High School.",
    distanceToTrainKm: 1.0,
    trainLine: "Pakenham Line, Berwick Station",
    distanceToFreewayKm: 4.0,
    distanceToShoppingKm: 2.0,
    nearestHospitalKm: 4.3,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 32,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "11 Coach House Lane, Beaconsfield", price: 2110000, date: "May 2026", beds: 5 },
      { address: "5 Ascot Rise, Berwick", price: 1300000, date: "Apr 2026", beds: 4 },
      { address: "8 Grand Arch Way, Berwick", price: 1210000, date: "Feb 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Fully renovated 2021, 40mm stone benchtops, 900mm Smeg oven, butler's pantry, island bench with breakfast bar",
    bathroomRenovated: "Master ensuite renovated 2021, second bathroom renovated 2023, third bathroom original 2005",
    flooringType: "Solid timber floors living areas, plush carpet bedrooms",
    airConType: "Ducted refrigerated cooling (Daikin, 2021)",
    heatingType: "Ducted gas heating",
    solarKw: 8.0,
    batteryStorage: true,
    evCharging: true,
    nbnType: "NBN FTTP (Fibre to the Premises)",
    waterTank: true,
    alarmSystem: true,
    smartHome: true,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Alfresco 45sqm, heated inground pool, spa, established gardens, outdoor kitchen with BBQ",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Already maximised with pool and alfresco; scope for upper level addition subject to NRZ1 height limits",
    councilDevelopmentHistory: "Pool permit 2018, kitchen and bathroom reno permit 2021, no outstanding permits",
    neighbourhoodDescription: "Prestigious Ashfield Drive address, surrounded by executive homes. Walking distance to Berwick Grammar, Berwick Village, and Berwick Station.",
    trafficNoiseLevel: "Low, quiet residential street with excellent setback",
    flightPathFlag: false,
    futureInfrastructure: "Berwick Station precinct upgrade, Nossal High expansion. Strong long-term demand drivers.",
    floodZone: false,
    vendorMotivation: "Family transitioning — children grown, vendor looking to right-size to a prestige apartment",
    vendorTimelineDays: 90,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "New listing, no reductions",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A",
    vendorPreferredSettlement: "90 days preferred",
    vendorFlexOnInclusions: "Inclusions largely fixed given outdoor kitchen and pool equipment — confirm with Cameron",
    inclusions: "All light fittings, window coverings, dishwasher, outdoor kitchen, pool equipment, water tank, EV charger, alarm, smart home hub",

    qa: [
      {
        question: "What is the land size?",
        answer: "820 square metres, a generous block with room for the pool, alfresco, and established gardens.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square"],
      },
      {
        question: "What is the home size?",
        answer: "Approximately 380 square metres of living space including 5 bedrooms, 3 bathrooms, home theatre, formal lounge, and open plan family and meals areas.",
        category: "physical",
        keywords: ["house", "size", "area", "internal", "sqm", "living", "floor"],
      },
      {
        question: "Does it have a pool?",
        answer: "Yes. A heated inground pool and spa with a 45 square metre alfresco and outdoor kitchen.",
        category: "physical",
        keywords: ["pool", "swimming", "spa", "heated", "inground"],
      },
      {
        question: "Is there outdoor entertaining?",
        answer: "Yes. A 45 square metre alfresco with an outdoor kitchen and BBQ, overlooking the pool and landscaped gardens.",
        category: "physical",
        keywords: ["outdoor", "alfresco", "entertaining", "bbq", "kitchen", "pool", "garden"],
      },
      {
        question: "What is the construction type?",
        answer: "Double brick prestige construction with rendered feature panels, built in 2005.",
        category: "physical",
        keywords: ["construction", "brick", "double brick", "quality", "build", "materials"],
      },
      {
        question: "What is the price range?",
        answer: "Listed at $1,350,000 to $1,490,000.",
        category: "financial",
        keywords: ["price", "range", "asking", "listed", "cost", "how much", "budget"],
      },
      {
        question: "What school zone is this property in?",
        answer: "Zoned for Berwick Primary School and Berwick Secondary College. It is also close to Berwick Grammar and Nossal High School.",
        category: "location",
        keywords: ["school", "zone", "catchment", "berwick", "grammar", "nossal", "primary", "secondary"],
      },
      {
        question: "How far is the train station?",
        answer: "Berwick Station on the Pakenham Line is approximately 1km from Ashfield Drive.",
        category: "location",
        keywords: ["train", "station", "commute", "walk", "transport", "pakenham"],
      },
      {
        question: "How far is the freeway?",
        answer: "The Princes Freeway M1 is approximately 4km from the property.",
        category: "location",
        keywords: ["freeway", "m1", "princes", "highway", "motorway", "distance"],
      },
      {
        question: "What is the suburb growth rate?",
        answer: "Berwick has delivered approximately 28% median price growth over the past 5 years, supported by strong school zones and infrastructure.",
        category: "location",
        keywords: ["growth", "capital", "appreciation", "suburb", "5 year", "market"],
      },
      {
        question: "What is the kitchen like?",
        answer: "Fully renovated in 2021 with 40mm stone benchtops, 900mm Smeg oven, butler's pantry, and island bench with breakfast bar.",
        category: "features",
        keywords: ["kitchen", "bench", "smeg", "oven", "butler", "pantry", "island", "stone", "renovated"],
      },
      {
        question: "What is the air conditioning setup?",
        answer: "Ducted refrigerated cooling (Daikin, installed 2021) and ducted gas heating throughout.",
        category: "features",
        keywords: ["air con", "ducted", "cooling", "daikin", "heating", "refrigerated", "climate"],
      },
      {
        question: "Is there solar power and battery storage?",
        answer: "Yes. An 8kW solar system with battery storage is installed, plus an EV charger in the garage.",
        category: "features",
        keywords: ["solar", "battery", "ev", "charger", "energy", "electricity", "kw", "storage"],
      },
      {
        question: "Is there a smart home system?",
        answer: "Yes. Smart home system covering lighting, security, and climate control.",
        category: "features",
        keywords: ["smart home", "automation", "hub", "control", "lighting", "tech"],
      },
      {
        question: "What is the NBN type?",
        answer: "NBN FTTP (Fibre to the Premises), the fastest available technology.",
        category: "features",
        keywords: ["nbn", "internet", "fibre", "fttp", "broadband", "connection"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "A 5-bedroom prestige home with pool in this location would rent for approximately $650 to $720 per week.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week"],
      },
      {
        question: "What are the council rates?",
        answer: "Approximately $2,200 per year with Casey Council.",
        category: "financial",
        keywords: ["council", "rates", "annual", "per year", "fees"],
      },
      {
        question: "What stamp duty applies?",
        answer: "At the midpoint of $1.42M, stamp duty for an owner-occupier is approximately $82,650.",
        category: "financial",
        keywords: ["stamp duty", "duty", "transfer", "government", "cost"],
      },
      {
        question: "Are there any overlays?",
        answer: "No planning overlays apply to this property.",
        category: "legal",
        keywords: ["overlay", "overlays", "heritage", "bushfire", "eso", "planning"],
      },
      {
        question: "Is the Section 32 ready?",
        answer: "The Section 32 is currently in preparation. Confirm the expected completion date with the agent.",
        category: "legal",
        keywords: ["s32", "section 32", "contract", "vendor statement", "ready"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No. NRZ1 zoning and the existing pool and alfresco footprint preclude subdivision.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split"],
      },
      {
        question: "Is there an EV charger?",
        answer: "Yes. An EV charger is installed in the double garage.",
        category: "features",
        keywords: ["ev", "charger", "electric vehicle", "tesla", "charge", "garage"],
      },
      {
        question: "What inclusions are provided?",
        answer: "All light fittings, window coverings, dishwasher, outdoor kitchen, pool equipment, water tank, EV charger, alarm, and smart home hub.",
        category: "legal",
        keywords: ["inclusions", "included", "pool", "ev", "outdoor kitchen", "alarm", "smart"],
      },
    ],
  },

  // =========================================================================
  // PAS SUNILCHANDRA / AREA SPECIALIST — SE MELBOURNE PROPERTIES
  // =========================================================================

  // -------------------------------------------------------------------------
  // 301 — 58 Broadway Street, Berwick (SOLD $932K est., 14 May 2026)
  // Brand new 2025 Metricon build — sold price not publicly indexed, estimated from suburb median
  // -------------------------------------------------------------------------
  301: {
    propertyId: 301,
    address: "58 Broadway Street",
    suburb: "Berwick VIC 3806",
    status: "sold",
    soldDate: "14 May 2026",
    soldPrice: 932000,

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 612,
    houseSqm: "TBD",
    yearBuilt: 2025,
    propertyType: "House",
    frontageMetre: 17,
    depthMetre: 36,
    propertyShape: "Rectangular",
    orientation: "North-facing rear garden",
    pool: false,
    gardenSqm: "TBD",
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: "TBD",
    roofType: "Colorbond",
    externalCladding: "Brick veneer with render detail",
    construction: "Metricon new build (2025) — brick veneer",
    floorplanConfig: "4 bed, 2 bath, master ensuite, open plan living/dining, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "Drainage easement along rear boundary",
    covenants: "Estate covenant: single dwelling, no caravan or boat storage",
    overlays: "No planning overlays",
    s32Status: "Section 32 issued",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "Neighbourhood Residential Zone (NRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "April 2026",

    // FINANCIAL
    priceMin: 932000,
    priceMax: 932000,
    vendorReserve: "TBD",
    settlementTermsDays: 45,
    depositPct: 10,
    rentalAppraisalLow: 510,
    rentalAppraisalHigh: 550,
    grossYieldAtAsk: 3.07,
    councilRates: 1900,
    waterRates: 950,
    bodyCorporateFees: 0,
    stampDutyEstimate: 50870,
    landTaxThreshold: "Above threshold for investment properties; land tax applies",
    depreciationYear1Est: 7800,
    capitalGainsHistory: "Berwick median has grown approximately 26% over 5 years",

    // LOCATION & SUBURB
    primarySchool: "Berwick Chase Primary School or Berwick Fields Primary School (confirm via findmyschool.vic.gov.au)",
    primarySchoolRating: "TBD",
    secondarySchool: "Berwick College (confirm via findmyschool.vic.gov.au)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Berwick — confirm exact catchment at findmyschool.vic.gov.au",
    distanceToTrainKm: 1.4,
    trainLine: "Pakenham Line (Berwick Station)",
    distanceToFreewayKm: 3.2,
    distanceToShoppingKm: 1.1,
    nearestHospitalKm: 4.3,
    suburb5yrGrowthPct: 26,
    suburbMedianPrice: 920000,
    daysOnMarketAvg: 28,
    clearanceRatePct: 68,
    comparableSales: [
      { address: "44 Broadway Street, Berwick", price: 918000, date: "Mar 2026", beds: 4 },
      { address: "71 Broadway Street, Berwick", price: 945000, date: "Jan 2026", beds: 4 },
      { address: "12 Highview Road, Berwick",   price: 905000, date: "Apr 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "As new — 2025 Metricon build with stone benchtops, stainless appliances",
    bathroomRenovated: "As new — 2025 build, modern fixtures throughout",
    flooringType: "TBD — new build",
    airConType: "TBD — confirm inclusions with Metricon build spec",
    heatingType: "TBD — confirm with build specification",
    solarKw: "TBD",
    batteryStorage: "TBD",
    evCharging: "TBD",
    nbnType: "FTTP (Fibre to the Premises — new build)",
    waterTank: "TBD",
    alarmSystem: "TBD",
    smartHome: "TBD",
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Alfresco, double garage with internal access — confirm dimensions",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Yes — NRZ1 allows extensions subject to council permit and setback compliance",
    councilDevelopmentHistory: "No building permits recorded in preceding 7 years",
    neighbourhoodDescription: "Established Berwick residential street with mix of family homes. Well-connected to Berwick village, train, and school zones. Broadway Street is a quiet local road.",
    trafficNoiseLevel: "Low — local residential street",
    flightPathFlag: false,
    futureInfrastructure: "Casey growth corridor. No road or infrastructure works directly impacting this property.",
    floodZone: false,
    vendorMotivation: "Vendor relocating interstate",
    vendorTimelineDays: 45,
    previousOffers: false,
    daysOnMarket: 22,
    priceReductionHistory: "None",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession",
    vendorPreferredSettlement: "45 days preferred",
    vendorFlexOnInclusions: "Flexible — discuss with agent",
    inclusions: "All fixed floor coverings, light fittings, window furnishings, dishwasher, alarm system",

    qa: [
      {
        question: "How big is the land?",
        answer: "612 square metres — rectangular block, 17m frontage by 36m deep. Good size for a Berwick family home.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "frontage", "depth"],
      },
      {
        question: "What school zone is this in?",
        answer: "Berwick Primary School catchment (approx 600m) and Kambrya College for secondary. One of the more sought-after school zones in the Casey area. Confirm exact catchment with Casey Council.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "kambrya", "berwick", "education"],
      },
      {
        question: "How far is the train station?",
        answer: "Berwick Station on the Pakenham Line is approximately 1.4km away — about a 17-minute walk or 4-minute drive. Direct service to the CBD.",
        category: "location",
        keywords: ["train", "station", "transport", "commute", "berwick station", "pakenham"],
      },
      {
        question: "What is the rental yield?",
        answer: "Rental appraisal is $510–$550 per week. At the $932K sale price that's approximately 2.9–3.1% gross yield. Strong rental demand in Berwick due to school zones.",
        category: "financial",
        keywords: ["rent", "rental", "yield", "investment", "income", "per week", "gross"],
      },
      {
        question: "What comparable sales are there nearby?",
        answer: "Recent sales on and near Broadway Street: 44 Broadway Street sold $918K (Mar 2026), 71 Broadway Street sold $945K (Jan 2026), 12 Highview Road sold $905K (Apr 2026). All 4-bedroom homes.",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold nearby", "similar", "90 days", "comparable sales"],
      },
      {
        question: "Has the kitchen been renovated?",
        answer: "Yes — updated in 2019 with stone benchtops, stainless steel appliances, and a breakfast bar. Still presents very well.",
        category: "features",
        keywords: ["kitchen", "bench", "appliance", "renovated", "stone", "updated"],
      },
      {
        question: "Is there ducted air conditioning?",
        answer: "Yes — ducted reverse-cycle throughout the home, plus ducted gas heating. Very comfortable year-round.",
        category: "features",
        keywords: ["air con", "ducted", "cooling", "heating", "reverse cycle", "climate"],
      },
      {
        question: "What is the suburb median price?",
        answer: "Berwick's current median house price is approximately $920,000 for 4-bedroom homes. The suburb has shown approximately 26% growth over the past 5 years.",
        category: "location",
        keywords: ["suburb", "median", "price", "growth", "market", "berwick", "5 year"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No — NRZ1 zoning and the 612sqm lot size do not meet minimum subdivision requirements. Single dwelling only.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split", "develop"],
      },
      {
        question: "What are the council rates?",
        answer: "Casey Council rates approximately $1,900 per annum. Water rates approximately $950 per annum. No body corporate fees.",
        category: "financial",
        keywords: ["council", "rates", "annual", "fees", "outgoings", "water", "casey"],
      },
      {
        question: "What is the vacancy rate in the suburb?",
        answer: "Berwick has a very low vacancy rate of approximately 1.1%, well below the Metro Melbourne average of 2.3%. Strong tenant demand driven by school zone families.",
        category: "financial",
        keywords: ["vacancy", "vacant", "vacancy rate", "tenant demand", "rental market"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes — a 3.2kW solar system is installed. Reduces electricity bills significantly.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 302 — 32 Seattle Crescent, Cranbourne North (SOLD $797K, 28 Apr 2026)
  // -------------------------------------------------------------------------
  302: {
    propertyId: 302,
    address: "32 Seattle Crescent",
    suburb: "Cranbourne North VIC 3977",
    status: "sold",
    soldDate: "28 Apr 2026",
    soldPrice: 797000,

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 476,
    houseSqm: 225,
    yearBuilt: 2015,
    propertyType: "House",
    frontageMetre: 14,
    depthMetre: 34,
    propertyShape: "Rectangular",
    orientation: "North-facing living areas",
    pool: false,
    gardenSqm: 160,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 18,
    roofType: "Colorbond",
    externalCladding: "Brick veneer with render detail",
    construction: "Brick veneer, estate builder (approximately 2015)",
    floorplanConfig: "4 bed, 2 bath, master ensuite with WIR, open plan kitchen/living/dining, alfresco, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "Drainage easement along rear boundary",
    covenants: "Estate covenant: single dwelling, facade approval required for extensions",
    overlays: "No planning overlays",
    s32Status: "Section 32 issued",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "General Residential Zone (GRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "March 2026",

    // FINANCIAL
    priceMin: 797000,
    priceMax: 797000,
    vendorReserve: "TBD",
    settlementTermsDays: 45,
    depositPct: 10,
    rentalAppraisalLow: 450,
    rentalAppraisalHigh: 490,
    grossYieldAtAsk: 2.93,
    councilRates: 1700,
    waterRates: 900,
    bodyCorporateFees: 0,
    stampDutyEstimate: 42890,
    landTaxThreshold: "Above threshold for investment properties; land tax applies",
    depreciationYear1Est: 9500,
    capitalGainsHistory: "Cranbourne North median has grown approximately 34% over 5 years",

    // LOCATION & SUBURB
    primarySchool: "Cranbourne North Primary School (approx 400m)",
    primarySchoolRating: "TBD",
    secondarySchool: "Cranbourne Secondary College (approx 2.8km)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Cranbourne North Primary School and Cranbourne Secondary College — confirm with Casey Council",
    distanceToTrainKm: 3.8,
    trainLine: "Cranbourne Line (Merinda Park Station approx 3.8km)",
    distanceToFreewayKm: 4.1,
    distanceToShoppingKm: 2.2,
    nearestHospitalKm: 6.4,
    suburb5yrGrowthPct: 34,
    suburbMedianPrice: 790000,
    daysOnMarketAvg: 31,
    clearanceRatePct: 62,
    comparableSales: [
      { address: "18 Seattle Crescent, Cranbourne North", price: 784000, date: "Feb 2026", beds: 4 },
      { address: "7 Portland Drive, Cranbourne North",    price: 810000, date: "Mar 2026", beds: 4 },
      { address: "41 Tullock Road, Cranbourne North",     price: 773000, date: "Jan 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Original 2015 kitchen — good condition with stone benchtops, 900mm oven, dishwasher",
    bathroomRenovated: "Original 2015 — well maintained, semi-frameless shower in ensuite",
    flooringType: "Tiles in living areas, carpet in bedrooms",
    airConType: "Ducted reverse-cycle throughout",
    heatingType: "Ducted gas heating",
    solarKw: 6.6,
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTC (Fibre to the Curb)",
    waterTank: false,
    alarmSystem: true,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Covered alfresco 18sqm, low-maintenance rear garden, double garage with internal access",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Limited — 476sqm block and estate covenant restrict significant extension. Side or rear additions may be feasible subject to council approval.",
    councilDevelopmentHistory: "No permits issued since construction in 2015",
    neighbourhoodDescription: "Established estate in Cranbourne North with modern family homes. Quiet crescent location. Walking distance to Cranbourne North Primary School and local reserves.",
    trafficNoiseLevel: "Low — quiet crescent with no through traffic",
    flightPathFlag: false,
    futureInfrastructure: "South-east corridor growth area — road upgrades and community facilities planned in Cranbourne North growth precincts.",
    floodZone: false,
    vendorMotivation: "Vendor upsizing to larger home",
    vendorTimelineDays: 45,
    previousOffers: false,
    daysOnMarket: 28,
    priceReductionHistory: "None",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession",
    vendorPreferredSettlement: "45–60 days",
    vendorFlexOnInclusions: "Dishwasher and window coverings included",
    inclusions: "All fixed floor coverings, light fittings, window coverings, dishwasher, alarm",

    qa: [
      {
        question: "How big is the land?",
        answer: "476 square metres — 14m frontage by 34m deep. Manageable low-maintenance block, typical for Cranbourne North estates built post-2010.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "frontage", "depth"],
      },
      {
        question: "What school zone is this in?",
        answer: "Cranbourne North Primary School (approx 400m walk) and Cranbourne Secondary College for Year 7–12. Confirm exact catchment with Casey Council on 03 9705 5190.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "cranbourne", "education"],
      },
      {
        question: "How far is the train station?",
        answer: "Merinda Park Station on the Cranbourne Line is approximately 3.8km away (about 8 minutes drive). Cranbourne Station is slightly further at approx 5km.",
        category: "location",
        keywords: ["train", "station", "transport", "commute", "cranbourne", "merinda park"],
      },
      {
        question: "What is the rental yield?",
        answer: "Rental appraisal is $450–$490 per week. At the $797K sale price that's approximately 2.9–3.2% gross yield. Cranbourne North has strong rental demand from families in the school zone.",
        category: "financial",
        keywords: ["rent", "rental", "yield", "investment", "income", "per week", "gross"],
      },
      {
        question: "What comparable sales are there nearby?",
        answer: "Recent comparable sales: 18 Seattle Crescent sold $784K (Feb 2026, 4-bed), 7 Portland Drive sold $810K (Mar 2026, 4-bed), 41 Tullock Road sold $773K (Jan 2026, 4-bed).",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold nearby", "90 days", "comparable sales"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes — a 6.6kW solar system is installed. One of the better systems for this price range; will meaningfully reduce electricity costs.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
      {
        question: "What is the vacancy rate in the suburb?",
        answer: "Cranbourne North vacancy rate is approximately 1.3%, below the Metro Melbourne average. Strong demand from families relocating to the area for schooling and affordability.",
        category: "financial",
        keywords: ["vacancy", "vacant", "vacancy rate", "tenant demand", "rental market"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No — the 476sqm lot and estate covenant restrict subdivision. GRZ1 zoning allows some flexibility but the block size and covenant make dual occupancy not viable.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "sub", "second dwelling", "split", "develop"],
      },
      {
        question: "What are the council rates?",
        answer: "Casey Council rates approximately $1,700 per annum. Water rates approximately $900 per annum. No body corporate fees — freestanding home.",
        category: "financial",
        keywords: ["council", "rates", "annual", "fees", "outgoings", "water", "body corporate"],
      },
      {
        question: "Has the kitchen been renovated?",
        answer: "Original 2015 kitchen — still in excellent condition with stone benchtops, 900mm stainless oven, and dishwasher. Modern build so no renovation needed.",
        category: "features",
        keywords: ["kitchen", "bench", "appliance", "renovated", "stone", "updated"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 303 — 20 Elwick Drive, Clyde North (SOLD $670K, 04 Feb 2026) — confirmed
  // Lot 2 PS747632 | Land 289sqm | Floor 124sqm | Built 2019 | Private sale
  // -------------------------------------------------------------------------
  303: {
    propertyId: 303,
    address: "20 Elwick Drive",
    suburb: "Clyde North VIC 3978",
    status: "sold",
    soldDate: "04 Feb 2026",
    soldPrice: 670000,

    // PHYSICAL
    beds: 3,
    baths: 2,
    cars: 1,
    landSqm: 289,
    houseSqm: 124,
    yearBuilt: 2019,
    propertyType: "House",
    frontageMetre: 12,
    depthMetre: 24.1,
    propertyShape: "Rectangular",
    orientation: "North-facing living",
    pool: false,
    gardenSqm: 80,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 10,
    roofType: "Colorbond",
    externalCladding: "Rendered brick veneer",
    construction: "Lightweight rendered brick, modern estate build",
    floorplanConfig: "3 bed, 2 bath, master ensuite with WIR, open plan kitchen/living/dining, alfresco, single garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "Drainage easement along rear boundary",
    covenants: "Estate covenant: facade approval for any modifications, no caravan storage",
    overlays: "No planning overlays",
    s32Status: "Section 32 issued",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "General Residential Zone (GRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "February 2026",

    // FINANCIAL
    priceMin: 670000,
    priceMax: 670000,
    vendorReserve: "TBD",
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 390,
    rentalAppraisalHigh: 425,
    grossYieldAtAsk: 3.11,
    councilRates: 1550,
    waterRates: 850,
    bodyCorporateFees: 0,
    stampDutyEstimate: 34250,
    landTaxThreshold: "Above threshold for investment properties",
    depreciationYear1Est: 11000,
    capitalGainsHistory: "Clyde North median has grown approximately 38% over 5 years from a low base",

    // LOCATION & SUBURB
    primarySchool: "Wilandra Rise Primary School or Grayling Primary School (confirm via findmyschool.vic.gov.au)",
    primarySchoolRating: "TBD",
    secondarySchool: "Clyde Secondary College (confirm catchment with Casey Council)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Clyde North — multiple new schools in area. Confirm at findmyschool.vic.gov.au",
    distanceToTrainKm: 7.2,
    trainLine: "No direct train. Nearest station: Merinda Park (approx 7.2km). Bus routes connect to Cranbourne Station.",
    distanceToFreewayKm: 2.8,
    distanceToShoppingKm: 3.1,
    nearestHospitalKm: 8.5,
    suburb5yrGrowthPct: 38,
    suburbMedianPrice: 650000,
    daysOnMarketAvg: 34,
    clearanceRatePct: 58,
    comparableSales: [
      { address: "8 Elwick Drive, Clyde North",     price: 638000, date: "Jan 2026", beds: 3 },
      { address: "45 Hartwell Blvd, Clyde North",   price: 665000, date: "Mar 2026", beds: 3 },
      { address: "19 Brightfield Way, Clyde North",  price: 643000, date: "Feb 2026", beds: 3 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "As new — original 2019 build, stone benchtops, 600mm oven, dishwasher",
    bathroomRenovated: "As new — original 2019 build, frameless shower in ensuite",
    flooringType: "Tiles throughout living areas, carpet in bedrooms",
    airConType: "Split-system in living area + master bedroom",
    heatingType: "Gas ducted heating",
    solarKw: 6.6,
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTP (Fibre to the Premises)",
    waterTank: false,
    alarmSystem: false,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Covered alfresco 12sqm, low-maintenance backyard, single garage with internal access",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Minimal — 392sqm with single garage limits rear extension. Side addition may be possible subject to council setback requirements.",
    councilDevelopmentHistory: "No permits issued since construction in 2019",
    neighbourhoodDescription: "Brand new Elara estate in Clyde North. Modern homes throughout, predominantly young families and first home buyers. Close to Clyde Creek Primary School and Clyde Grammar.",
    trafficNoiseLevel: "Low — local estate road with no through traffic",
    flightPathFlag: false,
    futureInfrastructure: "Significant infrastructure planned for Clyde North — new schools, retail precinct, and the proposed Clyde Rail Extension (long-term planning stage). Strong growth area.",
    floodZone: false,
    vendorMotivation: "First home buyers upgrading to larger home",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 19,
    priceReductionHistory: "None",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession",
    vendorPreferredSettlement: "60 days",
    vendorFlexOnInclusions: "Includes all window coverings and standard inclusions",
    inclusions: "All fixed floor coverings, light fittings, window coverings, dishwasher",

    qa: [
      {
        question: "How big is the land?",
        answer: "289 square metres — 12m frontage by approximately 24.1m deep (Lot 2 PS747632). Compact and very low maintenance — ideal for busy families or investors.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "frontage", "depth"],
      },
      {
        question: "What school zone is this in?",
        answer: "Clyde Creek Primary School is in the catchment (approx 800m). Clyde Grammar private school is approx 2km away. Secondary zoning to Cranbourne East SC — confirm with Casey Council.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "clyde", "grammar", "education"],
      },
      {
        question: "What is the rental yield?",
        answer: "Rental appraisal is $390–$420 per week. At the $651K sale price that's approximately 3.1–3.4% gross yield. Clyde North has strong rental demand as the area grows rapidly.",
        category: "financial",
        keywords: ["rent", "rental", "yield", "investment", "income", "per week", "gross", "appraisal"],
      },
      {
        question: "What comparable sales are there nearby?",
        answer: "Recent comparable sales in Clyde North: 8 Elwick Drive sold $638K (Jan 2026), 45 Hartwell Blvd sold $665K (Mar 2026), 19 Brightfield Way sold $643K (Feb 2026). All 3-bedroom homes.",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold nearby", "90 days", "comparable sales"],
      },
      {
        question: "Is there public transport nearby?",
        answer: "No direct train station nearby — nearest is Merinda Park approx 7.2km. Bus routes connect to Cranbourne Station. The Clyde Rail Extension is in long-term planning — timeframe uncertain.",
        category: "location",
        keywords: ["train", "bus", "transport", "commute", "station", "public transport"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes — a 6.6kW solar system. For a property this size that's excellent coverage. Reduces electricity costs significantly.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
      {
        question: "What is the vacancy rate in the suburb?",
        answer: "Clyde North vacancy rate is approximately 1.8% — slightly higher than inner suburbs due to rapid new supply, but demand remains strong from families and investors attracted by the growth story.",
        category: "financial",
        keywords: ["vacancy", "vacant", "vacancy rate", "tenant demand", "rental market"],
      },
      {
        question: "Is the property suitable for a first home buyer?",
        answer: "Yes — ideal entry-level property. At $651K it qualifies for stamp duty concessions for eligible FHBs. Modern 2019 build means no immediate maintenance costs. FHBG may also apply — confirm with your broker.",
        category: "financial",
        keywords: ["first home", "fhb", "stamp duty", "grant", "first home buyer", "entry level", "fhbg"],
      },
      {
        question: "What future infrastructure is planned nearby?",
        answer: "Clyde North is a significant growth area. New schools, a retail precinct, and long-term planning for a rail extension are all in various stages. Growth drivers are strong.",
        category: "planning",
        keywords: ["future", "infrastructure", "development", "rail", "growth", "clyde north", "planned"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 401 — 51 Hedgeville Drive, Officer (ACTIVE, $850K–$960K)
  // Custom 46+ square two-storey home. Land 391sqm. Also listed for rent at $370/wk.
  // -------------------------------------------------------------------------
  401: {
    propertyId: 401,
    address: "51 Hedgeville Drive",
    suburb: "Officer VIC 3809",
    status: "active",

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 391,
    houseSqm: 430,
    yearBuilt: "TBD",
    propertyType: "House",
    frontageMetre: "TBD",
    depthMetre: "TBD",
    propertyShape: "Rectangular",
    orientation: "TBD",
    pool: false,
    gardenSqm: 100,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: "TBD",
    roofType: "TBD",
    externalCladding: "TBD",
    construction: "Custom two-storey build — 46+ squares (~430 sqm internal), 6-star energy rating",
    floorplanConfig: "4 bed, 2 bath, master ensuite with freestanding bath + double vanity + WIR, multiple living areas, separate theatre, study, stone kitchen with butler's pantry + 900mm oven + island bench, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "Drainage easement along rear boundary",
    covenants: "Timbertop estate covenant: single dwelling, facade approval, no caravan storage",
    overlays: "No planning overlays",
    s32Status: "Section 32 in preparation",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "General Residential Zone (GRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "TBD",

    // FINANCIAL
    priceMin: 850000,
    priceMax: 960000,
    vendorReserve: "TBD",
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 550,
    rentalAppraisalHigh: 600,
    grossYieldAtAsk: 3.34,
    councilRates: 1950,
    waterRates: 950,
    bodyCorporateFees: 0,
    stampDutyEstimate: 48200,
    landTaxThreshold: "Above threshold for investment properties",
    depreciationYear1Est: 9800,
    capitalGainsHistory: "Officer median has grown approximately 32% over 5 years",

    // LOCATION & SUBURB
    primarySchool: "Officer Primary School (approx 900m)",
    primarySchoolRating: "TBD",
    secondarySchool: "Timbertop P-9 College or Officer Secondary College (approx 1.5km)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Officer Primary School and Officer Secondary College — confirm with Cardinia Council",
    distanceToTrainKm: 1.8,
    trainLine: "Pakenham Line (Officer Station)",
    distanceToFreewayKm: 2.4,
    distanceToShoppingKm: 1.4,
    nearestHospitalKm: 9.5,
    suburb5yrGrowthPct: 32,
    suburbMedianPrice: 760000,
    daysOnMarketAvg: 33,
    clearanceRatePct: 60,
    comparableSales: [
      { address: "37 Hedgeville Drive, Officer",    price: 762000, date: "Mar 2026", beds: 4 },
      { address: "14 Copperfield Way, Officer",     price: 785000, date: "Apr 2026", beds: 4 },
      { address: "23 Rosehaven Drive, Officer",     price: 754000, date: "Feb 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Premium — stone benchtops, 900mm freestanding oven, island bench, butler's pantry",
    bathroomRenovated: "Premium — freestanding bath in master ensuite, double vanity, oversized shower",
    flooringType: "TBD — confirm on inspection",
    airConType: "TBD — confirm with agent",
    heatingType: "TBD — confirm with agent",
    solarKw: "TBD",
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTP (Fibre to the Premises)",
    waterTank: false,
    alarmSystem: true,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Covered alfresco 20sqm, established garden, double garage with internal access",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Possible on 504sqm — side or rear extension subject to Cardinia Council permit and estate covenant approval",
    councilDevelopmentHistory: "No permits since 2017 construction",
    neighbourhoodDescription: "Timbertop estate in Officer — modern family precinct with wide streetscapes and established gardens. Close to Officer Station and Cardinia Road shopping. Strong community feel.",
    trafficNoiseLevel: "Low — estate road with no through traffic",
    flightPathFlag: false,
    futureInfrastructure: "Cardinia Road employment precinct development ongoing. Officer Station upgrading. Area earmarked for continued growth in Cardinia's Housing Strategy.",
    floodZone: false,
    vendorMotivation: "Vendor downsizing",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "None",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession",
    vendorPreferredSettlement: "60 days",
    vendorFlexOnInclusions: "Negotiable on inclusions",
    inclusions: "All fixed floor coverings, light fittings, window coverings, dishwasher, alarm system",

    qa: [
      {
        question: "How big is the land?",
        answer: "391 square metres. This is a custom two-storey home — the size of the land is deceptive because the home itself is 46+ squares (approximately 430 sqm internal across two levels). Very efficiently designed.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "frontage", "depth"],
      },
      {
        question: "What school zone is this in?",
        answer: "Officer Primary School (approx 900m) and Officer Secondary College for Year 7–12. Timbertop P-9 also nearby. Confirm exact catchment with Cardinia Council.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "officer", "timbertop", "education"],
      },
      {
        question: "How far is the train station?",
        answer: "Officer Station on the Pakenham Line is approximately 1.8km — about a 4-minute drive or 22-minute walk. Direct to the city.",
        category: "location",
        keywords: ["train", "station", "transport", "commute", "officer station", "pakenham"],
      },
      {
        question: "What is the rental yield?",
        answer: "Rental appraisal is $550–$600 per week (this is a 46+ square premium home — well above suburb median). At $905K mid-guide that's approximately 3.2–3.5% gross yield. Also currently available for rent at $370/week via Area Specialist — confirm current status.",
        category: "financial",
        keywords: ["rent", "rental", "yield", "investment", "income", "per week", "gross", "appraisal"],
      },
      {
        question: "What comparable sales are there nearby?",
        answer: "65 Hedgeville Drive (4/2/2) sold April 2021 for $650K — this gives a sense of the street. The subject property is a 46+ square custom build which commands a significant premium. Suburb median for Officer is approximately $752K for standard homes.",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold nearby", "90 days", "comparable sales"],
      },
      {
        question: "Is there a theatre room?",
        answer: "Yes — a dedicated separate theatre room is part of the floorplan. Ideal for families or a home office conversion.",
        category: "physical",
        keywords: ["theatre", "theater", "media room", "cinema", "study", "office"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes — 6.6kW solar system installed. Excellent for a 4-bedroom home — covers most daytime electricity usage.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
      {
        question: "What is the vacancy rate in Officer?",
        answer: "Officer vacancy rate is approximately 1.5%. Tenant demand is strong, particularly from families attracted by the school zones and proximity to the Pakenham Line.",
        category: "financial",
        keywords: ["vacancy", "vacant", "vacancy rate", "tenant demand", "rental market"],
      },
      {
        question: "Is there a butler's pantry?",
        answer: "Yes — the kitchen includes a butler's pantry, which is a standout feature at this price point. Great for storage and food prep.",
        category: "features",
        keywords: ["butler", "pantry", "kitchen", "storage", "walk-in pantry"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 402 — 8/59-61 Belgrave Hallam Road, Hallam (ACTIVE, $490K–$540K)
  // 2018 townhouse complex (~27 units). Previously leased $370/wk (Jan 2025).
  // -------------------------------------------------------------------------
  402: {
    propertyId: 402,
    address: "8/59-61 Belgrave Hallam Road",
    suburb: "Hallam VIC 3803",
    status: "active",

    // PHYSICAL
    beds: 2,
    baths: 1,
    cars: 1,
    landSqm: 162,
    houseSqm: 108,
    yearBuilt: 2018,
    propertyType: "Unit",
    frontageMetre: "TBD",
    depthMetre: "TBD",
    propertyShape: "Strata lot",
    orientation: "TBD",
    pool: false,
    gardenSqm: 28,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 14,
    roofType: "Colorbond",
    externalCladding: "Brick veneer",
    construction: "Brick veneer strata unit (one of approximately 10 in complex)",
    floorplanConfig: "2 bed, 1 bath, open plan kitchen/living, private courtyard, single garage",

    // LEGAL & TITLE
    titleType: "Strata Title",
    easements: "Common property easements — refer to plan of subdivision",
    covenants: "Owners corporation rules apply",
    overlays: "No planning overlays",
    s32Status: "Section 32 in preparation",
    encumbrances: "Owners Corporation",
    ownerOccupied: false,
    zoning: "General Residential Zone (GRZ1)",
    rightOfWay: "Common property access",
    sewerEasement: "Via common property",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None known",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "TBD",

    // FINANCIAL
    priceMin: 490000,
    priceMax: 540000,
    vendorReserve: "TBD",
    settlementTermsDays: 30,
    depositPct: 10,
    rentalAppraisalLow: 330,
    rentalAppraisalHigh: 360,
    grossYieldAtAsk: 3.57,
    councilRates: 1200,
    waterRates: 750,
    bodyCorporateFees: 1800,
    stampDutyEstimate: 25800,
    landTaxThreshold: "Lot 8 value well below land tax threshold with OC included",
    depreciationYear1Est: 7200,
    capitalGainsHistory: "Hallam unit median has grown approximately 22% over 5 years",

    // LOCATION & SUBURB
    primarySchool: "Hallam Primary School (approx 700m)",
    primarySchoolRating: "TBD",
    secondarySchool: "Hallam Senior Secondary College (approx 1.2km)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Hallam Primary School and Hallam Senior Secondary College — confirm with Casey Council",
    distanceToTrainKm: 1.1,
    trainLine: "Pakenham Line (Hallam Station approx 1.1km)",
    distanceToFreewayKm: 2.8,
    distanceToShoppingKm: 0.9,
    nearestHospitalKm: 3.4,
    suburb5yrGrowthPct: 22,
    suburbMedianPrice: 520000,
    daysOnMarketAvg: 38,
    clearanceRatePct: 55,
    comparableSales: [
      { address: "4/59-61 Belgrave Hallam Rd, Hallam", price: 502000, date: "Feb 2026", beds: 2 },
      { address: "3/12 Frawley Road, Hallam",           price: 495000, date: "Mar 2026", beds: 2 },
      { address: "7/72 Belgrave Hallam Road, Hallam",   price: 515000, date: "Jan 2026", beds: 2 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Updated 2021 — new benchtops, electric cooktop, dishwasher",
    bathroomRenovated: "Updated 2021 — new tiling and vanity",
    flooringType: "Timber laminate in living area, tiles in wet areas, carpet in bedrooms",
    airConType: "Split-system in main living area",
    heatingType: "Wall-mounted gas heater",
    solarKw: "TBD",
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTC (Fibre to the Curb)",
    waterTank: false,
    alarmSystem: false,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: false,
    outdoorFeatures: "Private courtyard 14sqm, lock-up single garage",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "No — strata title, owners corporation approval required for any modifications. No scope for extension.",
    councilDevelopmentHistory: "No individual permits — strata complex managed as a whole",
    neighbourhoodDescription: "Small well-maintained strata complex of approximately 10 units on Belgrave Hallam Road. Convenient location — walking distance to Hallam Station, shops, and schools. Established area.",
    trafficNoiseLevel: "Moderate — Belgrave Hallam Road is a main road; rear units are quieter",
    flightPathFlag: false,
    futureInfrastructure: "Hallam is an established suburb with limited major infrastructure changes planned. Benefiting from broader SE Melbourne growth.",
    floodZone: false,
    vendorMotivation: "Investor selling after 8-year hold",
    vendorTimelineDays: 30,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "None",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement",
    vendorPreferredSettlement: "30 days preferred",
    vendorFlexOnInclusions: "All white goods included",
    inclusions: "All fixed floor coverings, light fittings, window coverings, dishwasher, fridge (negotiable)",

    qa: [
      {
        question: "What are the body corporate fees?",
        answer: "Owners corporation fees are approximately $1,800 per annum ($450 per quarter). This covers building insurance, common property maintenance, and management. Confirm exact amount from the Section 32.",
        category: "financial",
        keywords: ["body corporate", "strata", "owners corp", "oc fees", "quarterly fees", "body corp"],
      },
      {
        question: "What is the rental yield?",
        answer: "Rental appraisal is $330–$360 per week. At $515K mid-guide that's approximately 3.3–3.6% gross yield. Hallam has reliable rental demand from workers near the Dandenong South industrial precinct.",
        category: "financial",
        keywords: ["rent", "rental", "yield", "investment", "income", "per week", "gross"],
      },
      {
        question: "How far is the train station?",
        answer: "Hallam Station on the Pakenham Line is approximately 1.1km — about a 13-minute walk. Very convenient for commuters to the city.",
        category: "location",
        keywords: ["train", "station", "transport", "commute", "hallam station", "pakenham"],
      },
      {
        question: "What comparable sales are there nearby?",
        answer: "Recent comparable sales: 4/59-61 Belgrave Hallam Rd sold $502K (Feb 2026), 3/12 Frawley Rd sold $495K (Mar 2026), 7/72 Belgrave Hallam Rd sold $515K (Jan 2026). All 2-bed units.",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold nearby", "90 days", "comparable sales"],
      },
      {
        question: "Is the property currently tenanted?",
        answer: "No — vacant possession at settlement. The property is available for immediate occupancy or a new tenancy.",
        category: "planning",
        keywords: ["tenant", "tenanted", "vacant", "possession", "occupied", "lease"],
      },
      {
        question: "What school zone is this in?",
        answer: "Hallam Primary School catchment (approx 700m) and Hallam Senior Secondary College for Year 7–12. Confirm with Casey Council.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "hallam", "education"],
      },
      {
        question: "Are pets allowed?",
        answer: "No — the owners corporation rules do not permit pets. Confirm the latest OC rules in the Section 32.",
        category: "legal",
        keywords: ["pets", "dogs", "cats", "animals", "allowed", "oc rules", "strata"],
      },
      {
        question: "Is there parking?",
        answer: "Yes — single lock-up garage included with the unit. Visitor parking in the complex.",
        category: "physical",
        keywords: ["parking", "garage", "car space", "lock-up", "visitor"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 403 — 12 Swallowtail Avenue, Clyde North (ACTIVE, $780K–$850K)
  // Berwick Waters Estate. Price guide confirmed via Area Specialist listing.
  // Comparable: 6 Swallowtail Ave (4/2/2) sold Jul 2025 $775K.
  // -------------------------------------------------------------------------
  403: {
    propertyId: 403,
    address: "12 Swallowtail Avenue",
    suburb: "Clyde North VIC 3978",
    status: "active",

    // PHYSICAL
    beds: 4,
    baths: 2,
    cars: 2,
    landSqm: 380,
    houseSqm: 228,
    yearBuilt: 2018,
    propertyType: "House",
    frontageMetre: 13.5,
    depthMetre: 33.2,
    propertyShape: "Rectangular",
    orientation: "North-facing living",
    pool: false,
    gardenSqm: 155,
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: 18,
    roofType: "Colorbond",
    externalCladding: "Rendered brick veneer",
    construction: "Brick veneer, Elara estate build",
    floorplanConfig: "4 bed, 2 bath, master ensuite with WIR, open plan kitchen/dining/living, home office/study nook, alfresco, double garage",

    // LEGAL & TITLE
    titleType: "Torrens Title",
    easements: "Drainage easement along rear boundary",
    covenants: "Berwick Waters estate covenant: single dwelling, facade approval, no caravan storage",
    overlays: "No planning overlays",
    s32Status: "Section 32 in preparation",
    encumbrances: "None",
    ownerOccupied: true,
    zoning: "General Residential Zone (GRZ1)",
    rightOfWay: "None",
    sewerEasement: "None",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "TBD",

    // FINANCIAL
    priceMin: 780000,
    priceMax: 850000,
    vendorReserve: "TBD",
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 460,
    rentalAppraisalHigh: 500,
    grossYieldAtAsk: 3.15,
    councilRates: 1600,
    waterRates: 880,
    bodyCorporateFees: 0,
    stampDutyEstimate: 41950,
    landTaxThreshold: "Above threshold for investment properties",
    depreciationYear1Est: 12000,
    capitalGainsHistory: "Clyde North median has grown approximately 38% over 5 years",

    // LOCATION & SUBURB
    primarySchool: "Wilandra Rise Primary School or Grayling Primary School (Berwick Waters estate — confirm via findmyschool.vic.gov.au)",
    primarySchoolRating: "TBD",
    secondarySchool: "Clyde Secondary College or Berwick College (approx 6km)",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Berwick Waters estate — confirm catchment at findmyschool.vic.gov.au",
    distanceToTrainKm: 7.0,
    trainLine: "No direct train. Nearest station: Merinda Park (approx 7km). Bus routes available to Cranbourne Station.",
    distanceToFreewayKm: 2.9,
    distanceToShoppingKm: 2.8,
    nearestHospitalKm: 8.1,
    suburb5yrGrowthPct: 38,
    suburbMedianPrice: 800000,
    daysOnMarketAvg: 36,
    clearanceRatePct: 56,
    comparableSales: [
      { address: "6 Swallowtail Avenue, Clyde North",   price: 775000, date: "Jul 2025", beds: 4 },
      { address: "15 Swallowtail Avenue, Clyde North",  price: 790000, date: "Mar 2026", beds: 4 },
      { address: "28 Larkin Way, Clyde North",           price: 808000, date: "Apr 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "As new — 2020 build, stone benchtops, 900mm oven, butler's pantry, dishwasher",
    bathroomRenovated: "As new — 2020 build, frameless shower in ensuite, freestanding bath in main",
    flooringType: "Tiles throughout living areas and wet areas, carpet in bedrooms",
    airConType: "Ducted reverse-cycle throughout",
    heatingType: "Ducted gas heating",
    solarKw: 6.6,
    batteryStorage: false,
    evCharging: false,
    nbnType: "FTTP (Fibre to the Premises)",
    waterTank: false,
    alarmSystem: false,
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Covered alfresco 18sqm, low-maintenance rear garden, double garage with internal access",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Limited — 448sqm block and estate covenant restrict major extensions. Minor rear addition may be possible.",
    councilDevelopmentHistory: "No permits since 2020 construction",
    neighbourhoodDescription: "Berwick Waters estate in Clyde North — one of Melbourne's fastest growing suburbs. Modern 2018 homes throughout, predominantly young families. Lake walking trails, Selandra Rise Shopping Centre approx 2km, Casey Fields nearby.",
    trafficNoiseLevel: "Very low — quiet estate street with no through traffic",
    flightPathFlag: false,
    futureInfrastructure: "Clyde North has multiple schools, a retail precinct, and a rail extension in long-term planning. One of Melbourne's most active growth corridors.",
    floodZone: false,
    vendorMotivation: "Vendor upgrading to larger family home",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "None",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession",
    vendorPreferredSettlement: "60 days",
    vendorFlexOnInclusions: "All inclusions standard — discuss specifics with agent",
    inclusions: "All fixed floor coverings, light fittings, window coverings, dishwasher",

    qa: [
      {
        question: "How big is the land?",
        answer: "448 square metres — 13.5m frontage by 33.2m deep. Modern efficient block in the Elara estate. North-facing living areas.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "frontage", "depth"],
      },
      {
        question: "What school zone is this in?",
        answer: "In the Berwick Waters estate — Wilandra Rise Primary School or Grayling Primary are likely catchment schools. Secondary: Clyde Secondary College or Berwick College. Confirm at findmyschool.vic.gov.au as school zones in Clyde North are evolving with the area's growth.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "clyde", "berwick waters", "education"],
      },
      {
        question: "What is the rental yield?",
        answer: "Rental appraisal is $460–$500 per week. At $805K mid-guide that's approximately 3.0–3.2% gross yield. Clyde North has strong rental demand from families who want to be in the area but aren't yet ready to buy.",
        category: "financial",
        keywords: ["rent", "rental", "yield", "investment", "income", "per week", "gross", "appraisal"],
      },
      {
        question: "What comparable sales are there nearby?",
        answer: "On the same street: 6 Swallowtail Avenue (4/2/2, same Berwick Waters estate) sold July 2025 for $775K. Also: 15 Swallowtail Avenue sold $790K (Mar 2026), 28 Larkin Way sold $808K (Apr 2026). The $780K–$850K guide is well-supported.",
        category: "financial",
        keywords: ["comparable", "comps", "recent sales", "sold nearby", "90 days", "comparable sales"],
      },
      {
        question: "Is there a butler's pantry?",
        answer: "Yes — the kitchen includes a butler's pantry. Excellent for a family who entertains. One of the standout features of this floorplan.",
        category: "features",
        keywords: ["butler", "pantry", "kitchen", "storage", "walk-in pantry", "entertaining"],
      },
      {
        question: "What future infrastructure is planned nearby?",
        answer: "Clyde North is one of Melbourne's most active growth corridors — new schools, retail precincts, and a long-term rail extension are in planning. The suburb's fundamentals are very strong for capital growth.",
        category: "planning",
        keywords: ["future", "infrastructure", "development", "rail", "growth", "clyde north", "planned"],
      },
      {
        question: "Is the property suitable for first home buyers?",
        answer: "Yes — eligible FHBs may qualify for stamp duty concessions and the FHBG on this property. At the lower end of the guide ($770K) it could come in under key thresholds. Confirm with your broker.",
        category: "financial",
        keywords: ["first home", "fhb", "stamp duty", "grant", "first home buyer", "entry level", "fhbg"],
      },
      {
        question: "Is there solar power?",
        answer: "Yes — 6.6kW solar installed. As a 2020 build it has one of the better solar specs. Significantly reduces electricity bills for a 4-bedroom home.",
        category: "features",
        keywords: ["solar", "panels", "energy", "electricity", "kw", "power"],
      },
      {
        question: "Is there ducted air conditioning?",
        answer: "Yes — ducted reverse-cycle throughout plus ducted gas heating. Full climate control in every room.",
        category: "features",
        keywords: ["air con", "ducted", "cooling", "heating", "reverse cycle", "climate"],
      },
      {
        question: "What is the vacancy rate in Clyde North?",
        answer: "Clyde North vacancy rate is approximately 1.8%. Demand remains strong from young families — the school options and growth story attract quality tenants.",
        category: "financial",
        keywords: ["vacancy", "vacant", "vacancy rate", "tenant demand", "rental market"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 601 — 10 Scenic Road, Warragul VIC 3820 (ACTIVE LISTING)
  // SLM data: Extracted from Section 32 Vendor Statement (SJD Law Conveyancing)
  // Title search produced 07/04/2026 | Planning report 07/04/2026
  // Title: Vol 11967 Fol 877 | Lot 2 PS819986H | Baw Baw Shire Council
  // Vendors: Richard Anthony Cimino & Anthony John Collins
  // -------------------------------------------------------------------------
  601: {
    propertyId: 601,
    address: "10 Scenic Road",
    suburb: "Warragul VIC 3820",
    status: "active",

    // PHYSICAL
    // Beds/baths/cars/houseSqm/yearBuilt not stated in S32 — marked TBD
    beds:              "TBD",
    baths:             "TBD",
    cars:              "TBD",
    landSqm:           1309,
    houseSqm:          "TBD",
    yearBuilt:         "TBD",
    propertyType:      "House",
    frontageMetre:     "TBD",
    depthMetre:        "TBD",
    propertyShape:     "Irregular — multi-sided polygon per Plan PS819986H Sheet 2. Perimeter 172m. Lot 2 of PS819986H — bounded by Scenic Road (north), adjacent to Warragul Linear Park Arts Discovery Trail / watercourse corridor (east), Hallyburton Grove (south) and Bronte Avenue (east).",
    orientation:       "TBD",
    pool:              true,
    gardenSqm:         "TBD",
    shed:              "TBD",
    outdoorEntertaining: "TBD",
    alfrescoSqm:       "TBD",
    roofType:          "TBD",
    externalCladding:  "TBD",
    construction:      "TBD — house pre-dates pool construction (pool built 24 January 2017). No building permits disclosed in preceding 7 years per vendor statement.",
    floorplanConfig:   "TBD",

    // LEGAL & TITLE
    titleType:         "Torrens — Volume 11967 Folio 877 (Lot 2 on Plan of Subdivision PS819986H). Standard Parcel Identifier: 2\\PS819986. Estate Fee Simple. Joint proprietors: Anthony John Collins (of Unit 10, 36 Peel Street, Berwick VIC 3806) and Richard Anthony Cimino (of 10 Scenic Road, Warragul VIC 3820). Instrument AR054983G dated 24/05/2018. Parent titles: Volume 11317 Folio 168 and Volume 11889 Folio 016. Created by plan instrument PS819986H registered 15/03/2018. No activity in last 125 days as at 07/04/2026.",
    easements:         "Six registered easement schedules per Plan PS819986H: E-1 gas supply (2m width, instrument V21169B, benefiting C/T Vol 9655 Fol 644) and power line (2m width, PS611739K, SPI Electricity Pty Ltd); E-2 power line (2m, PS611739K, SPI Electricity Pty Ltd); E-3 sewerage (see diagram, LP 135370, in favour of Lots on LP 135370) and pipeline or ancillary purposes (see diagram, PS611739K, Central Gippsland Region Water Corporation); E-4 drainage (2m, PS611739K, Lot 1 on PS611739K); E-5 sewerage (2m, PS611739K, Lot 1 on PS611739K); E-6 sewerage (2m, this plan, Lot 1 on PS819986H). Also: encumbrances created by Section 98 Transfer of Land Act 1958 and Section 24 Subdivision Act 1988 as shown on plan.",
    covenants:         "Nil — no registered covenants or Section 173 agreements disclosed in vendor statement.",
    overlays:          "DCPO1 (Development Contributions Plan Overlay — Schedule 1) and ESO4 (Environmental Significance Overlay — Schedule 4) both apply directly to this land. Floodway Overlay (FO) and Land Subject to Inundation Overlay (LSIO) exist in the vicinity but are NOT directly affecting this land (per Planning Property Report, 07/04/2026). Planning scheme data last updated 2 April 2026.",
    s32Status:         "Signed — vendors Richard Anthony Cimino and Anthony John Collins. Prepared by SJD Law Conveyancing. Title search produced 07/04/2026 10:07 AM (LANDATA). Planning Property Report 07/04/2026 09:41 AM.",
    encumbrances:      "Nil registered encumbrances, caveats or notices (NIL activity in last 125 days as at 07/04/2026). Encumbrances under Section 98 Transfer of Land Act 1958 / Section 24 Subdivision Act 1988 apply as shown on plan.",
    ownerOccupied:     true,
    zoning:            "GRZ1 — General Residential Zone Schedule 1 (Baw Baw Planning Scheme). Council: Baw Baw Shire. Council Property Number: 26809. Directory reference: Vicroads 704 E5.",
    rightOfWay:        "None disclosed in vendor statement.",
    sewerEasement:     "Yes — E-3 sewerage (Central Gippsland Region Water Corporation, see diagram on PS819986H), E-5 sewerage (2m, Lot 1 PS611739K) and E-6 sewerage (2m, Lot 1 PS819986H) are registered on title.",
    contaminatedLand:  false,
    buildingPermitsOutstanding: "Not Applicable — no building permits disclosed in preceding 7 years (vendor statement). Permanent swimming pool constructed 24 January 2017 (per Baw Baw Council permit records, pool registration SP-1337/19) — outside the 7-year disclosure window.",
    ownerBuilderWork:  false,
    titlesOfficeReady: true,
    section32CompletionDate: "07/04/2026",

    // FINANCIAL
    priceMin:             "TBD",
    priceMax:             "TBD",
    vendorReserve:        "TBD",
    settlementTermsDays:  "TBD",
    depositPct:           10,
    rentalAppraisalLow:   "TBD",
    rentalAppraisalHigh:  "TBD",
    grossYieldAtAsk:      "TBD",
    councilRates:         5000,
    waterRates:           "TBD",
    bodyCorporateFees:    0,
    stampDutyEstimate:    "TBD",
    landTaxThreshold:     "NOT land tax reform scheme land under the Commercial and Industrial Property Tax Reform Act 2024 Vic (CIPT Act) — confirmed in Section 1.5 of vendor statement (AVPC: n/a; land tax reform scheme: NO). Purchaser liability under the Land Tax Act 2005 (Vic) depends on intended use — investor purchasers should obtain advice.",
    depreciationYear1Est: "TBD",
    capitalGainsHistory:  "Vendors (Richard Anthony Cimino and Anthony John Collins) registered as joint proprietors by instrument AR054983G dated 24/05/2018. CGT position depends on vendor's acquisition cost, use, and applicable exemptions — confirm with vendor's accountant.",

    // LOCATION & SUBURB
    primarySchool:        "TBD — confirm with Baw Baw Shire Council",
    primarySchoolRating:  "TBD",
    secondarySchool:      "TBD — confirm with Baw Baw Shire Council",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment:  "TBD — confirm with Baw Baw Shire Council (www.bawbawshire.vic.gov.au)",
    distanceToTrainKm:    "TBD",
    trainLine:            "TBD — Warragul is on the Gippsland Line (Southern Cross to Traralgon); confirm distance from property",
    distanceToFreewayKm:  "TBD",
    distanceToShoppingKm: "TBD",
    nearestHospitalKm:    "TBD",
    suburb5yrGrowthPct:   "TBD",
    suburbMedianPrice:    "TBD",
    daysOnMarketAvg:      "TBD",
    clearanceRatePct:     "TBD",
    comparableSales:      "TBD",

    // FEATURES & CONDITION
    kitchenRenovated:     "TBD",
    bathroomRenovated:    "TBD",
    flooringType:         "TBD",
    airConType:           "TBD",
    heatingType:          "TBD",
    solarKw:              "TBD",
    batteryStorage:       "TBD",
    evCharging:           "TBD",
    nbnType:              "TBD",
    waterTank:            "TBD",
    alarmSystem:          "TBD",
    smartHome:            "TBD",
    disabilityAccess:     "TBD",
    petsAllowed:          "TBD",
    outdoorFeatures:      "Permanent swimming pool — construction date 24 January 2017 (per Baw Baw Shire Council permit records). Pool type: permanent swimming pool. Applicable barrier standard: AS 1926.1-2012 (deemed to satisfy Building Code of Australia). Pool barrier inspection completed 9 April 2024 by Ian Bruhn (IN-PS 69817), Bass Coast Pool Inspections — CERTIFIED COMPLIANT. Pool registered with Baw Baw Shire Council, registration number SP-1337/19. Next Certificate of Pool and Spa Barrier Compliance due no later than 18 April 2028. Council acknowledgement letter dated 18 April 2024 from Julian Bonnici, Municipal Building Surveyor, Baw Baw Shire Council.",

    // PLANNING & VENDOR
    subdivisionPotential:      false,
    dualOccupancyPotential:    "TBD",
    grannyFlatApproved:        "TBD",
    extensionPotential:        "Possible under GRZ1 subject to Baw Baw Council planning permit. Note ESO4 (Environmental Significance Overlay — Schedule 4) may trigger additional permit requirements for works near the watercourse corridor on the eastern boundary. DCPO1 may impose developer contributions. Contact Baw Baw Shire Council for current requirements.",
    councilDevelopmentHistory: "No building permits disclosed in preceding 7 years per vendor statement. Pool registered with council SP-1337/19, construction date 24 January 2017, pool barrier compliance certificate current as at April 2024. Council building services contact: (03) 5624 2411.",
    neighbourhoodDescription:  "Lot 2 of PS819986H — 1,309m² irregular residential block in Warragul, Baw Baw Shire. Fronts Scenic Road (north-west). Eastern boundary runs adjacent to the Warragul Linear Park Arts Discovery Trail / watercourse corridor. Southern boundary near Hallyburton Grove, south-east near Bronte Avenue. Western vicinity of Latrobe Street and Western Park Drive. Adjacent parcels include Lot 1 (944m², 6 Scenic Road). Public Park and Recreation Reserve (PPRZ) nearby. Predominantly residential zoning (GRZ1). No industrial (IN1Z) directly adjacent — nearest industrial zone visible to south-west on planning map. Located in Parish of Drouin East, Township of Warragul, Section 11, Crown Allotment 10 (part) & 11 (part). Baw Baw Shire Council. Country Fire Authority (CFA) fire authority. Gunaikurnai Land and Waters Aboriginal Country.",
    trafficNoiseLevel:         "TBD",
    flightPathFlag:            false,
    futureInfrastructure:      "DCPO1 (Development Contributions Plan Overlay — Schedule 1, Baw Baw Planning Scheme) applies to this land. Developer contributions may be levied by council for future development. Contact Baw Baw Shire Council for current DCP levy schedule and any proposed infrastructure works in the area.",
    floodZone:                 false,
    vendorMotivation:          "TBD",
    vendorTimelineDays:        "TBD",
    previousOffers:            "TBD",
    daysOnMarket:              "TBD",
    priceReductionHistory:     "TBD",
    tenantInPlace:             "TBD",
    tenantLeaseEndDate:        "TBD",
    vendorPreferredSettlement: "TBD",
    vendorFlexOnInclusions:    "TBD",
    inclusions:                "TBD — refer to Contract of Sale for full inclusions list",

    qa: [
      {
        question: "How big is the land?",
        answer: "1,309 square metres. This is confirmed in the Planning Property Report (Department of Transport and Planning, 07/04/2026) and the Property Report (Department of Energy, Environment and Climate Action, 07/04/2026). The lot perimeter is 172 metres. It is Lot 2 on Plan of Subdivision PS819986H.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "frontage", "perimeter", "1309"],
      },
      {
        question: "What is the title reference?",
        answer: "Volume 11967, Folio 877. The Standard Parcel Identifier (SPI) is 2\\PS819986. It is Lot 2 on Plan of Subdivision PS819986H, registered 15/03/2018. Parent titles were Volume 11317 Folio 168 and Volume 11889 Folio 016. The title was produced by LANDATA on 07/04/2026.",
        category: "legal",
        keywords: ["title", "volume", "folio", "certificate of title", "CT", "SPI", "lot", "plan of subdivision", "PS819986"],
      },
      {
        question: "Who are the vendors and owners?",
        answer: "The registered proprietors are Anthony John Collins (of Unit 10, 36 Peel Street, Berwick VIC 3806) and Richard Anthony Cimino (of 10 Scenic Road, Warragul VIC 3820). They hold the property as joint proprietors in fee simple by instrument AR054983G dated 24/05/2018.",
        category: "legal",
        keywords: ["vendor", "owner", "proprietor", "Collins", "Cimino", "seller"],
      },
      {
        question: "What planning zone is the property in?",
        answer: "General Residential Zone Schedule 1 (GRZ1) under the Baw Baw Planning Scheme. Council is Baw Baw Shire. This is confirmed in the Planning Property Report (Department of Transport and Planning) dated 07/04/2026.",
        category: "planning",
        keywords: ["zone", "zoning", "planning zone", "GRZ", "GRZ1", "residential zone", "planning scheme"],
      },
      {
        question: "What planning overlays apply to this property?",
        answer: "Two overlays apply directly: DCPO1 (Development Contributions Plan Overlay — Schedule 1) and ESO4 (Environmental Significance Overlay — Schedule 4). Two overlays exist in the vicinity but do NOT directly affect this land: Floodway Overlay (FO) and Land Subject to Inundation Overlay (LSIO). This is confirmed in the Planning Property Report dated 07/04/2026.",
        category: "planning",
        keywords: ["overlay", "DCPO", "ESO", "development contributions", "environmental significance", "planning overlay"],
      },
      {
        question: "Is the property in a flood zone?",
        answer: "No — the property is NOT within the Floodway Overlay (FO) or Land Subject to Inundation Overlay (LSIO). The Planning Property Report (07/04/2026) shows these overlays exist in the vicinity but do NOT directly affect this land. A watercourse runs adjacent to the eastern boundary (Warragul Linear Park Arts Discovery Trail corridor).",
        category: "planning",
        keywords: ["flood", "floodway", "inundation", "flood zone", "LSIO", "FO", "water", "flood risk"],
      },
      {
        question: "Is the property in a bushfire prone area?",
        answer: "No. The Planning Property Report (07/04/2026) explicitly states: 'This property is not in a designated bushfire prone area. No special bushfire construction requirements apply. Planning provisions may apply.' The Section 32 also confirms the bushfire prone area box is not marked.",
        category: "planning",
        keywords: ["bushfire", "bushfire prone area", "BPA", "fire", "BAL", "construction requirements"],
      },
      {
        question: "What services are connected to the property?",
        answer: "All services are connected. The Section 32 confirms electricity, gas, water, sewerage, and telephone are all connected (no boxes marked as 'NOT connected' in Section 8 of the vendor statement). Power distributor is AUSNET. Urban water is Gippsland Water. Rural water is Southern Rural Water. The property is outside Melbourne Water's drainage boundary.",
        category: "physical",
        keywords: ["services", "electricity", "gas", "water", "sewerage", "telephone", "utilities", "connected"],
      },
      {
        question: "What are the council rates?",
        answer: "The Section 32 (Section 1.1) states that the total rates, taxes, charges and similar outgoings do not exceed $5,000.00 per annum. This is the statutory cap disclosure; the actual rate notice amount should be confirmed with Baw Baw Shire Council (Council Property No: 26809).",
        category: "financial",
        keywords: ["rates", "council rates", "outgoings", "annual rates", "council charge", "rates notice"],
      },
      {
        question: "Is there a swimming pool?",
        answer: "Yes. There is a permanent swimming pool. Construction date: 24 January 2017 (per Baw Baw Shire Council permit records). Pool registration number: SP-1337/19 (Baw Baw Shire Council). Applicable barrier standard: AS 1926.1-2012.",
        category: "features",
        keywords: ["pool", "swimming pool", "spa", "pool fence", "pool barrier"],
      },
      {
        question: "Is the pool barrier compliant?",
        answer: "Yes — certified compliant. A Form 23 Certificate of Barrier Compliance was issued on 9 April 2024 by Ian Bruhn (Building Practitioner No. IN-PS 69817, Bass Coast Pool Inspections). The barrier was inspected against AS 1926.1-2012 and deemed to satisfy the Building Code of Australia. Baw Baw Shire Council acknowledged receipt of the certificate on 18 April 2024 (letter from Julian Bonnici, Municipal Building Surveyor).",
        category: "legal",
        keywords: ["pool compliance", "pool barrier", "pool fence", "Form 23", "AS 1926", "pool inspection", "barrier compliance"],
      },
      {
        question: "When is the next pool inspection due?",
        answer: "No later than 18 April 2028. The Certificate of Pool and Spa Barrier Compliance must be no older than 30 days at the time of lodgement, accompanied by the applicable lodgement fee. Pool registration: SP-1337/19. Contact Baw Baw Shire Council Building Services on (03) 5624 2411.",
        category: "legal",
        keywords: ["pool inspection", "next inspection", "pool compliance due", "pool certificate", "Form 23"],
      },
      {
        question: "What easements are on the property?",
        answer: "Six registered easements per Plan PS819986H: E-1 — gas supply (2m, instrument V21169B, benefiting C/T Vol 9655 Fol 644) and power line (2m, PS611739K, SPI Electricity Pty Ltd); E-2 — power line (2m, PS611739K, SPI Electricity Pty Ltd); E-3 — sewerage (see diagram, LP 135370, Lots on LP 135370) and pipeline or ancillary purposes (see diagram, PS611739K, Central Gippsland Region Water Corporation); E-4 — drainage (2m, PS611739K, Lot 1 PS611739K); E-5 — sewerage (2m, PS611739K, Lot 1 PS611739K); E-6 — sewerage (2m, this plan, Lot 1 PS819986H). Encumbrances under s98 Transfer of Land Act 1958 and s24 Subdivision Act 1988 also apply per plan.",
        category: "legal",
        keywords: ["easement", "easements", "encumbrance", "gas easement", "power easement", "sewerage easement", "drainage easement"],
      },
      {
        question: "Are there any covenants on the property?",
        answer: "Nil. The vendor statement does not disclose any registered covenants, Section 173 agreements, or other similar restrictions. The Section 32 states that to the best of the vendor's knowledge there is no existing failure to comply with any easements, covenants or similar restrictions.",
        category: "legal",
        keywords: ["covenant", "restriction", "section 173", "encumbrance", "caveat", "restrictions"],
      },
      {
        question: "Is there an owners corporation?",
        answer: "No — Not Applicable. Section 6 of the vendor statement confirms the property is not affected by an Owners Corporation under the Owners Corporations Act 2006. There are no owners corporation fees.",
        category: "financial",
        keywords: ["owners corporation", "body corporate", "strata", "OC fees", "body corp fees"],
      },
      {
        question: "Is there a Growth Areas Infrastructure Contribution (GAIC)?",
        answer: "No — Not Applicable. Section 7 of the vendor statement confirms no GAIC applies. This property is not within a growth area subject to Part 9B of the Planning and Environment Act 1987.",
        category: "financial",
        keywords: ["GAIC", "growth areas", "infrastructure contribution", "growth area levy"],
      },
      {
        question: "What is the GST position?",
        answer: "The purchaser is NOT required to make a GST payment under Section 14-250 of Schedule 1 of the Taxation Administration Act 1953 (Cwlth) in relation to the supply of this property. This is confirmed in Section 13 of the vendor statement.",
        category: "financial",
        keywords: ["GST", "goods and services tax", "withholding", "tax", "GST notice"],
      },
      {
        question: "What is the land tax position?",
        answer: "This land is NOT land tax reform scheme land under the Commercial and Industrial Property Tax Reform Act 2024 (Vic) — confirmed in Section 1.5 of the vendor statement. The AVPC is n/a. Purchaser's land tax liability under the Land Tax Act 2005 (Vic) depends on intended use (principal place of residence exemption does not apply to investors). Obtain independent tax advice.",
        category: "financial",
        keywords: ["land tax", "CIPT", "commercial industrial property tax", "AVPC", "land tax reform"],
      },
      {
        question: "Are there any building permits to disclose?",
        answer: "Not Applicable. Section 5 of the vendor statement states no building permits were issued under the Building Act 1993 in the preceding 7 years. The permanent swimming pool was constructed on 24 January 2017 — outside the 7-year disclosure window as at the date of this S32.",
        category: "legal",
        keywords: ["building permit", "permits", "building works", "renovations", "construction permit"],
      },
      {
        question: "Is there any owner-builder work?",
        answer: "Not Applicable — Section 2.2 of the vendor statement confirms no owner-builder work requiring disclosure under section 137B of the Building Act 1993 exists at this property.",
        category: "legal",
        keywords: ["owner builder", "owner-builder", "DIY", "self-built", "builder warranty"],
      },
      {
        question: "Are there any notices or orders affecting the property?",
        answer: "No — Section 4.1 states Not Applicable for all government notices, orders, declarations or recommendations. Section 4.3 confirms Nil for any compulsory acquisition notices under the Land Acquisition and Compensation Act 1986.",
        category: "legal",
        keywords: ["notices", "orders", "compulsory acquisition", "government order", "declaration"],
      },
      {
        question: "Is the property subject to agricultural chemical contamination?",
        answer: "Nil. Section 4.2 confirms there are no notices, property management plans, reports or orders relating to livestock disease or agricultural chemical contamination affecting the ongoing use of the land for agricultural purposes.",
        category: "legal",
        keywords: ["chemicals", "agricultural chemicals", "contamination", "chemical contamination"],
      },
      {
        question: "What is the development contributions situation?",
        answer: "DCPO1 (Development Contributions Plan Overlay — Schedule 1) applies to this land under the Baw Baw Planning Scheme. This means Baw Baw Shire Council may levy development contributions for any future development. Contact council for the current DCP levy schedule and applicable contributions: Baw Baw Shire Council, (03) 5624 2411, bawbaw@bawbawshire.vic.gov.au.",
        category: "planning",
        keywords: ["development contributions", "DCPO", "developer levy", "infrastructure levy", "DCP"],
      },
      {
        question: "What is the Environmental Significance Overlay about?",
        answer: "ESO4 (Environmental Significance Overlay — Schedule 4) applies directly to this property. ESO4 under the Baw Baw Planning Scheme relates to the watercourse and creek corridor environment. This overlay may require a planning permit for certain works including vegetation removal, buildings and works near the waterway, and subdivision. The watercourse is visible adjacent to the eastern boundary of the property (Warragul Linear Park Arts Discovery Trail corridor). Contact Baw Baw Shire Council for what triggers a permit requirement under ESO4 Schedule 4.",
        category: "planning",
        keywords: ["ESO", "environmental significance", "environmental overlay", "ESO4", "waterway", "vegetation", "creek"],
      },
      {
        question: "What utilities companies service the property?",
        answer: "Power distributor: AUSNET. Urban water corporation: Gippsland Water. Rural water corporation: Southern Rural Water. The property is outside the Melbourne Water drainage boundary. Fire authority: Country Fire Authority (CFA). These details are confirmed in both the Planning Property Report and the Property Report (both 07/04/2026).",
        category: "physical",
        keywords: ["utilities", "power", "water", "AusNet", "Gippsland Water", "Southern Rural Water", "electricity company"],
      },
      {
        question: "Which council manages this property and what are the contact details?",
        answer: "Baw Baw Shire Council. Council Property Number: 26809. Website: www.bawbawshire.vic.gov.au. Phone: (03) 5624 2411. Fax: (03) 5622 3654. Email: bawbaw@bawbawshire.vic.gov.au. Postal: PO Box 304, Warragul VIC 3820. Planning scheme: Baw Baw.",
        category: "location",
        keywords: ["council", "Baw Baw", "local council", "council contact", "shire council"],
      },
      {
        question: "What is the lot shape and street frontage position?",
        answer: "The lot is an irregular multi-sided polygon with a perimeter of 172 metres and an area of 1,309m² (per Property Report, 07/04/2026). Per the Plan of Subdivision PS819986H Sheet 2, the lot has a frontage to Scenic Road (north-west boundary) and also adjoins Hallyburton Grove and Bronte Avenue to the south and east. The eastern boundary runs adjacent to a watercourse / the Warragul Linear Park Arts Discovery Trail corridor. It is Lot 2 of PS819986H — adjacent to Lot 1 (944m², being 6 Scenic Road).",
        category: "physical",
        keywords: ["lot shape", "frontage", "street frontage", "irregular", "lot dimensions", "perimeter", "boundary"],
      },
      {
        question: "What state electorate does this property fall in?",
        answer: "Legislative Council: Eastern Victoria Region. Legislative Assembly: Narracan electorate. Confirmed in the Planning Property Report and Property Report (07/04/2026).",
        category: "location",
        keywords: ["electorate", "state electorate", "Narracan", "Eastern Victoria", "MP", "state member"],
      },
      {
        question: "What is the Aboriginal traditional country context?",
        answer: "The registered Aboriginal party for this area is the Gunaikurnai Land and Waters Aboriginal Corporation. This is the recognised Traditional Custodian group for the Warragul / Gippsland region.",
        category: "location",
        keywords: ["Aboriginal", "traditional owners", "Gunaikurnai", "traditional country", "indigenous"],
      },
      {
        question: "Is the sale subject to a mortgage?",
        answer: "Not Applicable — Section 1.4 of the vendor statement confirms the sale is not subject to any mortgage being held over after settlement. Vacant possession will be provided.",
        category: "legal",
        keywords: ["mortgage", "sale subject to mortgage", "lender", "bank"],
      },
      {
        question: "When was this lot created and what was the original block?",
        answer: "The lot was created by Plan of Subdivision PS819986H, registered 15/03/2018. The plan was signed off by Baw Baw Shire Council on 07/02/2018 (by Lyndal Farrar). The parent titles were Volume 11317 Folio 168 and Volume 11889 Folio 016. The original block was described as Crown Allotment 10 (part) and 11 (part), Section 11, Township of Warragul, Parish of Drouin East. The subdivision created two lots: Lot 1 (944m², 6 Scenic Road) and Lot 2 (1,309m², 10 Scenic Road — this property). Survey by Webster Survey Group, surveyors file ref 16090.",
        category: "legal",
        keywords: ["subdivision", "lot created", "parent title", "original block", "plan PS819986", "crown allotment"],
      },
      {
        question: "Are there any encumbrances or caveats on title?",
        answer: "Nil registered encumbrances, caveats or notices — confirmed by the LANDATA title search (Security No. 124133550301H) produced 07/04/2026. Activity in the last 125 days: NIL. Note: encumbrances created by Section 98 of the Transfer of Land Act 1958 or Section 24 of the Subdivision Act 1988, and easements shown on the plan diagram, do apply.",
        category: "legal",
        keywords: ["caveat", "encumbrance", "charges", "title encumbrance", "registered interest", "activity on title"],
      },
      {
        question: "Is this a staged subdivision?",
        answer: "No. The Plan of Subdivision PS819986H states explicitly: 'This is not a staged subdivision. Planning Permit No. [blank].' Planning permit reference: planning permit not required. The subdivision was certified under section 6 of the Subdivision Act 1988. No public open space requirement was made (statement of compliance issued under section 21 of the Subdivision Act 1988).",
        category: "legal",
        keywords: ["staged subdivision", "subdivision", "planning permit", "stages", "further subdivision"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 602 — 13 Jack William Way, Berwick VIC 3806 (ACTIVE LISTING)
  // SLM data: Extracted from Contract of Sale / Section 32 (81 pages)
  // Title: Vol 10794 Folio 460 | Lot 106 on PS516565X
  // Vendor: DONG&NA INVESTMENT PTY LTD ATF J&K Family Trust One (ACN 647194492)
  // Title search: 27/02/2026 | LIC: 02/03/2026 | SEW statement: 02/03/2026
  // SRO clearance: 02/03/2026 | Planning report: 27/02/2026
  // -------------------------------------------------------------------------
  602: {
    propertyId: 602,
    address: "13 Jack William Way",
    suburb: "Berwick VIC 3806",
    status: "active",

    // PHYSICAL
    beds: "TBD",
    baths: "TBD",
    cars: "TBD",
    landSqm: 630,
    houseSqm: "TBD",
    yearBuilt: "TBD",
    propertyType: "House",
    frontageMetre: "TBD",
    depthMetre: "TBD",
    propertyShape: "TBD",
    orientation: "TBD",
    pool: "TBD",
    gardenSqm: "TBD",
    shed: "TBD",
    outdoorEntertaining: "TBD",
    alfrescoSqm: "TBD",
    roofType: "TBD",
    externalCladding: "TBD",
    construction: "Established residential dwelling in PS516565X subdivision estate (plan registered 13/04/2004, parish of Berwick, Crown Portion 35, origin 348-356 Clyde Road Berwick). Capital Improved Value $910,000 (City of Casey valuation 01/07/2025). No owner-builder works. No building permits in preceding 7 years (S32 Item 5).",
    floorplanConfig: "TBD",

    // LEGAL & TITLE
    titleType: "Torrens — Volume 10794 Folio 460 (Lot 106 on Plan of Subdivision 516565X). Standard Parcel Identifier: 106\\PS516565X. Estate Fee Simple, Sole Proprietor. Registered proprietor: DONG&NA INVESTMENT PTY LTD of 90 Lake View Boulevard, Keysborough VIC 3173, by instrument AU592651E dated 19/07/2021. Parent Title: Volume 10776 Folio 201. Created by instrument PS516565X registered 13/04/2004. eCT controlled by ANZ Banking Group Ltd (16165A, effective 19/07/2021). Title search produced 27/02/2026. Security number: 124132560438V. No dealing activity in last 125 days.",
    easements: "E-1: Sewerage easement (origin PS509027T, benefiting South East Water Ltd). E-2: Drainage and Sewerage easement (origin PS516565X, benefiting lots on plan and South East Water Ltd) — 9-metre wide (9E) easement applies to Lot 106 per Sheet 4 notation (-07,E2+502). No structures may be built over or within 1 metre of easements without South East Water written consent. SEW asset plans confirm 150mm uPVC sewer main in street.",
    covenants: "COVENANT AC885145U (27/05/2004) — Section 98 Transfer of Land Act 1958 / Section 24 Subdivision Act 1988 encumbrances per plan PS516565X. Building Envelope Restriction in PS516565X Sheet 5 applies ONLY to Lots 76–81 — Lot 106 is NOT subject to the Building Envelope Restriction. GRZ1 planning controls apply: site coverage max 55%, open space min 20% or 80m².",
    overlays: "No planning overlays (Planning Property Report, 27/02/2026, Casey Planning Scheme — 'No planning overlay found'). Zone: GRZ1 (General Residential Zone Schedule 1).",
    s32Status: "Section 32 Vendor Statement prepared — vendor DONG&NA INVESTMENT PTY LTD ATF J&K Family Trust One (ACN 647194492). Conveyancer: Able Land and Conveyancing Pty Ltd (ref V602008, alac.mel@gmail.com, 0430082881). Title search 27/02/2026, LIC 02/03/2026, SEW statement 02/03/2026, SRO clearance 02/03/2026.",
    encumbrances: "1. MORTGAGE AU592652C (19/07/2021) — Australia and New Zealand Banking Group Ltd (ANZ) — to be discharged at settlement. eCT control: 16165A ANZ, effective 19/07/2021. 2. COVENANT AC885145U (27/05/2004) — Section 98/24 subdivision encumbrances per plan PS516565X. 3. AGREEMENT AC424222D (23/10/2003) — Section 173 Planning and Environment Act 1987 Community Infrastructure Levy Agreement (Casey City Council / Lyngreye Pty Ltd / Newland Developments Pty Ltd) — CIL payable prior to building permit; obligation effectively spent for existing dwelling.",
    ownerOccupied: false,
    zoning: "GRZ1 — General Residential Zone Schedule 1 (Casey Planning Scheme). Council Property Number: 89644. Melway reference: 131 A5.",
    rightOfWay: "None. Road access confirmed via public road Jack William Way vested in City of Casey (PS516565X roads R-1 — City of Casey).",
    sewerEasement: "Yes — E-2 Drainage and Sewerage easement (9-metre wide) applies to Lot 106 per PS516565X Sheet 4. Benefiting: lots on plan and South East Water Ltd. No building or filling within easement or within 1m of any South East Water asset without written approval.",
    contaminatedLand: false,
    buildingPermitsOutstanding: "Not applicable — vendor confirms no building permits issued in preceding 7 years (S32 Item 5). Original subdivision required environmental audit per planning permit P 430/01 condition 8 — statement of compliance was issued, certifying land suitable for residential use.",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "27/02/2026 (title search) / 02/03/2026 (LIC eCerR/C010341 and SEW statement / SRO clearance certificate No. 97984653)",

    // FINANCIAL
    priceMin: 0,
    priceMax: 0,
    vendorReserve: "TBD",
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 530,
    rentalAppraisalHigh: 620,
    grossYieldAtAsk: "TBD",
    councilRates: 2757,
    waterRates: 704,
    bodyCorporateFees: 0,
    stampDutyEstimate: 49100,
    landTaxThreshold: "Vendor (J&K Family Trust One / DONG&NA Investment Pty Ltd, ACN 647194492) has 2026 land tax $4,458.00 (SV $620,000) and 2025 arrears $4,701.75. Total SRO clearance charge $9,159.75 (Property Clearance Certificate No. 97984653, 02/03/2026). CIPT: $0.00 (AVPCC 110 — not qualifying commercial/industrial use). Windfall Gains Tax: $0.00. Purchaser liability assessed from settlement date under Land Tax Act 2005 (Vic).",
    depreciationYear1Est: "TBD",
    capitalGainsHistory: "Vendor acquired 19/07/2021 (instrument AU592651E). CIV: $910,000 at 01/07/2025. Site Value: $620,000. Net Annual Value: $45,500. Capital gain since 2021 purchase price not disclosed. Not new residential premises — no GST withholding required (GST Withholding Notice in S32). FIRB: purchaser warrants ordinary Australian resident (SC4).",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School (approx 1.5km) — confirm catchment with City of Casey or findmyschool.net.au",
    primarySchoolRating: "TBD",
    secondarySchool: "Berwick Secondary College (approx 2km) — confirm catchment with City of Casey",
    secondarySchoolRating: "TBD",
    schoolZoneCatchment: "Likely Berwick Primary School and Berwick Secondary College — confirm with City of Casey. St Catherine's Catholic Primary School also in area (referenced in original PS516565X planning permit P 430/01).",
    distanceToTrainKm: 1.8,
    trainLine: "Pakenham Line — Berwick Station (~1.8km). Approx 45 min to Flinders Street.",
    distanceToFreewayKm: 1.5,
    distanceToShoppingKm: 2.0,
    nearestHospitalKm: 3.5,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 870000,
    daysOnMarketAvg: 30,
    clearanceRatePct: 65,
    comparableSales: "TBD",

    // FEATURES & CONDITION
    kitchenRenovated: "TBD",
    bathroomRenovated: "TBD",
    flooringType: "TBD",
    airConType: "TBD",
    heatingType: "TBD",
    solarKw: "TBD",
    batteryStorage: "TBD",
    evCharging: "TBD",
    nbnType: "TBD — telephone not connected per S32 Item 8. NBN availability to be confirmed with NBN Co — FTTC or FTTP typically available in Berwick estates of this vintage.",
    waterTank: "TBD",
    alarmSystem: "TBD",
    smartHome: "TBD",
    disabilityAccess: "TBD",
    petsAllowed: true,
    outdoorFeatures: "TBD",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Yes — GRZ1 permits additions/extensions subject to council planning permit. Lot 106 is NOT subject to Building Envelope Restriction (PS516565X Sheet 5 — restriction applies only to Lots 76–81). Site coverage max 55%, open space min 20% or 80m² per subdivision covenants.",
    councilDevelopmentHistory: "No building permits in preceding 7 years (S32 Item 5). Section 173 CIL Agreement (AC424222D) obligation discharged upon original building permit. Planning permit P 430/01 (amended 29 Aug 2002) — original subdivision permit, spent. No unregistered dealings (title search 27/02/2026).",
    neighbourhoodDescription: "Lot 106 on PS516565X — 630m² residential property at 13 Jack William Way, Berwick VIC 3806 (City of Casey, Council Property No. 89644, Melway 131 A5). Part of residential estate created from 348-356 Clyde Road, Berwick (Parish of Berwick, Crown Portion 35, registered 13/04/2004). Located between Lot 105 and Lot 107 on Jack William Way. E-2 drainage and sewerage easement (9m wide). GRZ1 zone. No planning overlays. Berwick Station (Pakenham Line) approx 1.8km. Eden Rise / Berwick Village shopping approx 2km. Casey Hospital approx 3.5km. Not in designated bushfire prone area. Melbourne Water confirms: not subject to flooding at 1% probability. Fire authority: Country Fire Authority (CFA). Aboriginal cultural heritage area — Bunurong Land Council Aboriginal Corporation. Legislative Assembly electorate: Berwick. Legislative Council: South-Eastern Metropolitan.",
    trafficNoiseLevel: "Low to moderate — Jack William Way is an internal residential estate street. Clyde Road (major arterial) and Berwick-Cranbourne Road are in the broader area but not directly fronting this lot.",
    flightPathFlag: false,
    futureInfrastructure: "City of Casey growth corridor. No compulsory acquisition notices (S32 Item 4.3: No). No notices or orders (S32 Item 4.1: Not Applicable). No GAIC recording (S32 Item 7). No windfall gains tax (SRO certificate $0.00). CIPT: $0.00 (AVPCC 110 — residential land).",
    floodZone: false,
    vendorMotivation: "Investment entity — DONG&NA INVESTMENT PTY LTD ATF J&K Family Trust One (ACN 647194492), acquired 19/07/2021. Not owner-occupied. Offering vacant possession. Outstanding land tax arrears of $4,701.75 for 2025 evident on SRO clearance certificate.",
    vendorTimelineDays: "TBD",
    previousOffers: "TBD",
    daysOnMarket: 0,
    priceReductionHistory: "N/A — new to market",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement",
    vendorPreferredSettlement: "TBD — price and settlement date not specified in contract particulars. SC7: variation of settlement date by Deed of Variation ($220+GST vendor's legal costs).",
    vendorFlexOnInclusions: "Standard inclusions — all fixed floor coverings, electric light fittings, window furnishings and all fixtures and fittings of a permanent nature as inspected. SC5: vendor makes no representations or warranties regarding solar panels if installed.",
    inclusions: "All fixed floor coverings, electric light fittings, window furnishings and all fixtures and fittings of a permanent nature as inspected (COS Goods clause, page 7). SC5: no representations or warranties on solar panels.",

    qa: [
      {
        question: "How big is the land?",
        answer: "630 square metres — confirmed by Plan of Subdivision PS516565X (Lot 106, Sheet 4) and City of Casey Land Information Certificate (Property No. 89644, issued 02/03/2026).",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "area", "frontage", "depth"],
      },
      {
        question: "What is the title?",
        answer: "Torrens title — Volume 10794 Folio 460, Lot 106 on Plan of Subdivision 516565X. SPI: 106\\PS516565X. Estate Fee Simple. Registered proprietor: DONG&NA INVESTMENT PTY LTD (90 Lake View Boulevard, Keysborough VIC 3173) by instrument AU592651E, 19/07/2021. Parent title: Volume 10776 Folio 201. Title created by instrument PS516565X registered 13/04/2004.",
        category: "legal",
        keywords: ["title", "torrens", "folio", "volume", "lot", "plan", "subdivision", "spi", "certificate", "torrens"],
      },
      {
        question: "Who is the vendor?",
        answer: "DONG&NA INVESTMENT PTY LTD ACN 647194492, as trustee for the J&K Family Trust One. Vendor address: 90 Lake View Boulevard, Keysborough VIC 3173. Listed through Barry Plant Berwick (Manpreet Panayi, mpanayi@barryplant.com.au, 03 9707 1400 / 0413204342). Vendor's conveyancer: Able Land and Conveyancing Pty Ltd, Mulgrave (ref V602008, alac.mel@gmail.com, 0430082881).",
        category: "legal",
        keywords: ["vendor", "seller", "owner", "trust", "company", "dong", "family trust", "barry plant"],
      },
      {
        question: "What is the zoning?",
        answer: "General Residential Zone Schedule 1 (GRZ1) under the Casey Planning Scheme. No planning overlays apply (Planning Property Report, 27/02/2026). Not a designated bushfire prone area. Council: City of Casey.",
        category: "planning",
        keywords: ["zone", "zoning", "planning", "grz", "grz1", "residential", "overlay", "casey", "scheme"],
      },
      {
        question: "Are there any easements?",
        answer: "Yes — two easements under PS516565X: E-1 (Sewerage, origin PS509027T, benefiting South East Water Ltd) and E-2 (Drainage and Sewerage, origin PS516565X, benefiting lots on plan and South East Water Ltd). E-2 applies to Lot 106 — 9-metre wide easement per Sheet 4 notation. No structures can be built over or within 1 metre of the easement without South East Water written approval. South East Water asset plans show 150mm uPVC sewer mains in the street.",
        category: "legal",
        keywords: ["easement", "sewer", "drainage", "south east water", "encumbrance", "easements", "E-2", "9 metre"],
      },
      {
        question: "What are the covenants?",
        answer: "Covenant AC885145U (27/05/2004) — Section 98 Transfer of Land Act 1958 / Section 24 Subdivision Act 1988 encumbrances per plan PS516565X. The Building Envelope Restriction in PS516565X Sheet 5 applies ONLY to Lots 76–81 — Lot 106 is NOT subject to this restriction. GRZ1 controls apply: site coverage max 55%, open space min 20% or 80m².",
        category: "legal",
        keywords: ["covenant", "restriction", "building envelope", "encumbrance", "section 98", "subdivision act", "AC885145U"],
      },
      {
        question: "What is the Section 173 Agreement on title?",
        answer: "Agreement AC424222D (23/10/2003) is a Community Infrastructure Levy (CIL) Agreement under Section 173 of the Planning and Environment Act 1987, between Casey City Council, Lyngreye Pty Ltd, and Newland Developments Pty Ltd. It required each lot owner to pay a CIL of $325/lot (CPI-adjusted from 1 April 1998) to Casey City Council before obtaining any building permit. Since the existing dwelling was built after 2004, the CIL for Lot 106 has been discharged. The Agreement remains on title but its obligations are effectively spent for this lot. It runs with the land and binds successive owners.",
        category: "legal",
        keywords: ["section 173", "s173", "agreement", "CIL", "community infrastructure levy", "casey council", "AC424222D", "planning"],
      },
      {
        question: "Is there a mortgage on the property?",
        answer: "Yes — Mortgage AU592652C registered 19/07/2021 in favour of Australia and New Zealand Banking Group Ltd (ANZ). This will be fully discharged at settlement. The eCT (Electronic Certificate of Title) is under ANZ's control (16165A). The ANZ mortgage is the only registered financial encumbrance.",
        category: "legal",
        keywords: ["mortgage", "ANZ", "bank", "encumbrance", "discharge", "settlement", "loan", "AU592652C"],
      },
      {
        question: "What services are connected?",
        answer: "Electricity (AUSNET), gas, water (South East Water) and sewerage (South East Water) are all connected. Telephone is NOT connected per Section 32 Item 8. NBN availability to be confirmed with NBN Co — FTTC or FTTP is typically available in Berwick estates of this vintage. Melbourne Water: property is inside Melbourne Water's drainage boundary.",
        category: "physical",
        keywords: ["services", "electricity", "gas", "water", "sewer", "sewerage", "telephone", "nbn", "internet", "connected", "ausnet"],
      },
      {
        question: "What are the council rates?",
        answer: "City of Casey council rates for FY2026 total $2,757.20: General Rates $1,995.77, Garbage Charge $468.00, ESVF Levy $293.43. Land Information Certificate eCerR/C010341 issued 02/03/2026. No scheme charges. Full rate payments were due 16/02/2026 — purchaser assumes responsibility from settlement date.",
        category: "financial",
        keywords: ["council", "rates", "annual", "casey", "garbage", "levy", "fees", "per year", "outgoings"],
      },
      {
        question: "What are the water rates?",
        answer: "South East Water quarterly service charges (Q1 2026): Parks Victoria Parks Service Charge $22.45, Melbourne Water Corporation $31.25, Water Service Charge $21.97, Sewerage Service Charge $100.41 — subtotal $176.08 per quarter. Estimated annual service fees approximately $704 (plus usage). SEW Information Statement Case No. 51569766, 02/03/2026.",
        category: "financial",
        keywords: ["water", "rates", "south east water", "sewerage", "quarterly", "annual", "fees", "charges", "outgoings"],
      },
      {
        question: "What is the property valuation?",
        answer: "City of Casey valuation as at 01/07/2025: Site Value $620,000, Capital Improved Value (CIV) $910,000, Net Annual Value (NAV) $45,500. These are government valuations used for rate and land tax assessment — not a market valuation.",
        category: "financial",
        keywords: ["valuation", "CIV", "site value", "capital improved", "NAV", "assessed", "land value", "government"],
      },
      {
        question: "What is the land tax situation?",
        answer: "Vendor (J&K Family Trust One / DONG&NA Investment Pty Ltd) has 2026 land tax $4,458.00 (SV $620,000) and 2025 arrears $4,701.75. Total SRO clearance charge: $9,159.75 (Property Clearance Certificate No. 97984653, 02/03/2026). CIPT charge: $0.00 (AVPCC 110 — not qualifying commercial/industrial use). Windfall Gains Tax: $0.00. Purchaser liability depends on intended use — investor purchasers assessed under Land Tax Act 2005 (Vic) from settlement.",
        category: "financial",
        keywords: ["land tax", "SRO", "state revenue", "clearance", "certificate", "arrears", "CIPT", "windfall"],
      },
      {
        question: "Is there GST or FIRB to consider?",
        answer: "No GST withholding required — vendor confirms the property is NOT new residential premises (GST Withholding Notice in S32, per s.14-250 TAA 1953). FIRB: Special Condition 4 requires the purchaser to warrant they are an ordinary Australian resident — no FIRB or Reserve Bank approval required.",
        category: "legal",
        keywords: ["GST", "FIRB", "foreign", "withholding", "tax", "new residential", "overseas", "investor"],
      },
      {
        question: "Is the property in a flood zone?",
        answer: "No. South East Water Information Statement (02/03/2026) states: 'Information available at Melbourne Water indicates that this property is not subject to flooding from Melbourne Water's drainage system, based on a flood level that has a probability of occurrence of 1% in any one year.' No flood overlay on title.",
        category: "planning",
        keywords: ["flood", "flooding", "flood zone", "inundation", "waterway", "risk", "melbourne water"],
      },
      {
        question: "Is the property in a bushfire prone area?",
        answer: "No. Section 32 confirms: Designated Bushfire Prone Area — No. Planning Property Report (27/02/2026): 'This property is not in a designated bushfire prone area. No special bushfire construction requirements apply.' Fire authority is the Country Fire Authority (CFA).",
        category: "planning",
        keywords: ["bushfire", "fire", "BAL", "hazard", "prone", "CFA", "fire authority", "construction"],
      },
      {
        question: "Is there an owners corporation?",
        answer: "No. Section 32 confirms Owners Corporation — Not Applicable (Item 6). No body corporate fees apply.",
        category: "legal",
        keywords: ["owners corporation", "body corporate", "OC", "strata", "fees", "body corp"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "No. The lot is 630m² under GRZ1 zoning. A 9-metre E-2 easement further limits developable area. Section 32 Item 10 confirms no unregistered, staged, or further subdivision. The covenant AC885145U also restricts to single residential dwelling use.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "second dwelling", "split", "potential", "develop", "grz1"],
      },
      {
        question: "Are there any planning overlays?",
        answer: "No planning overlays apply. Planning Property Report from planning.vic.gov.au (27/02/2026) confirms: 'No planning overlay found' for 13 Jack William Way Berwick 3806 (Lot 106 PS516565X). GRZ1 zone applies. No Heritage Overlay, Environmental Overlay, Flood Overlay, or Vegetation Overlay.",
        category: "planning",
        keywords: ["overlay", "planning overlay", "heritage", "environmental", "flood", "vegetation", "vpo", "eso", "none"],
      },
      {
        question: "How far is Berwick Station?",
        answer: "Berwick Station on the Pakenham Line is approximately 1.8km from the property. Trains run to Flinders Street in approximately 45 minutes.",
        category: "location",
        keywords: ["train", "station", "berwick", "pakenham", "transport", "commute", "distance", "walk", "flinders"],
      },
      {
        question: "How far is shopping?",
        answer: "Berwick Village and Eden Rise Shopping Centre (Coles, specialty stores) is approximately 2km. Fountain Gate Westfield (Narre Warren) is approximately 7km.",
        category: "location",
        keywords: ["shopping", "shops", "centre", "coles", "supermarket", "eden rise", "berwick village", "westfield"],
      },
      {
        question: "How far is Casey Hospital?",
        answer: "Casey Hospital in Berwick is approximately 3.5km from the property.",
        category: "location",
        keywords: ["hospital", "casey", "medical", "health", "emergency", "distance"],
      },
      {
        question: "What school zone is this property in?",
        answer: "Most likely Berwick Primary School and Berwick Secondary College catchment — confirm with City of Casey or findmyschool.net.au. St Catherine's Catholic Primary School is nearby (referenced in planning permit P 430/01 for the original subdivision). Private options include Beaconhills College and Haileybury College in the broader Berwick area.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "berwick", "catholic", "education", "st catherine"],
      },
      {
        question: "What is the Berwick suburb market like?",
        answer: "Berwick has delivered approximately 28% median price growth over 5 years. Current median house price is approximately $870,000. Average days on market is around 30 days, clearance rate approximately 65%. Berwick is in City of Casey LGA — one of Victoria's fastest-growing LGAs. Legislative Assembly electorate: Berwick. Legislative Council: South-Eastern Metropolitan.",
        category: "location",
        keywords: ["suburb", "market", "growth", "median", "berwick", "clearance", "days on market", "appreciation", "casey"],
      },
      {
        question: "What is the rental appraisal?",
        answer: "Based on comparable Berwick rentals, this property would likely rent for approximately $530–$620 per week depending on bedroom count and condition (to be confirmed on inspection). City of Casey Net Annual Value of $45,500 equates to approximately $875/week by the government's 5%-of-CIV NAV methodology — though market rent typically differs.",
        category: "financial",
        keywords: ["rent", "rental", "appraisal", "yield", "investment", "income", "per week", "return"],
      },
      {
        question: "What is the stamp duty estimate?",
        answer: "Stamp duty in Victoria depends on purchase price. At a reference of $910,000 (CIV), principal place of residence duty is approximately $49,100. Investor rate is the same in Victoria. Exact duty is calculated at settlement on the contract price. Use the SRO Victoria stamp duty calculator at sro.vic.gov.au.",
        category: "financial",
        keywords: ["stamp duty", "duty", "transfer", "government charge", "cost", "purchase", "SRO"],
      },
      {
        question: "Is vacant possession offered?",
        answer: "Yes. The property is sold with vacant possession — no lease or tenancy is in place per the Section 32 (lease box unchecked). The vendor is an investment entity (not owner-occupied) but offers vacant possession at settlement.",
        category: "legal",
        keywords: ["vacant possession", "vacant", "tenancy", "lease", "tenant", "empty", "possession"],
      },
      {
        question: "What inclusions are in the sale?",
        answer: "All fixed floor coverings, electric light fittings, window furnishings and all fixtures and fittings of a permanent nature as inspected (COS Goods clause). Note Special Condition 5: the vendor makes no representations or warranties regarding solar panels if installed — buyers should inspect and satisfy themselves as to any solar system present.",
        category: "legal",
        keywords: ["inclusions", "included", "fixtures", "fittings", "floor coverings", "light fittings", "solar", "window", "goods"],
      },
      {
        question: "Are there any notices or orders on the property?",
        answer: "No. Section 32 confirms: Notices and Orders (Item 4.1) — Not Applicable. No compulsory acquisition (Item 4.3 — No). No agricultural chemicals used (Item 4.2 — No). No GAIC recording and no Work-in-Kind Agreement (Item 7). No CIPT or Windfall Gains Tax liability.",
        category: "legal",
        keywords: ["notices", "orders", "compulsory", "acquisition", "GAIC", "chemicals", "agricultural", "notices"],
      },
      {
        question: "What is the Aboriginal cultural heritage status?",
        answer: "The property is in an 'area of cultural heritage sensitivity' under the Aboriginal Heritage Regulations 2018. The registered Aboriginal party is the Bunurong Land Council Aboriginal Corporation. For the existing dwelling, this is noted for information only. Significant future works (e.g. major excavation or subdivision) may trigger a Cultural Heritage Management Plan requirement.",
        category: "planning",
        keywords: ["aboriginal", "cultural heritage", "bunurong", "indigenous", "sensitivity", "CHMP"],
      },
      {
        question: "What are the special conditions in the contract?",
        answer: "SC1: Property sold as inspected — no warranty on defects or contamination. SC2: GC 9 and 12 deleted; breach/default periods reduced from 14 to 7 days (GC 21.2 and 22.2). SC3: Purchaser prepares Statement of Adjustments 5 days prior to settlement ($150+GST if late). SC4: Purchaser warrants Australian residency — no FIRB approval required. SC5: No warranty on solar panels. SC6: Nomination deed — $330+GST (or $440+GST if under 10 days). SC7: Settlement variation by Deed of Variation ($220+GST vendor's costs). SC8: Finance — loan application evidence required; no automatic extension period. SC9: Default — 15% p.a. interest, $300+GST extra vendor legal costs, land tax exposure if settlement delayed into new calendar year.",
        category: "legal",
        keywords: ["special conditions", "contract", "conditions", "finance", "default", "FIRB", "settlement", "SC1", "SC2", "nomination"],
      },
      {
        question: "What council manages this property?",
        answer: "City of Casey. Council Property Number: 89644. Contact: 03 9705 5200, caseycc@casey.vic.gov.au, www.casey.vic.gov.au. PO Box 1000, Narre Warren VIC 3805. ABN: 43 320 295 742. Casey Planning Scheme applies.",
        category: "location",
        keywords: ["council", "casey", "local government", "LGA", "council area", "rates", "casey.vic.gov.au"],
      },
      {
        question: "What comparable sales are there?",
        answer: "Comparable sales data is TBD — to be populated with recent Berwick sales. As a guide, established 4-bedroom homes in Berwick's PS516565X-era estates have been selling in the $860,000–$950,000 range (2025–2026). The CIV of $910,000 (City of Casey, 01/07/2025) provides a useful government reference point.",
        category: "financial",
        keywords: ["comparable", "sales", "recent", "sold", "comps", "comparable sales", "market", "evidence"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 502 — 15 Hartsmere Drive, Berwick VIC 3806 (SOLD 02 May 2026, $845,000)
  // Title: Vol 10668 Folio 940 | Lot 293 PS444491A | Casey Council prop no. 81609
  // Covenant AC906027Q | S173 Agreement P168642E (Kingsmere Estate) | CBA mortgage AS783842A
  // Tenant: Stefan Gerard and Ann Maria (property sold subject to residential tenancy)
  // Source: Contract & Section 32 — 15 Hartsmere Drive, Berwick.pdf (75 pages)
  // -------------------------------------------------------------------------
  502: {
    propertyId: 502,
    address: "15 Hartsmere Drive",
    suburb: "Berwick VIC 3806",
    status: "sold",
    soldDate: "02 May 2026",
    soldPrice: 845000,

    // PHYSICAL
    beds: 3,
    baths: 2,
    cars: 2,
    landSqm: 718,
    houseSqm: "TBD",
    yearBuilt: 2003,
    propertyType: "House",
    frontageMetre: "TBD",
    depthMetre: "TBD",
    propertyShape: "Lot 293 on Plan of Subdivision PS444491A (Kingsmere Estate Stage 5A, Berwick). Refer PS444491A plan sheets for exact boundaries and dimensions. 15.24m excavation depth limitation applies to all land in PS444491A.",
    orientation: "TBD — confirm at inspection",
    pool: false,
    gardenSqm: "TBD",
    shed: false,
    outdoorEntertaining: true,
    alfrescoSqm: "TBD",
    roofType: "TBD",
    externalCladding: "Rendered brick veneer — 'striking rendered façade' per property description. Covenant AC906027Q mandates outer walls brick or brick veneer (render permitted over brick veneer).",
    construction: "Brick veneer (rendered). Covenant AC906027Q mandates outer walls brick or brick veneer. Kingsmere Estate Stage 5A (PS444491A), circa 2003 construction.",
    floorplanConfig: "3 bed, 2 bath, double garage. Open plan living/dining/kitchen with stone benchtops. Alfresco entertaining area.",

    // LEGAL & TITLE
    titleType: "Torrens — Vol 10668 Folio 940 (Lot 293 PS444491A). Kingsmere Estate Stage 5A. Casey City Council Property No. 81609. CBA mortgage AS783842A must be discharged at settlement.",
    easements: "Easements from PS444491A apply to Lot 293 (Kingsmere Estate Stage 5A). Standard estate easements include: E-1 Sewerage (Melbourne Water Corporation / South East Water Ltd), E-2 Drainage and Sewerage (Casey City Council / South East Water Ltd), E-3 Drainage and Sewerage (created by PS444491A), E-4 Powerline (TXU Networks Pty Ltd — s88 Electricity Industry Act 2000). 15.24m excavation depth limitation applies to all land in PS444491A. Confirm specific easement positions on Lot 293 from PS444491A plan sheets. No structures within easements or within 1m of SEW assets without prior written approval from South East Water.",
    covenants: "Restrictive Covenant AC906027Q — single dwelling, minimum floor area 17 squares (~157.9 sqm); outer walls to be brick or brick veneer (render permitted — this property has rendered façade); no caravans, boats or mobile homes used as permanent fixtures in visible areas; domestic pets only; no re-subdivision by Plan of Subdivision, Strata Subdivision or Cluster Titles. Runs with land permanently. S173 Agreement P168642E (registered 04/05/1989 — City of Berwick, Allen's Vegetable Farms Pty Ltd, Hooker Corporation Ltd, RVA Pty Ltd): (1) construct noise attenuation mounds along Princes Freeway (M1) reservation adjacent to Kingsmere Estate boundary; (2) subdivide only in accordance with Berwick Residential Normal Density Zone. Obligation (1) performed by developer at estate completion c.2002. Remains on title as historic encumbrance. Runs with all land derived from Crown Allotments 31C and 31E, Parish of Berwick (entire Kingsmere Estate).",
    overlays: "Bushfire Prone Area (BPA) — confirmed YES (S32 Vendor Statement section 3.3 and Planning Property Report). Any future building works on this lot must comply with applicable Bushfire Attack Level (BAL) requirements under Building Act 1993 and AS 3959. For the existing established dwelling, BPA designation is informational only. No additional planning overlays (heritage, design, floodway, etc.) identified for this established Kingsmere Estate residential lot. Zone: GRZ1 (General Residential Zone Schedule 1).",
    s32Status: "Section 32 Vendor Statement prepared and executed — investment property sold subject to existing residential tenancy (tenants: Stefan Gerard and Ann Maria). Title: Vol 10668 Folio 940 (Lot 293 PS444491A). GRZ1 zoning. BPA: YES (section 3.3 confirmed). No owners corporation. All services connected (electricity, gas, water, sewer, telephone). CBA mortgage AS783842A to be discharged at settlement. SRO clearance certificate included. Sold 02 May 2026 for $845,000.",
    encumbrances: "1. Mortgage AS783842A — Commonwealth Bank of Australia (CBA) — to be discharged at settlement. 2. Covenant AC906027Q — restrictive covenant — see covenants field. 3. Agreement P168642E — S173 Planning and Environment Act 1987 — see covenants field.",
    ownerOccupied: false,
    zoning: "GRZ1 — General Residential Zone Schedule 1 (Casey Planning Scheme). Casey City Council Property No. 81609.",
    rightOfWay: "None",
    sewerEasement: "Yes — sewerage and drainage easements from PS444491A apply to Lot 293. Confirm specific easement positions from PS444491A plan sheets. No building or filling within 1m of any South East Water asset without prior written approval.",
    contaminatedLand: false,
    buildingPermitsOutstanding: "None identified in S32 — confirm directly with Casey Council for full permit history. Original construction circa 2003.",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "Section 32 signed — sale completed 02/05/2026. See Vendor's Statement for execution date.",

    // FINANCIAL
    priceMin: 0,
    priceMax: 0,
    vendorReserve: 0,
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 430,
    rentalAppraisalHigh: 490,
    grossYieldAtAsk: 2.8,
    councilRates: 2473,
    waterRates: 704,
    bodyCorporateFees: 0,
    stampDutyEstimate: 44700,
    landTaxThreshold: "Investment property (not PPOR) — investor land tax on single holding with SV $605,000: approx $2,565/yr ($1,350 + ($605,000 - $300,000) x 0.3 cents). No CIPT (AVPCC 110, residential). No Windfall Gains Tax. SRO clearance certificate included in S32 pack.",
    depreciationYear1Est: 7500,
    capitalGainsHistory: "Investment property sold subject to residential tenancy. CIV as at 01/07/2025: $790,000. Site Value (SV): $605,000. Net Annual Value (NAV): ~$39,500. Sold 02 May 2026 for $845,000. Original construction circa 2003 (Kingsmere Estate Stage 5A, Lot 293 PS444491A). CBA mortgage AS783842A discharged at settlement.",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School — 'steps to Berwick Primary' per property description. Confirm current catchment at findmyschool.vic.gov.au.",
    primarySchoolRating: "Good — well-regarded inner Berwick primary school with strong community reputation",
    secondarySchool: "Berwick Secondary College or Kambrya College — confirm current catchment with City of Casey",
    secondarySchoolRating: "Good — Berwick Secondary College and Kambrya College are established schools. Nossal High School (selective entry, ~10km) is a popular choice for high achievers.",
    schoolZoneCatchment: "Berwick Primary School (primary — walking distance per description). Secondary: confirm with Casey Council or findmyschool.vic.gov.au. Timbarra area of Berwick.",
    distanceToTrainKm: 1.8,
    trainLine: "Pakenham Line — Berwick Station (approx 1.8km). Approx 45 min to Flinders Street Station.",
    distanceToFreewayKm: 0.4,
    distanceToShoppingKm: 0.5,
    nearestHospitalKm: 7.4,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 850000,
    daysOnMarketAvg: 30,
    clearanceRatePct: 74,
    comparableSales: [
      { address: "15 Hartsmere Drive, Berwick", price: 845000, date: "May 2026", beds: 3 },
      { address: "32 Hartsmere Drive, Berwick", price: 820000, date: "Feb 2026", beds: 4 },
      { address: "4 Sunnyside Drive, Berwick", price: 843000, date: "Mar 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "Stylish kitchen with stone benchtops (confirmed per property description). Open plan kitchen/living/dining.",
    bathroomRenovated: "Two bathrooms — ensuite to master bedroom, main bathroom. Original circa 2003 or updated — confirm condition at inspection.",
    flooringType: "TBD — confirm at inspection. Typically carpet to bedrooms, tiles to living/kitchen/wet areas for circa 2003 Berwick construction.",
    airConType: "TBD — confirm at inspection and inclusions list",
    heatingType: "TBD — ducted heating typical for Berwick estate homes of this era. Confirm at inspection.",
    solarKw: "TBD",
    batteryStorage: false,
    evCharging: false,
    nbnType: "TBD — NBN available in Berwick. FTTN or FTTC typical for Kingsmere Estate. Confirm with NBN Co.",
    waterTank: false,
    alarmSystem: "TBD",
    smartHome: false,
    disabilityAccess: false,
    petsAllowed: true,
    outdoorFeatures: "Alfresco entertaining area (confirmed per property description). Double garage. Rendered façade — striking street presentation. No pool. Confirm alfresco size and garden at inspection.",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Possible — GRZ1 allows extensions subject to Casey planning permit and setback requirements. Covenant AC906027Q limits to single dwelling (minimum 17 squares / ~158 sqm) — extension must maintain single-dwelling use. BPA designation means any building works (including extensions) must comply with applicable BAL requirements under Building Act 1993 and AS 3959. Recommend BAL assessment prior to planning any extension.",
    councilDevelopmentHistory: "Original construction circa 2003 (PS444491A Stage 5A lot). No additional building permits referenced in S32. Confirm directly with Casey Council for full permit history.",
    neighbourhoodDescription: "Kingsmere Estate, Berwick — Stage 5A. Hartsmere Drive — established, low-traffic residential street. Steps to Berwick Primary School and Timbarra Village Shopping. Close to Princes Freeway (M1) access. Casey City Council. S173 Agreement P168642E noise attenuation mounds completed along M1 boundary by developer c.2002.",
    trafficNoiseLevel: "Low to moderate — established residential street in Kingsmere Estate. Close to Princes Freeway (M1) but noise attenuation mounds along M1 boundary per S173 P168642E. BPA designation notes proximity to natural environment. Inspect at various times of day.",
    flightPathFlag: false,
    futureInfrastructure: "Casey growth corridor — continued development in surrounding areas. Timbarra shopping and community infrastructure nearby. No direct road acquisition proposals affecting this property per VicRoads certificate included in S32. Princes Freeway (M1) already established — noise mounds completed c.2002.",
    floodZone: false,
    vendorMotivation: "Investment property — sold subject to residential tenancy (Stefan Gerard and Ann Maria in occupation). CBA mortgage AS783842A to be discharged at settlement. Sold 02 May 2026 at $845,000.",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: "TBD",
    priceReductionHistory: "None — sold at $845,000 (02 May 2026)",
    tenantInPlace: true,
    tenantLeaseEndDate: "Tenants: Stefan Gerard and Ann Maria — lease type, rent, bond, and end date per residential tenancy agreement in S32. Confirm all lease terms with agent.",
    vendorPreferredSettlement: "60 days (standard per Contract of Sale)",
    vendorFlexOnInclusions: "Standard inclusions per COS — all fixtures and fittings as inspected, subject to existing tenancy obligations",
    inclusions: "All fixtures and fittings as inspected (per COS). Stone kitchen benchtops, alfresco structure, double garage. Confirm specific inclusions with agent — sold subject to existing residential tenancy.",

    qa: [
      {
        question: "What is the land size and lot details?",
        answer: "718 sqm confirmed — Lot 293 on PS444491A (Kingsmere Estate Stage 5A), Vol 10668 Folio 940. Casey City Council property no. 81609. 15.24m excavation depth limitation applies to all land in PS444491A. Larger than many Kingsmere Estate lots at 718 sqm.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "title", "718"],
      },
      {
        question: "What covenants and restrictions affect this property?",
        answer: "Two registered encumbrances: (1) AC906027Q — restrictive covenant: single dwelling minimum 17 squares (~158 sqm), brick/brick veneer outer walls (render permitted — this property has rendered façade), no re-subdivision, no caravans/boats/mobile homes as permanent fixtures, domestic pets only. (2) P168642E — S173 agreement (1989) for entire Kingsmere Estate: noise attenuation mounds along M1 freeway (obligation performed by developer c.2002); subdivision restricted to residential normal density zone. Both run with land permanently.",
        category: "legal",
        keywords: ["covenant", "restriction", "s173", "encumbrance", "build", "subdivision", "material", "AC906027Q"],
      },
      {
        question: "Is there a mortgage on the property?",
        answer: "Yes — Commonwealth Bank of Australia (CBA) mortgage AS783842A. Must be fully discharged at settlement before title transfers to purchaser.",
        category: "legal",
        keywords: ["mortgage", "loan", "bank", "discharge", "encumbrance", "title", "cba", "commonwealth", "AS783842A"],
      },
      {
        question: "What are the council rates?",
        answer: "$2,473.26 per year (Casey City Council, Property No. 81609). Includes General Rates, Garbage Charge, and ESVF Levy as per Casey Land Information Certificate. Confirm current outstanding balance with Casey Council closer to settlement.",
        category: "financial",
        keywords: ["council", "rates", "annual", "levy", "garbage", "esvf", "casey", "lic", "2473"],
      },
      {
        question: "What are the water rates?",
        answer: "South East Water charges approximately $176.08 per quarter ($704 annualised). Includes Parks Victoria, Melbourne Water infrastructure, SEW Water Service and Sewerage charges. Water usage charged separately per metered consumption. No recycled water available in this area (confirmed SEW asset map). Confirm current outstanding balance with SEW at settlement.",
        category: "financial",
        keywords: ["water", "rates", "south east water", "sewerage", "quarterly", "annual", "sew", "176"],
      },
      {
        question: "What are the property valuations?",
        answer: "As at 01/07/2025 (Casey Land Information Certificate): Site Value (SV) $605,000, Capital Improved Value (CIV) $790,000, Net Annual Value (NAV) ~$39,500. Property sold 02 May 2026 for $845,000 — sold above CIV, reflecting strong demand for established 3-bed Berwick homes with large 718 sqm blocks.",
        category: "financial",
        keywords: ["valuation", "site value", "civ", "capital improved", "nav", "sv", "605000", "790000"],
      },
      {
        question: "What is the land tax situation?",
        answer: "Investment property — vendor not exempt as PPOR. Single investor holding with SV $605,000: approx $2,565/yr ($1,350 + ($605,000 - $300,000) x 0.3 cents). Purchaser's land tax liability assessed from date of settlement. No CIPT (AVPCC 110, residential). No Windfall Gains Tax. SRO clearance certificate included in S32 pack.",
        category: "financial",
        keywords: ["land tax", "sro", "investor", "ppor", "exempt", "wgt", "cipt", "605000", "land tax investment"],
      },
      {
        question: "Who are the tenants and what are the lease details?",
        answer: "Tenants: Stefan Gerard and Ann Maria. Property sold subject to existing residential tenancy. Purchaser inherits landlord obligations under the Residential Tenancies Act 1997 (Vic). Lease type (periodic/fixed), rent amount, bond, and end date are detailed in the residential tenancy agreement in the S32. If vacant possession is required, this must be negotiated with the vendor prior to contract.",
        category: "legal",
        keywords: ["tenant", "lease", "renter", "occupant", "rental", "residential tenancy", "lease end", "stefan", "ann", "vacant possession"],
      },
      {
        question: "Is the property in a bushfire prone area?",
        answer: "YES — confirmed Bushfire Prone Area (BPA) per S32 Vendor Statement section 3.3 and Planning Property Report. For the existing established dwelling, BPA is informational — no immediate action required. Any future building works (extensions, new structures, alterations) must comply with applicable Bushfire Attack Level (BAL) requirements under the Building Act 1993 and Australian Standard AS 3959. A BAL assessment may be required before obtaining a building permit for works.",
        category: "planning",
        keywords: ["bushfire", "fire", "prone", "bpa", "hazard", "building act", "bal", "bushfire prone area", "AS3959"],
      },
      {
        question: "Are there any easements?",
        answer: "Yes — multiple easements from PS444491A apply to Lot 293 (Kingsmere Estate Stage 5A). Includes: E-1 Sewerage (Melbourne Water Corp and South East Water Ltd), E-2 Drainage and Sewerage (Casey City Council and SEW), E-3 Drainage and Sewerage (created by PS444491A), E-4 Powerline (TXU Networks under Electricity Industry Act 2000). 15.24m excavation depth limitation applies to all land in PS444491A. No structures within easements or within 1m of SEW assets without prior written approval.",
        category: "legal",
        keywords: ["easement", "sewer", "drainage", "powerline", "restriction", "build", "easements", "PS444491A"],
      },
      {
        question: "What is the S173 agreement on this property?",
        answer: "P168642E (1989) is a Section 173 Planning and Environment Act agreement running with ALL land in Kingsmere Estate (Crown Allotments 31C and 31E, Parish of Berwick). Developer obligations: (1) construct noise attenuation mounds along Princes Freeway (M1) reservation — completed at estate development c.2002; (2) develop only as Berwick Residential Normal Density Zone — completed. Agreement remains registered on title as a historic encumbrance with minimal ongoing practical obligation for current owners.",
        category: "legal",
        keywords: ["s173", "agreement", "freeway", "noise", "mound", "kingsmere", "planning", "encumbrance", "P168642E"],
      },
      {
        question: "What is the planning zone and what can I build?",
        answer: "GRZ1 — General Residential Zone Schedule 1 (Casey Planning Scheme). Permits single dwellings and standard residential use. Maximum site coverage 55%, minimum open space 20% or 80 sqm. Covenant AC906027Q further restricts to single dwelling (minimum 17 squares / ~158 sqm), brick/brick veneer construction, no re-subdivision. BPA designation: any building works must comply with BAL requirements. Contact Casey Council for planning permit requirements before undertaking any works.",
        category: "planning",
        keywords: ["zone", "planning", "grz1", "general residential", "casey", "planning scheme", "build", "development", "permit"],
      },
      {
        question: "Is the property in a flood zone?",
        answer: "No. South East Water Information Statement (included in S32) confirms this property is not subject to flooding from Melbourne Water's drainage system based on 1% annual probability flood level assessment.",
        category: "planning",
        keywords: ["flood", "flooding", "flood prone", "flood zone", "flood risk", "drainage risk"],
      },
      {
        question: "What school zone does this property fall in?",
        answer: "Berwick Primary School — property description states 'steps to Berwick Primary'. Confirm current catchment at findmyschool.vic.gov.au before purchase as boundaries can change. Secondary: Berwick Secondary College or Kambrya College — confirm with City of Casey. Nossal High School (selective entry, ~10km) is a popular choice for high achievers.",
        category: "location",
        keywords: ["school", "zone", "catchment", "primary", "secondary", "berwick", "education", "berwick primary", "kambrya"],
      },
      {
        question: "Is there an owners corporation?",
        answer: "No owners corporation. S32 and title search confirm no OC applicable to Lot 293 (PS444491A). No body corporate fees payable.",
        category: "legal",
        keywords: ["owners corporation", "oc", "body corporate", "strata", "fees"],
      },
      {
        question: "Is subdivision possible?",
        answer: "No. Restrictive covenant AC906027Q expressly prohibits re-subdivision of Lot 293 by Plan of Subdivision, Strata Subdivision or Cluster Titles. The S173 Agreement P168642E also restricts development to residential normal density zone. At 718 sqm, re-subdivision into standard residential lots would also be unlikely to achieve minimum lot size requirements under GRZ1.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "split", "two lots", "potential"],
      },
      {
        question: "Is a granny flat or dual occupancy possible?",
        answer: "No. Covenant AC906027Q limits Lot 293 to a single dwelling (minimum 17 squares / ~158 sqm floor area). A second independent dwelling would conflict with the covenant's single-dwelling restriction. Enforcement rests with beneficiary parties (other lots in Kingsmere Estate, PS444491A).",
        category: "planning",
        keywords: ["granny flat", "dual occ", "second dwelling", "secondary", "build behind", "additional"],
      },
      {
        question: "What services are connected?",
        answer: "All services connected: electricity, gas, water, sewerage, and telephone (confirmed in Section 32). South East Water supplies water and sewerage. No recycled water available in this area (confirmed SEW asset map). NBN: confirm connection type — FTTN or FTTC typical for Berwick estates of this vintage.",
        category: "physical",
        keywords: ["services", "electricity", "gas", "water", "sewer", "telephone", "nbn", "connected", "recycled"],
      },
      {
        question: "How close is the property to shops, transport and the freeway?",
        answer: "Walking distance to Timbarra Village Shopping ('steps to Timbarra shopping' per description, approx 0.5km). Princes Freeway (M1) access approximately 0.4km — excellent freeway connectivity. Berwick Station (Pakenham Line) approximately 1.8km — approx 45 min to Flinders Street Station. Berwick Primary School within walking distance. Casey Hospital approximately 7.4km.",
        category: "location",
        keywords: ["shops", "shopping", "transport", "train", "freeway", "proximity", "timbarra", "berwick station", "m1", "pakenham"],
      },
      {
        question: "What are the special conditions in the contract?",
        answer: "Standard special conditions apply: finance condition (loan application evidence required), FIRB warranty (purchaser warrants ordinary Australian resident), nomination deed provision ($330+GST), settlement variation provisions, and default interest clause (15% p.a.). Importantly, property is sold subject to existing residential tenancy — purchaser assumes landlord role at settlement. Confirm all special conditions with your conveyancer before signing.",
        category: "legal",
        keywords: ["special conditions", "contract", "conditions", "finance", "default", "FIRB", "settlement", "nomination"],
      },
      {
        question: "Is there a VicRoads road acquisition proposal?",
        answer: "No proposals as at the VicRoads certificate date included in the S32. Princes Freeway (M1) reservation is already established — does not affect Lot 293 title. Noise attenuation mounds per S173 P168642E have been completed by developer c.2002. No further road works affecting this property identified.",
        category: "planning",
        keywords: ["vicroads", "road", "acquisition", "proposal", "freeway", "reserve"],
      },
      {
        question: "What is the Section 32 status?",
        answer: "Section 32 Vendor Statement prepared and executed — investment property sold subject to residential tenancy (Stefan Gerard and Ann Maria). Title: Vol 10668 Folio 940 (Lot 293 PS444491A). CBA mortgage AS783842A to be discharged at settlement. BPA: YES (confirmed section 3.3). All services connected. GRZ1 zoning. Casey Council Prop No. 81609. SV $605,000, CIV $790,000. Rates $2,473.26/yr. Property sold 02 May 2026 for $845,000.",
        category: "legal",
        keywords: ["s32", "section 32", "vendor statement", "signed", "ready", "status", "contract"],
      },
      {
        question: "What comparable sales are there?",
        answer: "15 Hartsmere Drive sold 02 May 2026 for $845,000 (3 bed, 2 bath, 2 car, 718 sqm — strong result for large-block Berwick home with rendered façade and stone kitchen). Nearby: 32 Hartsmere Drive ~$820,000 (Feb 2026, 4-bed), 4 Sunnyside Drive ~$843,000 (Mar 2026, 4-bed). The 718 sqm land holding adds value above average Kingsmere Estate lots. Median 3-bed Berwick house approximately $820,000–$870,000 (2026).",
        category: "financial",
        keywords: ["comparable", "sales", "recent", "sold", "comps", "comparable sales", "market", "evidence", "845000"],
      },
      {
        question: "What council manages this property?",
        answer: "City of Casey. Council Property Number: 81609. Contact: 03 9705 5200, caseycc@casey.vic.gov.au, www.casey.vic.gov.au. PO Box 1000, Narre Warren VIC 3805. ABN: 43 320 295 742. GRZ1 (General Residential Zone Schedule 1) under Casey Planning Scheme.",
        category: "location",
        keywords: ["council", "casey", "local government", "LGA", "council area", "rates", "casey.vic.gov.au", "81609"],
      },
      {
        question: "Is the property sold with vacant possession or subject to lease?",
        answer: "Property sold SUBJECT TO LEASE — tenants Stefan Gerard and Ann Maria are in occupation at time of sale (02 May 2026). Purchaser assumes role of landlord at settlement with all obligations under the Residential Tenancies Act 1997 (Vic). Lease terms, rent, bond lodgement and end date are in the residential tenancy agreement provided in the Section 32 pack. Vacant possession requires separate negotiation prior to contract.",
        category: "legal",
        keywords: ["vacant possession", "tenancy", "lease", "tenant", "subject to lease", "landlord", "residential tenancies act", "stefan", "ann"],
      },
    ],
  },

  // -------------------------------------------------------------------------
  // 501 — 40 Jack William Way, Berwick VIC 3806 (SOLD — 25 May 2026, $805,000)
  // SLM data: Extracted from Contract of Sale / Section 32 (84 pages)
  // Title: Vol 10794 Folio 444 | Lot 90 on PS516565X
  // Vendor: Alan Waller Melville (sole proprietor, AM371405Y 02/12/2015)
  // Title search: 11/03/2026 | LIC wCerR/C077688: 11/03/2026 | SEW Case 51647924: 11/03/2026
  // SRO Cert 98153904: 11/03/2026 | Planning Cert 1233888: 11/03/2026 | VicRoads: 11/03/2026
  // Casey Building Surveying CerB/W036705: 13/03/2026
  // -------------------------------------------------------------------------
  501: {
    propertyId: 501,
    address: "40 Jack William Way",
    suburb: "Berwick VIC 3806",
    status: "sold",
    soldDate: "25 May 2026",
    soldPrice: 805000,

    // PHYSICAL
    beds: 3,
    baths: 2,
    cars: 2,
    landSqm: 468,
    houseSqm: "TBD",
    yearBuilt: "TBD",
    propertyType: "House",
    frontageMetre: "TBD",
    depthMetre: "TBD",
    propertyShape: "Lot 90 on Plan of Subdivision PS516565X (Jack William Way estate, registered 13/04/2004). Refer PS516565X plan sheets for exact lot boundaries and dimensions. Planning Certificate map shows Lot 90 (SPI=90\\PS516565) between lots 38, 42, 44 on Jack William Way — confirm frontage and depth from plan.",
    orientation: "TBD — confirm at inspection",
    pool: "TBD",
    gardenSqm: "TBD",
    shed: "TBD",
    outdoorEntertaining: "TBD",
    alfrescoSqm: "TBD",
    roofType: "TBD",
    externalCladding: "TBD — Covenant AD606000B requires ≥75% external walls (excluding windows) in brick, brick veneer, stone, masonry or masonry veneer. Confirm construction type at inspection.",
    construction: "Established residential dwelling in PS516565X subdivision estate (plan registered 13/04/2004, Parish of Berwick, Crown Portion 35, origin 348-356 Clyde Road, Berwick). Capital Improved Value $710,000 (City of Casey valuation 01/07/2025). NIL building permits in last 10 years (Casey CerB/W036705, 13/03/2026). Covenant AD606000B mandates minimum floor area 150 sqm (excl verandah/carport/garage), single dwelling, and specific external cladding standards.",
    floorplanConfig: "3 bedrooms, 2 bathrooms, 2-car garage. Minimum dwelling floor area 150 sqm per restrictive covenant AD606000B (excluding verandah, carport, garage). Confirm internal configuration at inspection.",

    // LEGAL & TITLE
    titleType: "Torrens — Volume 10794 Folio 444 (Lot 90 on Plan of Subdivision 516565X). SPI: 90\\PS516565X. Estate Fee Simple, Sole Proprietor. Registered proprietor: Alan Waller Melville (2 Stonebridge Lane, Pakenham VIC 3810) by instrument AM371405Y dated 02/12/2015. Parent Title: Volume 10776 Folio 201 (LP86153 — Lot 2 of 348-356 Clyde Road, Berwick, being Crown Portion 35, Parish of Berwick, County of Mornington). Title created by instrument PS516565X registered 13/04/2004. eCT controlled by Adelaide Bank (Bendigo and Adelaide Bank Ltd), instrument 19018X, effective 03/03/2021. Title search produced 11/03/2026, Security Number: 124132871474N. No dealing activity in last 125 days (NIL).",
    easements: "E-1: Sewerage easement (origin PS509027T, benefiting South East Water Ltd). E-2: Drainage and Sewerage easement (origin PS516565X, benefiting lots on plan and South East Water Ltd). E-1: Drainage and Sewerage easement (origin PS509027T, benefiting lots on PS509027T). No structures may be built over or within 1 metre of easements without South East Water written consent. SEW asset plans (Case 51647924, 11 March 2026) confirm 225mm uPVC sewer mains in adjacent streets (Moondarra Drive), installed 2002–2003.",
    covenants: "COVENANT AD606000B (registered 10/05/2005, Transfer of Land Act 1958) — restricts Lot 90 to: (a) single private dwelling house only; minimum floor area 150 sqm (excl verandah, carport, garage); ≥75% of external walls (excl windows) in brick, brick veneer, stone, masonry or masonry veneer; outbuildings must use brick, stone, rendered concrete, concrete sheet, timber or coloured non-reflective material; roof must be masonry/terracotta tiles or coloured non-reflective roofing; no external plumbing visible from street (except stormwater downpipes); (b) no fence >2m height on side/rear boundary; timber palings must have timber cap and posts exposed both sides; front fence ≤1.5m and must be <50% transparent if height exceeds 1.2m; (c) no vehicle ≥1 tonne, boat, caravan or trailer stored/parked visible from street; (d) no external clothes dryer or air conditioner visible from street; (e) minimum 5m setback from front boundary; (f) no advertising signs (except property-for-sale sign once dwelling constructed). Runs with Lot 90 and all lots on PS509027T. NOTE: Lot 90 is NOT subject to the Building Envelope Restriction in PS516565X Sheet 5 — that restriction applies ONLY to Lots 76–81.",
    overlays: "No planning overlays. Planning Certificate No. 1233888 (11 March 2026, issued under Section 199 Planning and Environment Act 1987 by Minister for Planning Sonya Kilkenny): 'The land is included in a GENERAL RESIDENTIAL ZONE — SCHEDULE 1.' No Heritage Overlay, Environmental Overlay, Flood Overlay, Vegetation Overlay, or any other overlay is listed. Casey Planning Scheme applies.",
    s32Status: "Section 32 Vendor Statement complete. Vendor: Alan Waller Melville (sole proprietor). Conveyancer: Premier Conveyancing Group Pty Ltd, Suite 5, 28-32 Gloucester Avenue, Berwick (Ref AK:260200). All certificates obtained: Title search 11/03/2026 (Security No. 124132871474N), Land Information Certificate wCerR/C077688 (11/03/2026, Casey Property No. 89621), SEW Information Statement Case 51647924 (11/03/2026), SRO Property Clearance Certificate No. 98153904 (11/03/2026), Planning Certificate 1233888 (11/03/2026), VicRoads Roads Property Certificate (11/03/2026), Casey Building Surveying Certificate CerB/W036705 (13/03/2026). Sold 25/05/2026 for $805,000.",
    encumbrances: "1. MORTGAGE AT982163D (25/01/2021) — Bendigo and Adelaide Bank Ltd — discharged at settlement. eCT control: 19018X Adelaide Bank (Bendigo and Adelaide Bank Ltd), effective 03/03/2021. 2. COVENANT AD606000B (10/05/2005) — Transfer of Land Act 1958 design and use restrictions — see covenants field. 3. AGREEMENT AC424222D (23/10/2003) — Section 173 Planning and Environment Act 1987, Community Infrastructure Levy Agreement (Casey City Council / Lyngreye Pty Ltd / Newland Developments Pty Ltd) — CIL of $325/lot (CPI-adjusted quarterly from 1 April 1998) was payable before any building permit for Lot 90; obligation effectively spent for the existing dwelling. Agreement remains on title as historic encumbrance.",
    ownerOccupied: true,
    zoning: "GRZ1 — General Residential Zone Schedule 1 (Casey Planning Scheme). Casey Property Number: 89621. SRO Land Id: 31507702.",
    rightOfWay: "None. Road access via public road Jack William Way vested in City of Casey (PS516565X — Roads R-1, City of Casey). VicRoads Roads Property Certificate (11/03/2026, Certificate No. 79908375): 'NO PROPOSALS — VicRoads has no approved proposals requiring any part of the property as at 11th March 2026.'",
    sewerEasement: "Yes — E-1 (Sewerage, origin PS509027T, South East Water Ltd) and E-2 (Drainage and Sewerage, origin PS516565X, benefiting lots on plan and South East Water Ltd) shown on plan. SEW asset map (Case 51647924, 11 March 2026) confirms sewer infrastructure in adjacent streets. No building or filling within easements or within 1m of any South East Water asset without prior written SEW approval.",
    contaminatedLand: false,
    buildingPermitsOutstanding: "NIL — Casey City Council Building Surveying Services confirms no building permits issued in last 10 years (Certificate CerB/W036705, Search Date 13 March 2026, Legal Description Lot 90 PS 516565X). Property not subject to any notices or orders under the Building Act 1993. SC12 (Swimming Pool/Spa special condition) is included in the contract — if a pool/spa is present, its building permit predates the 10-year search window.",
    ownerBuilderWork: false,
    titlesOfficeReady: true,
    section32CompletionDate: "11/03/2026 (title search, LIC wCerR/C077688, SEW statement Case 51647924, SRO clearance 98153904, Planning Certificate 1233888, VicRoads certificate 79908375) / 13/03/2026 (Casey Building Surveying Certificate CerB/W036705). Property sold 25/05/2026.",

    // FINANCIAL
    priceMin: 805000,
    priceMax: 805000,
    vendorReserve: 0,
    settlementTermsDays: 60,
    depositPct: 10,
    rentalAppraisalLow: 490,
    rentalAppraisalHigh: 570,
    grossYieldAtAsk: 3.4,
    councilRates: 2284,
    waterRates: 704,
    bodyCorporateFees: 0,
    stampDutyEstimate: 43370,
    landTaxThreshold: "Vendor (Alan Waller Melville) has 2026 land tax $0.00 — exempt as LTX Principal Place of Residence (SRO Property Clearance Certificate No. 98153904, 11/03/2026, Taxable SV $545,000). If not PPR-exempt: land tax calculated as $1,350 plus ($545,000 - $300,000) x 0.300 cents = $2,085.00/year. CIPT (Commercial and Industrial Property Tax): $0.00 (AVPCC 110 — not a qualifying commercial/industrial use). Windfall Gains Tax: $0.00 (no liability identified). Purchaser's own land tax liability assessed from settlement date under Land Tax Act 2005 (Vic).",
    depreciationYear1Est: "TBD",
    capitalGainsHistory: "Vendor (Alan Waller Melville) acquired by instrument AM371405Y dated 02/12/2015. CIV at 01/07/2025: $710,000. Site Value (SV): $545,000. Net Annual Value (NAV): $35,500. Sold 25/05/2026 for $805,000. Not new residential premises — no GST withholding required. Owner-occupied PPR — land tax exempt. SC13 (reduced deposit) accepted.",

    // LOCATION & SUBURB
    primarySchool: "Berwick Primary School (approx 1.5km) — confirm catchment with City of Casey or findmyschool.vic.gov.au",
    primarySchoolRating: "Good — well-regarded inner Berwick primary school",
    secondarySchool: "Berwick Secondary College (approx 2km) — confirm catchment with City of Casey",
    secondarySchoolRating: "Good — established school in the Berwick area",
    schoolZoneCatchment: "Likely Berwick Primary School and Berwick Secondary College — confirm with City of Casey. St Catherine's Catholic Primary School is in the immediate area (referenced in PS516565X planning permit P 430/01 as nearby landmark at time of subdivision).",
    distanceToTrainKm: 1.8,
    trainLine: "Pakenham Line — Berwick Station (approx 1.8km). Approximately 45 minutes to Flinders Street Station.",
    distanceToFreewayKm: 1.5,
    distanceToShoppingKm: 2.0,
    nearestHospitalKm: 3.5,
    suburb5yrGrowthPct: 28,
    suburbMedianPrice: 870000,
    daysOnMarketAvg: 30,
    clearanceRatePct: 65,
    comparableSales: [
      { address: "40 Jack William Way, Berwick", price: 805000, date: "May 2026", beds: 3 },
      { address: "15 Hartsmere Drive, Berwick", price: 845000, date: "May 2026", beds: 3 },
      { address: "32 Hartsmere Drive, Berwick", price: 820000, date: "Feb 2026", beds: 4 },
    ],

    // FEATURES & CONDITION
    kitchenRenovated: "TBD — confirm at inspection",
    bathroomRenovated: "TBD — confirm at inspection",
    flooringType: "TBD — confirm at inspection",
    airConType: "TBD — confirm at inspection",
    heatingType: "TBD — ducted heating typical for Berwick estate homes. Confirm at inspection.",
    solarKw: "TBD",
    batteryStorage: "TBD",
    evCharging: "TBD",
    nbnType: "TBD — telephone connected per S32 Item 8. NBN availability to be confirmed with NBN Co — FTTC or FTTP typically available in Berwick estates of this vintage (post-2004).",
    waterTank: "TBD",
    alarmSystem: "TBD",
    smartHome: "TBD",
    disabilityAccess: "TBD",
    petsAllowed: true,
    outdoorFeatures: "TBD — SC12 (Swimming Pool/Spa special condition) included in contract; confirm whether pool or spa is present at inspection. Double garage. Garden. Confirm alfresco/outdoor entertaining at inspection.",

    // PLANNING & VENDOR
    subdivisionPotential: false,
    dualOccupancyPotential: false,
    grannyFlatApproved: false,
    extensionPotential: "Possible — GRZ1 permits extensions/additions subject to Casey City Council planning permit requirements. Lot 90 (468 sqm) is NOT subject to the Building Envelope Restriction in PS516565X (restriction applies only to Lots 76–81). Site coverage and open space requirements under Casey GRZ1 Schedule 1 apply. Covenant AD606000B requires minimum 5m front setback and restricts land to single residential dwelling use — any extension must maintain single-dwelling character.",
    councilDevelopmentHistory: "NIL building permits in last 10 years (Casey Certificate CerB/W036705, 13/03/2026). Section 173 CIL Agreement (AC424222D) obligation discharged upon original building permit. Planning Permit P 430/01 AMENDED (amended 29 August 2002, applicant Lyngreye Pty Ltd) — original subdivision permit for 348-356 Clyde Road, Berwick — spent. No unregistered dealings on title (Title search 11/03/2026 — NIL activity in last 125 days).",
    neighbourhoodDescription: "Lot 90 on PS516565X — 468 sqm residential property at 40 Jack William Way, Berwick VIC 3806 (City of Casey, Property No. 89621, SRO Land Id 31507702). Part of residential estate on former 348-356 Clyde Road, Berwick (Parish of Berwick, County of Mornington, Crown Portion 35, plan registered 13/04/2004 under Planning Permit P 430/01 — City of Casey). Adjacent streets include Moondarra Drive and Jamieson Court (per SEW asset maps). St Catherine's Catholic Primary School is in the immediate vicinity (referenced in Planning Permit P 430/01). Berwick Station (Pakenham Line) approximately 1.8km. Eden Rise / Berwick Village shopping approximately 2km. Casey Hospital approximately 3.5km. GRZ1 zone. No planning overlays. Not in designated Bushfire Prone Area. Melbourne Water confirms not subject to flooding (1% probability). Fire authority: Country Fire Authority (CFA). Legislative Assembly: Berwick electorate. Legislative Council: South-Eastern Metropolitan Region. Aboriginal cultural heritage: Bunurong Land Council Aboriginal Corporation.",
    trafficNoiseLevel: "Low to moderate — Jack William Way is an internal residential estate street with low through-traffic. Clyde Road (major arterial) and Berwick-Cranbourne Road are in the broader area but not directly fronting this lot.",
    flightPathFlag: false,
    futureInfrastructure: "City of Casey growth corridor. VicRoads Roads Property Certificate (11/03/2026): 'NO PROPOSALS — no approved proposals requiring any part of this property.' No compulsory acquisition notices in Section 32. No GAIC recording. No Windfall Gains Tax (SRO certificate $0.00). CIPT: $0.00 (AVPCC 110 — residential land, not qualifying commercial/industrial use).",
    floodZone: false,
    vendorMotivation: "Owner-occupier — Alan Waller Melville, sole proprietor since 02/12/2015, residing at 2 Stonebridge Lane, Pakenham VIC 3810. Land tax exempt as Principal Place of Residence (SRO confirmed $0.00). Standard residential resale; vacant possession offered at settlement. SC13 (reduced deposit) accepted.",
    vendorTimelineDays: 60,
    previousOffers: false,
    daysOnMarket: 0,
    priceReductionHistory: "None — sold at $805,000 (25 May 2026)",
    tenantInPlace: false,
    tenantLeaseEndDate: "N/A — vacant possession at settlement (no lease in place per S32 Item 11)",
    vendorPreferredSettlement: "60 days standard. SC13 (Reduced Deposit accepted). SC6: default interest at 4% p.a. above the rate set under the Penalty Interest Rates Act 1983.",
    vendorFlexOnInclusions: "Standard inclusions — all fixed floor coverings, electric light fittings, window furnishings and all fixtures and fittings of a permanent nature as inspected. SC12: Swimming Pool/Spa special condition included (confirm pool/spa status at inspection).",
    inclusions: "All fixed floor coverings, electric light fittings, window furnishings and all fixtures and fittings of a permanent nature as inspected. SC12: Swimming Pool/Spa special condition (confirm any pool or spa included in sale at inspection).",

    qa: [
      {
        question: "How big is the land?",
        answer: "468 square metres — confirmed by City of Casey Land Information Certificate (Property No. 89621, Certificate wCerR/C077688, issued 11 March 2026). Property description: Lot 90 PS 516565X, 40 Jack William Way BERWICK VIC 3806. Valuation date 01/07/2025.",
        category: "physical",
        keywords: ["land", "lot", "sqm", "block", "size", "m2", "square", "area", "frontage", "depth", "468"],
      },
      {
        question: "What is the title?",
        answer: "Torrens title — Volume 10794 Folio 444, Lot 90 on Plan of Subdivision 516565X. SPI: 90\\PS516565X. Estate Fee Simple, Sole Proprietor. Registered proprietor: Alan Waller Melville (2 Stonebridge Lane, Pakenham VIC 3810) by instrument AM371405Y dated 02/12/2015. Parent title: Volume 10776 Folio 201. Title created by instrument PS516565X registered 13/04/2004. Title search produced 11/03/2026 (Security Number: 124132871474N). No dealing activity in last 125 days.",
        category: "legal",
        keywords: ["title", "torrens", "folio", "volume", "lot", "plan", "subdivision", "spi", "certificate", "10794", "444"],
      },
      {
        question: "Who is the vendor?",
        answer: "Alan Waller Melville — individual, sole proprietor since 02/12/2015. Vendor address: 2 Stonebridge Lane, Pakenham VIC 3810. Agent: Barry Plant Berwick, 100 High Street, Berwick VIC 3806, (03) 9707 1400 (Manpreet Singh). Vendor's conveyancer: Premier Conveyancing Group Pty Ltd, Suite 5, 28-32 Gloucester Avenue, Berwick (Ref AK:260200).",
        category: "legal",
        keywords: ["vendor", "seller", "owner", "Melville", "Alan Waller", "barry plant", "individual", "Manpreet"],
      },
      {
        question: "What is the zoning?",
        answer: "General Residential Zone Schedule 1 (GRZ1) under the Casey Planning Scheme. Confirmed by Planning Certificate No. 1233888 (11 March 2026, issued under Section 199 Planning and Environment Act 1987 by Minister for Planning Sonya Kilkenny): 'The land is included in a GENERAL RESIDENTIAL ZONE — SCHEDULE 1.' No planning overlays apply. Council: City of Casey.",
        category: "planning",
        keywords: ["zone", "zoning", "planning", "grz", "grz1", "residential", "overlay", "casey", "scheme", "schedule 1"],
      },
      {
        question: "Are there any easements?",
        answer: "Yes — three easement entries on PS516565X: E-1 (Sewerage, origin PS509027T, benefiting South East Water Ltd), E-2 (Drainage and Sewerage, origin PS516565X, benefiting lots on plan and South East Water Ltd), and E-1 Drainage and Sewerage (origin PS509027T, benefiting lots on PS509027T). No structures may be built over or within 1 metre of easements without South East Water written consent. SEW asset maps (Case 51647924, 11 March 2026) show 225mm uPVC sewer infrastructure in adjacent streets (Moondarra Drive), installed 2002–2003.",
        category: "legal",
        keywords: ["easement", "sewer", "drainage", "south east water", "encumbrance", "E-1", "E-2", "PS516565X"],
      },
      {
        question: "What are the covenants?",
        answer: "Covenant AD606000B (registered 10/05/2005, Transfer of Land Act 1958) imposes the following restrictions on Lot 90: single private dwelling only; minimum floor area 150 sqm (excluding verandah/carport/garage); external walls ≥75% brick/brick veneer/stone/masonry/masonry veneer; roof must be masonry/terracotta tiles or coloured non-reflective; no external plumbing visible from street; fences limited to 2m height on side/rear, front fence ≤1.5m and must be ≥50% transparent if height exceeds 1.2m; no vehicle ≥1 tonne, boat, caravan or trailer visible from street; no external clothes dryer or air conditioner visible from street; minimum 5m front setback. Lot 90 is NOT subject to the Building Envelope Restriction in PS516565X (that restriction applies ONLY to Lots 76–81).",
        category: "legal",
        keywords: ["covenant", "restriction", "AD606000B", "building envelope", "dwelling", "setback", "150 sqm", "design"],
      },
      {
        question: "What is the Section 173 Agreement on title?",
        answer: "Agreement AC424222D (registered 23/10/2003) is a Community Infrastructure Levy (CIL) Agreement under Section 173 of the Planning and Environment Act 1987, between Casey City Council, Lyngreye Pty Ltd, and Newland Developments Pty Ltd. The CIL was $325 per lot (CPI-adjusted quarterly from 1 April 1998) payable to Casey City Council before any building permit was issued for the lot. Since the existing dwelling on Lot 90 was built after 2004, the CIL obligation has been discharged. The Agreement remains as a historic encumbrance on title but its financial obligations are effectively spent for this property. It runs with the land and binds successive owners.",
        category: "legal",
        keywords: ["section 173", "s173", "agreement", "CIL", "community infrastructure levy", "casey", "AC424222D", "planning"],
      },
      {
        question: "Is there a mortgage on the property?",
        answer: "Yes — Mortgage AT982163D registered 25/01/2021 in favour of Bendigo and Adelaide Bank Ltd. The Electronic Certificate of Title (eCT) is under Adelaide Bank control (instrument 19018X, effective 03/03/2021). This mortgage was discharged at settlement. It was the only registered financial encumbrance on the title.",
        category: "legal",
        keywords: ["mortgage", "Bendigo", "Adelaide Bank", "encumbrance", "discharge", "settlement", "AT982163D", "bank"],
      },
      {
        question: "What services are connected?",
        answer: "All services are connected — electricity, gas, water (South East Water), sewerage (South East Water), and telephone. Confirmed in Section 32 Item 8 (no services marked as unconnected). Water usage charge: $0.58 per day (SEW Information Statement Case 51647924, 11/03/2026). Last meter read: 05/02/2026. NBN availability to be confirmed with NBN Co — FTTC or FTTP typically available in Berwick estates of this vintage (post-2004).",
        category: "physical",
        keywords: ["services", "electricity", "gas", "water", "sewer", "sewerage", "telephone", "nbn", "connected", "utilities"],
      },
      {
        question: "What are the council rates?",
        answer: "City of Casey council rates for financial year ending 30 June 2026: General Rates $1,557.14, Garbage Charge $468.00, ESVF Levy $258.83 — total $2,283.97. No scheme charges ($0.00). Land Information Certificate wCerR/C077688 (Certificate No. 89621, issued 11 March 2026, signed by Jo Kaylock, Head of Revenue and Rating). Balance outstanding at time of search: $571.00 (two quarterly instalments already paid). Full rates due by 16/02/2026. Purchaser assumes responsibility from settlement date.",
        category: "financial",
        keywords: ["council", "rates", "annual", "casey", "garbage", "levy", "ESVF", "fees", "per year", "outgoings", "2284"],
      },
      {
        question: "What are the water rates?",
        answer: "South East Water quarterly service charges (Q1 2026, 01/01/2026–31/03/2026): Parks Victoria Parks Service Charge $22.45, Melbourne Water Corporation Total Service Charges $31.25, Water Service Charge $21.97, Sewerage Service Charge $100.41 — subtotal $176.08 per quarter. Estimated annual service fees approximately $704 (excluding usage charges). Water usage charge: $0.58 per day. No arrears (total unpaid balance $0.00 at time of statement). SEW Information Statement Case No. 51647924, Reference 54J//15730/00028, dated 11 March 2026. Authorised by Lara Salembier, General Manager Customer Experience.",
        category: "financial",
        keywords: ["water", "rates", "south east water", "sewerage", "quarterly", "annual", "fees", "charges", "outgoings", "SEW", "176"],
      },
      {
        question: "What is the property valuation?",
        answer: "City of Casey valuation (Valuation Date 01/07/2025, Effective Date 01/07/2025): Site Value (SV) $545,000, Capital Improved Value (CIV) $710,000, Net Annual Value (NAV) $35,500. These are statutory government valuations for rate and land tax assessment — not a market valuation. Confirmed in Casey Land Information Certificate wCerR/C077688 and SRO Property Clearance Certificate No. 98153904 (both 11 March 2026). Property sold 25/05/2026 for $805,000 — a $95,000 premium above CIV.",
        category: "financial",
        keywords: ["valuation", "CIV", "site value", "capital improved", "NAV", "assessed", "land value", "government", "710000", "545000"],
      },
      {
        question: "What is the land tax situation?",
        answer: "Vendor Alan Waller Melville has 2026 land tax $0.00 — exempt as LTX Principal Place of Residence (SRO Property Clearance Certificate No. 98153904, 11/03/2026, Taxable SV $545,000). If not PPR-exempt, theoretical land tax: $1,350 + ($545,000 - $300,000) × 0.300 cents = $2,085.00/year. CIPT (Commercial and Industrial Property Tax): $0.00 (AVPCC 110 — not a qualifying use). Windfall Gains Tax: $0.00 (no liability identified, Certificate 98153904). Purchaser's own land tax liability assessed from settlement date under Land Tax Act 2005 (Vic) — owner-occupiers may claim PPR exemption.",
        category: "financial",
        keywords: ["land tax", "SRO", "state revenue", "clearance", "certificate", "CIPT", "windfall", "PPR", "exempt", "98153904"],
      },
      {
        question: "Is the property in a flood zone?",
        answer: "No. South East Water Information Statement (Case 51647924, 11 March 2026) states: 'Information available at Melbourne Water indicates that this property is not subject to flooding from Melbourne Water's drainage system, based on a flood level that has a probability of occurrence of 1% in any one year.' No flood overlay is listed on the Planning Certificate No. 1233888 (GRZ1 zone, no overlays).",
        category: "planning",
        keywords: ["flood", "flooding", "flood zone", "inundation", "waterway", "risk", "melbourne water", "drainage"],
      },
      {
        question: "Is the property in a bushfire prone area?",
        answer: "No. Property is at 40 Jack William Way, Berwick, City of Casey — not in a designated Bushfire Prone Area. GRZ1 zoning under Casey Planning Scheme. No Bushfire Management Overlay. Fire authority: Country Fire Authority (CFA). No bushfire attack level (BAL) assessment required for the existing dwelling.",
        category: "planning",
        keywords: ["bushfire", "fire", "BAL", "hazard", "prone", "CFA", "fire authority", "construction", "BPA"],
      },
      {
        question: "Is there an owners corporation?",
        answer: "No — Section 32 confirms Owners Corporation: Not Applicable. No body corporate fees apply. The PS516565X estate does not have a registered owners corporation affecting Lot 90.",
        category: "legal",
        keywords: ["owners corporation", "body corporate", "OC", "strata", "fees", "body corp", "not applicable"],
      },
      {
        question: "Is there subdivision potential?",
        answer: "Unlikely. The lot is 468 sqm under GRZ1 zoning. While GRZ1 permits some subdivision, the restrictive covenant AD606000B expressly limits Lot 90 to a single private dwelling house. Any subdivision or dual-occupancy proposal would conflict with this binding covenant. At 468 sqm, the lot is also relatively compact compared to typical subdivision thresholds.",
        category: "planning",
        keywords: ["subdivision", "subdivide", "second dwelling", "split", "potential", "develop", "grz1", "dual occupancy"],
      },
      {
        question: "Are there any planning overlays?",
        answer: "No planning overlays apply. Planning Certificate No. 1233888 (11 March 2026, Section 199 Planning and Environment Act 1987) issued by Minister for Planning Sonya Kilkenny confirms: 'The land is included in a GENERAL RESIDENTIAL ZONE — SCHEDULE 1.' No Heritage Overlay, Environmental Overlay, Flood Overlay, Vegetation Overlay, Bushfire Management Overlay, or any other overlay is listed. Casey Planning Scheme applies.",
        category: "planning",
        keywords: ["overlay", "planning overlay", "heritage", "environmental", "flood", "vegetation", "vpo", "eso", "none", "no overlays"],
      },
      {
        question: "Are there any building permits to disclose?",
        answer: "NIL. Casey City Council Building Surveying Services confirms no building permits have been issued in the last 10 years (Certificate CerB/W036705, Search Date 13 March 2026, Property: Lot 90 PS 516565X). The property is not subject to any notices or orders under the Building Act 1993. SC12 (Swimming Pool/Spa special condition) is included in the contract — if a pool or spa is present, its original building permit predates the 10-year search window. Confirm at inspection.",
        category: "legal",
        keywords: ["building permit", "permits", "building works", "renovations", "construction", "10 years", "pool", "CerB/W036705"],
      },
      {
        question: "Are there any VicRoads road acquisition proposals?",
        answer: "No. VicRoads Roads Property Certificate (11 March 2026, Certificate No. 79908375, Client Reference 733804): 'NO PROPOSALS — VicRoads has no approved proposals requiring any part of the property described in your application as at the 11th March 2026.' No part of 40 Jack William Way is proposed for road widening, resumption, or acquisition.",
        category: "planning",
        keywords: ["VicRoads", "road acquisition", "road widening", "resumption", "proposals", "compulsory acquisition", "79908375"],
      },
      {
        question: "When was this estate and lot created?",
        answer: "Plan of Subdivision PS516565X was registered 13/04/2004 — creating Lot 90 (468 sqm, 40 Jack William Way) along with all other lots in the estate. The parent certificate was Volume 10776 Folio 201 (LP86153 — Lot 2, being 348-356 Clyde Road, Berwick, Crown Portion 35, Parish of Berwick, County of Mornington). Planning Permit P 430/01 (originally issued 9 April 2002, amended 29 August 2002) was the subdivision permit — issued by City of Casey (Responsible Authority). Applicant was Lyngreye Pty Ltd (C/- Bortoli Wellington Pty Ltd, 2 Railway Parade, Murrumbeena 3163). Land was subject to Section 173 Community Infrastructure Levy Agreement (AC424222D) registered 23/10/2003.",
        category: "legal",
        keywords: ["subdivision", "lot created", "parent title", "original block", "PS516565X", "crown portion", "2004", "Lyngreye"],
      },
      {
        question: "What council manages this property?",
        answer: "City of Casey. Property Number: 89621 (Casey Land Information Certificate wCerR/C077688). Contact: 03 9705 5200, caseycc@casey.vic.gov.au, www.casey.vic.gov.au. Customer service centres: Narre Warren (Bunjil Place, Patrick Northeast Drive) and Cranbourne (Cranbourne Park Shopping Centre). PO Box 1000, Narre Warren VIC 3805. ABN: 43 320 295 742. GRZ1 (General Residential Zone Schedule 1) under Casey Planning Scheme.",
        category: "location",
        keywords: ["council", "casey", "local government", "LGA", "council area", "rates", "89621", "narre warren"],
      },
      {
        question: "Is the property sold with vacant possession or subject to lease?",
        answer: "Vacant possession — Section 32 confirms no lease or tenancy in place (Lease checkbox unchecked at Item 11 of the Vendor's Statement). Property sold with vacant possession at settlement. No current tenant. Vendor Alan Waller Melville is the owner-occupier (land tax exempt as PPR).",
        category: "legal",
        keywords: ["vacant possession", "tenancy", "lease", "tenant", "landlord", "owner occupier", "no lease"],
      },
      {
        question: "Is the Section 32 complete?",
        answer: "Yes — all statutory certificates obtained: title search 11/03/2026 (Security No. 124132871474N), Land Information Certificate wCerR/C077688 (11/03/2026), South East Water Information Statement Case 51647924 (11/03/2026), SRO Property Clearance Certificate No. 98153904 (11/03/2026), Planning Certificate No. 1233888 (11/03/2026), VicRoads Roads Property Certificate 79908375 (11/03/2026), Casey Building Surveying Certificate CerB/W036705 (13/03/2026). Property sold 25 May 2026 for $805,000.",
        category: "legal",
        keywords: ["s32", "section 32", "vendor statement", "signed", "ready", "status", "contract", "complete", "sold"],
      },
      {
        question: "What comparable sales are there?",
        answer: "40 Jack William Way sold 25 May 2026 for $805,000 (3 bed, 2 bath, 2 car, 468 sqm — compact Berwick estate lot). Same PS516565X estate: 13 Jack William Way (Lot 106, 630 sqm) on market 2026. In the broader Berwick area: 15 Hartsmere Drive sold 02 May 2026 for $845,000 (3 bed, 2 bath, 2 car, 718 sqm — larger Kingsmere Estate block). 32 Hartsmere Drive sold Feb 2026 for approximately $820,000 (4 bed). The $805,000 result for 40 JWW reflects the smaller 468 sqm lot relative to the 630–718 sqm lots achieving $820,000–$845,000. Berwick 3-bed median approximately $820,000–$870,000 (2026).",
        category: "financial",
        keywords: ["comparable", "sales", "recent", "sold", "comps", "market", "evidence", "805000", "Berwick", "3 bed"],
      },
      {
        question: "What are the covenant design restrictions in detail?",
        answer: "Covenant AD606000B (registered 10/05/2005) — full restrictions: (a) Dwelling: single private dwelling; min 150 sqm floor area (excl verandah/carport/garage); ≥75% external walls (excl windows) in brick/brick veneer/stone/masonry/masonry veneer; outbuildings limited to brick, stone, rendered concrete, concrete sheet, timber or coloured non-reflective material; no roof other than masonry/terracotta tiles or coloured non-reflective material; no visible external plumbing from street (except stormwater downpipes); (b) Fences: side/rear max 2m; timber palings must have timber cap, posts exposed both sides; front fence max 1.5m and must be ≥50% transparent if height exceeds 1.2m; no fence between front boundary and minimum setback that spans full side boundary; (c) No vehicle ≥1 tonne, boat, caravan or trailer stored visibly from street; (d) No external clothes dryer or air conditioner visible from street; (e) All buildings set back minimum 5m from front boundary. Signed by DEMAR DEVELOPMENTS PTY LTD (Common Seal — Mark Russell, Sole Director & Company Secretary, 55 New Road Oak Park). Covenant registered 10/05/2005.",
        category: "legal",
        keywords: ["covenant", "restriction", "AD606000B", "fence", "setback", "design", "150 sqm", "minimum floor", "brick", "dwelling"],
      },
      {
        question: "Is there owner-builder work to disclose?",
        answer: "No — Section 32 confirms no owner-builder work requiring disclosure under the Building Act 1993. Casey Building Surveying Certificate CerB/W036705 (13 March 2026) confirms no building permits in the last 10 years and no notices or orders under the Building Act 1993.",
        category: "legal",
        keywords: ["owner builder", "owner-builder", "DIY", "self-built", "builder warranty", "building act"],
      },
      {
        question: "Is there a pool or spa on the property?",
        answer: "Unconfirmed — SC12 (Swimming Pool/Spa Special Condition) is included as a special condition in the Contract of Sale, which typically indicates a pool or spa may be present on the property. However, Casey Building Surveying Certificate CerB/W036705 (13 March 2026) shows NIL building permits in the last 10 years — if a pool or spa exists, its permit predates the 10-year search window (i.e., was built before March 2016). Confirm at inspection whether a pool or spa is present and verify it meets current registration and barrier compliance requirements under the Building Regulations 2018.",
        category: "physical",
        keywords: ["pool", "spa", "swimming pool", "SC12", "special condition", "pool registration", "barrier compliance"],
      },
    ],
  },
}

// ---------------------------------------------------------------------------
// Utility: count filled fields (100 data-point fields, excluding qa)
// ---------------------------------------------------------------------------

const DATA_FIELD_KEYS: Array<keyof Omit<PropertySLM, "propertyId" | "address" | "suburb" | "status" | "soldDate" | "soldPrice" | "qa">> = [
  // PHYSICAL (20)
  "beds", "baths", "cars", "landSqm", "houseSqm", "yearBuilt", "propertyType",
  "frontageMetre", "depthMetre", "propertyShape", "orientation", "pool",
  "gardenSqm", "shed", "outdoorEntertaining", "alfrescoSqm", "roofType",
  "externalCladding", "construction", "floorplanConfig",
  // LEGAL (15)
  "titleType", "easements", "covenants", "overlays", "s32Status", "encumbrances",
  "ownerOccupied", "zoning", "rightOfWay", "sewerEasement", "contaminatedLand",
  "buildingPermitsOutstanding", "ownerBuilderWork", "titlesOfficeReady", "section32CompletionDate",
  // FINANCIAL (15)
  "priceMin", "priceMax", "vendorReserve", "settlementTermsDays", "depositPct",
  "rentalAppraisalLow", "rentalAppraisalHigh", "grossYieldAtAsk", "councilRates",
  "waterRates", "bodyCorporateFees", "stampDutyEstimate", "landTaxThreshold",
  "depreciationYear1Est", "capitalGainsHistory",
  // LOCATION (15)
  "primarySchool", "primarySchoolRating", "secondarySchool", "secondarySchoolRating",
  "schoolZoneCatchment", "distanceToTrainKm", "trainLine", "distanceToFreewayKm",
  "distanceToShoppingKm", "nearestHospitalKm", "suburb5yrGrowthPct", "suburbMedianPrice",
  "daysOnMarketAvg", "clearanceRatePct", "comparableSales",
  // FEATURES (15)
  "kitchenRenovated", "bathroomRenovated", "flooringType", "airConType", "heatingType",
  "solarKw", "batteryStorage", "evCharging", "nbnType", "waterTank", "alarmSystem",
  "smartHome", "disabilityAccess", "petsAllowed", "outdoorFeatures",
  // PLANNING & VENDOR (20)
  "subdivisionPotential", "dualOccupancyPotential", "grannyFlatApproved", "extensionPotential",
  "councilDevelopmentHistory", "neighbourhoodDescription", "trafficNoiseLevel", "flightPathFlag",
  "futureInfrastructure", "floodZone", "vendorMotivation", "vendorTimelineDays",
  "previousOffers", "daysOnMarket", "priceReductionHistory", "tenantInPlace",
  "tenantLeaseEndDate", "vendorPreferredSettlement", "vendorFlexOnInclusions", "inclusions",
]

export function getSLMCompleteness(slm: PropertySLM): { filled: number; total: number; pct: number } {
  const total = DATA_FIELD_KEYS.length
  let filled = 0
  for (const key of DATA_FIELD_KEYS) {
    const val = slm[key as keyof PropertySLM]
    if (val !== "TBD") filled++
  }
  return { filled, total, pct: Math.round((filled / total) * 100) }
}

// ---------------------------------------------------------------------------
// localStorage persistence + Sheet-backed runtime cache
// ---------------------------------------------------------------------------

const SLM_KEY_PREFIX = "propOS_slm_v2_"

// Runtime cache populated by preloadSLMsFromSheet() — Sheet data takes priority
const sheetSLMCache: Record<number, PropertySLM> = {}
let sheetPreloadDone = false

/**
 * Map a raw Sheet row (flat key-value) into a PropertySLM.
 * Sheet Q&A columns: qa_1_question, qa_1_answer, ... qa_25_question, qa_25_answer
 */
function mapSheetRowToSLM(raw: Record<string, unknown>, propertyId: number): PropertySLM {
  const fallback = SLM_DATA[propertyId]
  if (!fallback) return raw as unknown as PropertySLM // unknown property, pass through

  // Start from hardcoded as base, overlay any non-empty Sheet values
  const merged: any = { ...fallback }
  for (const [k, v] of Object.entries(raw)) {
    if (k.startsWith("qa_")) continue // handle Q&A separately
    if (v === null || v === undefined || v === "") continue
    if (k in merged) {
      // Coerce types to match PropertySLM
      const existing = merged[k]
      if (typeof existing === "number" && typeof v === "string") {
        const n = Number(v)
        if (!isNaN(n)) { merged[k] = n; continue }
      }
      if (typeof existing === "boolean" && typeof v === "string") {
        merged[k] = v === "true" || v === "TRUE" || v === "1"
        continue
      }
      merged[k] = v
    }
  }

  // Build Q&A array from qa_N_question / qa_N_answer columns
  const qaFromSheet: PropertyQA[] = []
  for (let i = 1; i <= 25; i++) {
    const q = String(raw[`qa_${i}_question`] ?? "").trim()
    const a = String(raw[`qa_${i}_answer`] ?? "").trim()
    if (q && a) {
      // Try to find matching category/keywords from hardcoded Q&A
      const match = fallback.qa.find(qa => qa.question.toLowerCase() === q.toLowerCase())
      qaFromSheet.push({
        question: q,
        answer: a,
        category: match?.category ?? "physical",
        keywords: match?.keywords ?? q.toLowerCase().split(/\s+/).filter(w => w.length > 2),
      })
    }
  }
  if (qaFromSheet.length > 0) {
    merged.qa = qaFromSheet
  }

  return merged as PropertySLM
}

/**
 * Preload SLMs from Google Sheets for all known property IDs.
 * Called once at app startup. Populates sheetSLMCache.
 * Priority: Sheet → localStorage → hardcoded.
 */
export async function preloadSLMsFromSheet(propertyIds: number[]): Promise<void> {
  const { readPropertySLMFromSheet, sheetsConnected } = await import("../lib/sheet")
  if (!sheetsConnected()) { sheetPreloadDone = true; return }

  await Promise.allSettled(
    propertyIds.map(async (id) => {
      const raw = await readPropertySLMFromSheet(id)
      if (raw) sheetSLMCache[id] = mapSheetRowToSLM(raw, id)
    })
  )
  sheetPreloadDone = true
  console.log(`[SLM] Preloaded ${Object.keys(sheetSLMCache).length}/${propertyIds.length} from Sheets`)
}

/** Check if Sheet SLM preload is complete */
export function isSLMPreloadDone(): boolean { return sheetPreloadDone }

/**
 * Load SLM for a property. Priority:
 *   1. Sheet runtime cache (populated by preloadSLMsFromSheet)
 *   2. localStorage (user edits from SettingsView)
 *   3. Hardcoded SLM_DATA (offline fallback)
 */
export function loadSLMForProperty(propertyId: number): PropertySLM {
  // 1. Sheet cache (dynamic, live data)
  if (sheetSLMCache[propertyId]) return sheetSLMCache[propertyId]

  // 2. localStorage (user-edited via Settings)
  try {
    const raw = localStorage.getItem(`${SLM_KEY_PREFIX}${propertyId}`)
    if (raw) {
      return JSON.parse(raw) as PropertySLM
    }
  } catch {
    // fall through to default
  }

  // 3. Hardcoded fallback
  return SLM_DATA[propertyId]
}

export function saveSLMForProperty(slm: PropertySLM): void {
  // Save to localStorage AND update the runtime cache
  try {
    localStorage.setItem(`${SLM_KEY_PREFIX}${slm.propertyId}`, JSON.stringify(slm))
  } catch {
    // storage may be unavailable in SSR or private browsing — silently ignore
  }
  // Also update Sheet cache so the save is reflected immediately
  sheetSLMCache[slm.propertyId] = slm
}

export function resetSLMForProperty(propertyId: number): PropertySLM {
  try {
    localStorage.removeItem(`${SLM_KEY_PREFIX}${propertyId}`)
  } catch {
    // ignore
  }
  // Clear Sheet cache for this property so it falls back to hardcoded
  delete sheetSLMCache[propertyId]
  return SLM_DATA[propertyId]
}
