import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  C, FONT, PORTFOLIO_SOLD, PORTFOLIO_ACTIVE,
  DEFAULT_THEME, getPortfolioForAgent, isPasSunilchandra, isManpreetSingh,
  type AgentProfile, type AgencyTheme, type PortfolioProperty,
  type LeadStatus, LEAD_STATUS_LABELS, LEAD_STATUS_ORDER,
  type DemoMode,
} from "../data"
import { getPastBuyersForAgent, CURRENT_VALUE_ESTIMATES } from "../data/pastBuyers"
import { calculateFinancials, fmtDollar, fmtPct, type FinancialSnapshot } from "../lib/vendorFinancials"
import {
  batchSegment, PIPELINE_LABELS,
  type SegmentedBuyer, type Pipeline,
} from "../lib/vendorPipeline"
import { batchEstimateValues } from "../lib/comparableSales"
import {
  loadSLMForProperty, getSLMCompleteness, preloadSLMsFromSheet,
  type PropertySLM,
} from "../data/propertySlm"
import { matchLeadToListing, matchQuestionToSLM, type MatchResult } from "../lib/slmMatch"
import {
  readLeadsFromSheet, readAllLeadsFromSheet, postEvent, sheetsConnected,
  postLeadStatus, markAttended, writeAgentVoiceEntry,
  readPastBuyersFromSheet, updateLastContactDate,
  type SheetLead,
} from "../lib/sheet"
import AuctionOutcomePanel from "../components/AuctionOutcomePanel"
import BuyerPitchReport from "../components/BuyerPitchReport"
import { apiUrl } from "../lib/api"
import { buildVoiceContext, loadCorpus } from "../lib/voiceContext"
import { DEMO_FALLBACK_LEADS } from "../lib/demoFallback"
import { getCachedOutreach } from "../lib/cachedOutreach"
import { useVoiceMemo } from "../hooks/useVoiceMemo"
import {
  getLeadKnowledge, upsertLeadTranscript,
  getLeadCumulativeNotes, enrichLeadNotes,
} from "../lib/leadKnowledge"
import {
  generateComparables, buildAppraisalRange, buildEquityScenarios,
  fmtK,
  type CompSale, type AppraisalRange, type EquityScenario,
} from "../lib/appraisalEngine"

// ── Types ─────────────────────────────────────────────────────────────────────

interface ScoredLead extends SheetLead {
  matchResult: MatchResult
  fromPropertyId: number
  bedsWanted: number  // inferred from persona/notes
}

type Stage =
  | { kind: "portfolio" }
  | { kind: "soldLeads"; soldProperty: PortfolioProperty; leads: SheetLead[] }
  | { kind: "matching"; property: PortfolioProperty; soldLeads: Record<number, SheetLead[]> }
  | { kind: "leads"; property: PortfolioProperty; allLeads: ScoredLead[] }
  | { kind: "profile"; property: PortfolioProperty; lead: ScoredLead; soldSLM: PropertySLM; allLeads: ScoredLead[] }
  | { kind: "generating"; property: PortfolioProperty; lead: ScoredLead; soldSLM: PropertySLM; transcript: string; allLeads: ScoredLead[] }
  | { kind: "review"; property: PortfolioProperty; lead: ScoredLead; soldSLM: PropertySLM; transcript: string; sms: string; emailSubject: string; emailBody: string[]; allLeads: ScoredLead[] }
  | { kind: "missedOut"; auctionProperty: PortfolioProperty; leads: SheetLead[] }
  // ── Vendor prospecting stages ──────────────────────────────────────────
  | { kind: "vendorPortfolio" }
  | { kind: "vendorDashboard"; segmented: SegmentedBuyer[] }
  | { kind: "vendorProfile"; entry: SegmentedBuyer }
  | { kind: "vendorReview"; entry: SegmentedBuyer; sms: string; emailSubject: string; emailBody: string[] }

// ── Helpers ───────────────────────────────────────────────────────────────────

const fmt = (n: number) =>
  n >= 1_000_000 ? `$${(n / 1_000_000).toFixed(2)}M` : `$${(n / 1_000).toFixed(0)}K`

function scoreColor(score: number): string {
  if (score >= 80) return C.green
  if (score >= 60) return C.blue
  if (score >= 40) return "#f59e0b"
  return C.red ?? "#ef4444"
}

// Safely add alpha to any CSS colour (hex or rgb/rgba)
function withAlpha(color: string, alpha: number): string {
  if (color.startsWith("#") && color.length === 7) {
    const r = parseInt(color.slice(1, 3), 16)
    const g = parseInt(color.slice(3, 5), 16)
    const b = parseInt(color.slice(5, 7), 16)
    return `rgba(${r},${g},${b},${alpha})`
  }
  if (color.startsWith("rgb(")) {
    return color.replace("rgb(", "rgba(").replace(")", `,${alpha})`)
  }
  if (color.startsWith("rgba(")) {
    return color.replace(/,[\d.]+\)$/, `,${alpha})`)
  }
  return color
}

// ── ActiveCard ────────────────────────────────────────────────────────────────

function ActiveCard({ property, onClick, onBuyerBrief, theme }: {
  property: PortfolioProperty
  onClick: () => void
  onBuyerBrief?: (p: PortfolioProperty) => void
  theme: AgencyTheme
}) {
  const slm = loadSLMForProperty(property.id)
  const completeness = slm ? getSLMCompleteness(slm) : null

  return (
    <div
      onClick={onClick}
      style={{
        background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`,
        overflow: "hidden", cursor: "pointer",
        transition: "border 0.15s, box-shadow 0.15s, transform 0.15s",
      }}
      onMouseEnter={e => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = withAlpha(theme.primary, 0.5)
        el.style.boxShadow = `0 0 32px ${theme.glow}, 0 0 0 1px ${withAlpha(theme.primary, 0.08)}`
        el.style.transform = "translateY(-2px)"
      }}
      onMouseLeave={e => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = C.border
        el.style.boxShadow = "none"
        el.style.transform = "translateY(0)"
      }}
    >
      <div style={{ height: 160, overflow: "hidden", position: "relative" }}>
        <img
          src={property.image}
          alt={property.address}
          loading="lazy"
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
        {completeness && (
          <div style={{
            position: "absolute", bottom: 10, left: 10,
            padding: "3px 9px", borderRadius: 8,
            background: "rgba(0,0,0,0.72)", backdropFilter: "blur(4px)",
            fontSize: 10, fontWeight: 700, color: completeness.pct >= 70 ? C.green : "#f59e0b",
          }}>
            {completeness.pct}% SLM complete
          </div>
        )}
      </div>
      <div style={{ padding: "12px 14px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginBottom: 2, lineHeight: 1.3 }}>
          {property.address}
        </div>
        <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>
          {property.suburb} {property.state}
        </div>
        <div style={{ display: "flex", gap: 10, marginBottom: 8, flexWrap: "wrap" }}>
          {[
            `${property.beds} bd`,
            `${property.baths} bath`,
            `${property.cars} car`,
            property.land ? `${property.land}sqm` : null,
          ].filter(Boolean).map(s => (
            <span key={s} style={{ fontSize: 10, color: C.faint }}>{s}</span>
          ))}
        </div>
        <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.9)" }}>
          {property.priceMin && property.priceMax
            ? `${fmt(property.priceMin)} – ${fmt(property.priceMax)}`
            : fmt(property.price)}
        </div>
        {property.openDate && (
          <div style={{ marginTop: 6, fontSize: 10, color: C.muted }}>{property.openDate}</div>
        )}
        {property.auctionDate && (
          <div style={{ marginTop: 2, fontSize: 10, color: theme.gradient[0], fontWeight: 600 }}>Auction {property.auctionDate}</div>
        )}
        {onBuyerBrief && (
          <button
            onClick={e => { e.stopPropagation(); onBuyerBrief(property) }}
            style={{
              marginTop: 8, padding: "5px 12px", borderRadius: 6, fontSize: 10, fontWeight: 700,
              background: "#ffffff", border: `1px solid ${withAlpha(theme.primary, 0.28)}`,
              color: theme.gradient[0], cursor: "pointer", fontFamily: FONT,
            }}
          >
            Buyer Brief
          </button>
        )}
      </div>
    </div>
  )
}

// ── SoldCard ──────────────────────────────────────────────────────────────────

function SoldCard({ property, leads, loading, theme, onClick }: {
  property: PortfolioProperty
  leads: SheetLead[]
  loading: boolean
  theme: AgencyTheme
  onClick: () => void
}) {
  return (
    <div
      onClick={onClick}
      style={{
        borderRadius: 16, border: `1px solid ${withAlpha(theme.primary, 0.25)}`,
        overflow: "hidden", cursor: "pointer", position: "relative",
        height: 280,
        transition: "border 0.15s, box-shadow 0.15s, transform 0.15s",
      }}
      onMouseEnter={e => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = withAlpha(theme.primary, 0.7)
        el.style.boxShadow = `0 0 28px ${theme.glow}`
        el.style.transform = "translateY(-2px)"
      }}
      onMouseLeave={e => {
        const el = e.currentTarget as HTMLDivElement
        el.style.borderColor = withAlpha(theme.primary, 0.25)
        el.style.boxShadow = "none"
        el.style.transform = "translateY(0)"
      }}
    >
      {/* Layer 1 — full-bleed photo */}
      <img
        src={property.image}
        alt={property.address}
        loading="lazy"
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
      />

      {/* Layer 2 — agency colour gradient: transparent at top → solid at bottom */}
      <div style={{
        position: "absolute", inset: 0,
        background: `linear-gradient(180deg, ${withAlpha(theme.primary, 0)} 0%, ${withAlpha(theme.primary, 0)} 28%, ${withAlpha(theme.primary, 0.75)} 62%, ${withAlpha(theme.primary, 1)} 100%)`,
      }} />

      {/* Sold badge — top left */}
      <div style={{
        position: "absolute", top: 10, left: 10,
        padding: "3px 10px", borderRadius: 20,
        background: theme.primary,
        fontSize: 10, fontWeight: 800, color: "#fff", zIndex: 2,
      }}>
        Sold {fmt(property.price)}
      </div>

      {/* Sold date — top right */}
      {property.soldDate && (
        <div style={{
          position: "absolute", top: 10, right: 10,
          padding: "3px 10px", borderRadius: 20,
          background: "rgba(0,0,0,0.50)", backdropFilter: "blur(4px)",
          fontSize: 10, fontWeight: 600, color: "rgba(255,255,255,0.85)", zIndex: 2,
        }}>
          {property.soldDate}
        </div>
      )}


      {/* Layer 3 — text block */}
      <div style={{ position: "absolute", bottom: 16, left: 14, right: 14 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#fff", lineHeight: 1.25, marginBottom: 3 }}>
          {property.address}
        </div>
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.75)", marginBottom: 7 }}>
          {property.suburb} {property.state}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: 10 }}>
            {[`${property.beds} bd`, `${property.baths} ba`, `${property.cars} car`,
              property.land ? `${property.land} m²` : null].filter(Boolean).map(s => (
              <span key={s} style={{ fontSize: 10, color: "rgba(255,255,255,0.70)" }}>{s}</span>
            ))}
          </div>
          {loading ? (
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.5)", letterSpacing: 2 }}>
              <span style={{ animation: "blink 1s ease-in-out infinite" }}>.</span>
              <span style={{ animation: "blink 1s ease-in-out 0.33s infinite" }}>.</span>
              <span style={{ animation: "blink 1s ease-in-out 0.66s infinite" }}>.</span>
            </span>
          ) : (
            <div style={{ display: "flex", alignItems: "baseline", gap: 3 }}>
              <span style={{ fontSize: 16, fontWeight: 800, color: "#fff", lineHeight: 1 }}>
                {leads.length}
              </span>
              <span style={{ fontSize: 10, color: "rgba(255,255,255,0.70)" }}>
                {leads.length === 1 ? "attendee" : "attendees"}
              </span>
            </div>
          )}
        </div>
      </div>

    </div>
  )
}

// ── Stage 0b — Sold Property Attendees ───────────────────────────────────────

function SoldLeadsPage({ soldProperty, leads, onBack, onSelectLead, theme }: {
  soldProperty: PortfolioProperty
  leads: SheetLead[]
  onBack: () => void
  onSelectLead?: (lead: ScoredLead, property: PortfolioProperty) => void
  theme: AgencyTheme
}) {
  const slm = loadSLMForProperty(soldProperty.id)
  const activeSLMs = PORTFOLIO_ACTIVE.map(p => ({
    property: p,
    slm: loadSLMForProperty(p.id),
  }))
  const [attended, setAttended] = useState<Set<string>>(new Set())

  // For each lead, find the best-matching active listing
  const leadsWithRecs = leads.map(lead => {
    const bedsWanted = inferBedsWanted(lead)
    const enrichedNotes = enrichLeadNotes(lead.id, lead.notes)
    const bestMatch = activeSLMs
      .map(a => ({
        property: a.property,
        result: matchLeadToListing(
          { budget: lead.budget, bedsWanted, persona: lead.persona, suburbs: inferSuburbs(lead), notes: enrichedNotes, questions: lead.questions },
          a.slm,
          slm,
        ),
      }))
      .sort((a, b) => b.result.score - a.result.score)[0]
    return { lead, bestMatch }
  })

  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: "110px 28px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{
        background: "transparent", border: "none", cursor: "pointer",
        color: theme.primary, fontSize: 18, fontFamily: FONT,
        display: "flex", alignItems: "center", marginBottom: 20, padding: 0, lineHeight: 1,
      }}>←</button>

      {/* Header — property info */}
      <div style={{ display: "flex", gap: 20, marginBottom: 12, alignItems: "flex-start" }}>
        <div style={{ width: 80, height: 60, borderRadius: 10, overflow: "hidden", flexShrink: 0 }}>
          <img src={soldProperty.image} alt={soldProperty.address} loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
        <div>
          <div style={{ fontSize: 22, fontWeight: 700, color: C.text, letterSpacing: -0.6, marginBottom: 2 }}>
            {soldProperty.address}, {soldProperty.suburb}
          </div>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <span style={{ fontSize: 12, color: C.green, fontWeight: 700 }}>
              Sold {fmt(soldProperty.price)}
            </span>
            {soldProperty.soldDate && (
              <span style={{ fontSize: 12, color: C.muted }}>{soldProperty.soldDate}</span>
            )}
          </div>
        </div>
      </div>

      {/* Open Home Attendees title — between property info and lead list */}
      <div style={{
        fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted,
        textTransform: "uppercase", marginBottom: 16,
        paddingTop: 16, borderTop: `1px solid ${C.border}`,
      }}>
        Open Home Attendees · {leads.length} {leads.length === 1 ? "attendee" : "attendees"}
      </div>

      {leads.length === 0 ? (
        <div style={{
          padding: "32px", textAlign: "center", background: C.bg2,
          borderRadius: 16, border: `1px solid ${C.border}`,
        }}>
          <div style={{ fontSize: 14, color: C.muted, marginBottom: 8 }}>No leads found in Google Sheets</div>
          <div style={{ fontSize: 12, color: C.faint }}>
            Make sure the Leads tab has <code style={{ color: C.muted }}>inspectedProperty</code> matching this address exactly
          </div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {leadsWithRecs.map(({ lead, bestMatch }, i) => {
            const score = bestMatch?.result.score ?? 0
            const color = scoreColor(score)
            return (
              <motion.div
                key={lead.id || lead.name + i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                onClick={() => {
                  if (!onSelectLead) return
                  const scoredLead: ScoredLead = {
                    ...lead,
                    matchResult: bestMatch?.result ?? { score: 0, reasons: [] },
                    fromPropertyId: soldProperty.id,
                    bedsWanted: inferBedsWanted(lead),
                  }
                  onSelectLead(scoredLead, bestMatch?.property ?? PORTFOLIO_ACTIVE[0])
                }}
                style={{
                  background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`,
                  padding: "16px 18px",
                  cursor: onSelectLead ? "pointer" : "default",
                  transition: "border 0.15s, box-shadow 0.15s",
                }}
                onMouseEnter={onSelectLead ? (e => {
                  const el = e.currentTarget as HTMLDivElement
                  el.style.borderColor = theme.primary + "55"
                  el.style.boxShadow = `0 0 20px ${theme.glow}`
                }) : undefined}
                onMouseLeave={onSelectLead ? (e => {
                  const el = e.currentTarget as HTMLDivElement
                  el.style.borderColor = C.border
                  el.style.boxShadow = "none"
                }) : undefined}
              >
                <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
                  {/* Main info — no initials avatar */}
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4 }}>
                      <span style={{ fontSize: 15, fontWeight: 700, color: C.text }}>{lead.name}</span>
                      <span style={{
                        fontSize: 10, fontWeight: 700, padding: "2px 7px", borderRadius: 20,
                        background: theme.dim, border: `1px solid ${theme.primary}33`, color: theme.primary,
                      }}>{lead.persona || "Buyer"}</span>
                      {/* Attendance toggle — Feature 6 */}
                      <button
                        onClick={async e => {
                          e.stopPropagation()
                          const id = lead.id || lead.name
                          const next = new Set(attended)
                          if (attended.has(id)) {
                            next.delete(id)
                          } else {
                            next.add(id)
                            await markAttended({ leadId: id, leadName: lead.name, propertyAddress: soldProperty.address + ", " + soldProperty.suburb })
                          }
                          setAttended(next)
                        }}
                        style={{
                          padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 700, cursor: "pointer",
                          background: attended.has(lead.id || lead.name) ? "rgba(100,208,144,0.15)" : C.bg3,
                          border: `1px solid ${attended.has(lead.id || lead.name) ? C.green : C.border}`,
                          color: attended.has(lead.id || lead.name) ? C.green : C.muted,
                          transition: "all 0.15s",
                        }}
                      >
                        {attended.has(lead.id || lead.name) ? "Attended ✓" : "Mark attended"}
                      </button>
                    </div>
                    <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 6 }}>
                      {lead.phone && (
                        <a href={`tel:${lead.phone}`} style={{ fontSize: 12, color: theme.primary, textDecoration: "none" }}>{lead.phone}</a>
                      )}
                      {lead.email && (
                        <a href={`mailto:${lead.email}`} style={{ fontSize: 12, color: theme.primary, textDecoration: "none" }}>{lead.email}</a>
                      )}
                      <span style={{ fontSize: 12, color: C.muted }}>{fmt(lead.budget)} budget</span>
                    </div>
                    {lead.questions.length > 0 && (
                      <div style={{ fontSize: 11, color: C.faint, lineHeight: 1.4 }}>
                        Asked: {lead.questions.slice(0, 3).join(" · ")}
                      </div>
                    )}
                    {lead.notes && (
                      <div style={{ fontSize: 11, color: C.faint, marginTop: 4, lineHeight: 1.4 }}>
                        <span style={{ color: C.muted, fontWeight: 600 }}>Notes: </span>
                        {lead.notes.slice(0, 120)}{lead.notes.length > 120 ? "…" : ""}
                      </div>
                    )}
                  </div>

                  {/* Best match recommendation — score arc + compact ticks */}
                  {bestMatch && (() => {
                    const r = 20
                    const circ = 2 * Math.PI * r
                    const pct = Math.min(score, 99) / 100
                    const dash = circ * pct
                    const gap = circ - dash
                    const reasons = bestMatch.result.reasons.filter(r => r.type === "strength").slice(0, 2)
                    return (
                      <div style={{
                        flexShrink: 0, textAlign: "right", display: "flex", flexDirection: "column",
                        alignItems: "flex-end", gap: 6,
                      }}>
                        {/* Arc score circle */}
                        <div style={{ position: "relative", width: 48, height: 48 }}>
                          <svg width={48} height={48} style={{ transform: "rotate(-90deg)" }}>
                            <circle cx={24} cy={24} r={r} fill="none" stroke={color + "44"} strokeWidth={3} />
                            <circle
                              cx={24} cy={24} r={r} fill="none"
                              stroke={color} strokeWidth={3}
                              strokeDasharray={`${dash} ${gap}`}
                              strokeLinecap="round"
                            />
                          </svg>
                          <div style={{
                            position: "absolute", inset: 0,
                            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                          }}>
                            <span style={{ fontSize: 13, fontWeight: 800, color, lineHeight: 1 }}>{score}</span>
                          </div>
                        </div>
                        {/* Recommended listing */}
                        <div style={{
                          padding: "3px 8px", borderRadius: 8,
                          background: theme.dim, border: `1px solid ${theme.primary}22`,
                          fontSize: 10, color: theme.primary, fontWeight: 600,
                          maxWidth: 140, textAlign: "right", lineHeight: 1.3,
                        }}>
                          → {bestMatch.property.address}
                        </div>
                        {/* Compact tick reasons */}
                        {reasons.length > 0 && (
                          <div style={{ display: "flex", flexDirection: "column", gap: 2, alignItems: "flex-end" }}>
                            {reasons.map((r, ri) => {
                              // Extract short label — take first 2 words before "closely" or "match"
                              const short = r.text.split(" ").slice(0, 2).join(" ")
                              return (
                                <div key={ri} style={{ fontSize: 9, color: C.muted, display: "flex", alignItems: "center", gap: 3 }}>
                                  <span style={{ color: C.green }}>✓</span>
                                  <span>{short}</span>
                                </div>
                              )
                            })}
                          </div>
                        )}
                      </div>
                    )
                  })()}
                </div>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* Sheets data source — plain, unobtrusive */}
      <div style={{ marginTop: 28 }}>
        <div style={{ fontSize: 10, color: C.faint, lineHeight: 1.6 }}>
          Leads sourced from Google Sheets · inspectedProperty = {soldProperty.address}, {soldProperty.suburb} · Match scores calculated by SLM engine against active listings
        </div>
      </div>
    </div>
  )
}

// ── Address fuzzy match — normalise and check substring ──────────────────────

function normaliseAddr(s: string): string {
  return s.toLowerCase()
    .replace(/,/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\b(vic|nsw|qld|wa|sa|tas|act|nt)\b/g, "")
    .replace(/\b\d{4}\b/g, "")           // strip postcode
    .replace(/(street|st|road|rd|avenue|ave|drive|dr|court|ct|place|pl|way|wy|close|cl|grove|gr|terrace|tce|crescent|cres)\b/g, s => s[0]) // normalise type
    .replace(/\s+/g, " ").trim()
}

// Shorten address for SMS — "3 Thirlmere Court" → "Thirlmere Ct", "17 Grand Arch Way" → "Grand Arch Way"
function shortAddr(address: string): string {
  const typeAbbr: Record<string, string> = {
    street: "St", road: "Rd", avenue: "Ave", drive: "Dr",
    court: "Ct", place: "Pl", close: "Cl", grove: "Gr",
    terrace: "Tce", crescent: "Cres", lane: "Ln", boulevard: "Blvd",
    circuit: "Cct", parade: "Pde",
  }
  const withoutNum = address.replace(/^\d[\d/\-]*\s+/, "")
  const words = withoutNum.split(" ")
  const last = words[words.length - 1]?.toLowerCase()
  if (last && typeAbbr[last]) words[words.length - 1] = typeAbbr[last]
  return words.join(" ")
}

function leadBelongsToProperty(lead: SheetLead, property: PortfolioProperty): boolean {
  const haystack = normaliseAddr(lead.inspectedProperty)
  // Check if the street number + first word of street name appear together
  const needle = normaliseAddr(property.address)
  return haystack.includes(needle) || needle.includes(haystack.split(" ").slice(0, 3).join(" "))
}

/**
 * Group a flat list of leads by sold property.
 * Uses fuzzy address matching so minor formatting differences don't break the join.
 */
function groupLeadsByProperty(allLeads: SheetLead[], soldProperties: PortfolioProperty[] = PORTFOLIO_SOLD): Record<number, SheetLead[]> {
  const map: Record<number, SheetLead[]> = {}
  for (const sold of soldProperties) {
    map[sold.id] = allLeads.filter(lead => leadBelongsToProperty(lead, sold))
  }
  return map
}

/**
 * For Pas Sunilchandra: pull Cameron's "3 Thirlmere Court" leads (property 102)
 * and alias them under Pas's "58 Broadway Street" (property 301).
 * This lets the demo flow run without Pas needing his own Sheet leads.
 * Has zero effect when any other agent is logged in.
 */
function addPasLeadAliases(
  grouped: Record<number, SheetLead[]>,
  allLeads: SheetLead[],
  agent: AgentProfile
): Record<number, SheetLead[]> {
  // Pas Sunilchandra — alias Cameron's Thirlmere leads to Broadway St (301)
  if (isPasSunilchandra(agent)) {
    const camGrouped = groupLeadsByProperty(allLeads, PORTFOLIO_SOLD)
    const thirlmere = camGrouped[102] ?? []
    if (!thirlmere.length) return grouped
    return { ...grouped, 301: [...(grouped[301] ?? []), ...thirlmere] }
  }
  // Manpreet Singh — alias Cameron's Thirlmere leads to 40 Jack William Way (501)
  if (isManpreetSingh(agent)) {
    const camGrouped = groupLeadsByProperty(allLeads, PORTFOLIO_SOLD)
    const thirlmere = camGrouped[102] ?? []
    if (!thirlmere.length) return grouped
    return { ...grouped, 501: [...(grouped[501] ?? []), ...thirlmere] }
  }
  return grouped
}

/** Strip out test / placeholder rows that come back from the Sheet during development. */
function isRealLead(lead: SheetLead): boolean {
  const name = lead.name.trim().toLowerCase()
  if (!name) return false
  // Obvious test/seed row names
  if (["test lead", "lead_status", "name", "test", "sample"].includes(name)) return false
  // Seed rows that look like column headers or events (no space in name = likely a field name)
  if (!name.includes(" ") && lead.budget === 0) return false
  return true
}

// ── Stage 0 — Portfolio ───────────────────────────────────────────────────────

function PortfolioPage({ onSelectActive, onSelectSold, onAuctionSaved, onSettings, agent, theme }: {
  onSelectActive: (p: PortfolioProperty, soldLeads: Record<number, SheetLead[]>) => void
  onSelectSold: (p: PortfolioProperty, leads: SheetLead[]) => void
  onAuctionSaved: (property: PortfolioProperty, leads: SheetLead[]) => void
  onSettings?: () => void
  agent: AgentProfile
  theme: AgencyTheme
}) {
  // Gate portfolio data to Cam Knoll / Peake — other agents see empty
  const { sold: agentSold, active: agentActive } = getPortfolioForAgent(agent)

  const [soldLeads, setSoldLeads] = useState<Record<number, SheetLead[]>>({})
  const [sheetsLoading, setSheetsLoading] = useState(true)
  const [auctionPanelProperty, setAuctionPanelProperty] = useState<PortfolioProperty | null>(null)
  const [pitchProperty, setPitchProperty] = useState<PortfolioProperty | null>(null)

  useEffect(() => {
    let mounted = true
    const CACHE_KEY = "propOS_leads_cache_v3"

    const applyLeads = (leads: SheetLead[], save = false) => {
      if (!mounted) return
      const grouped = addPasLeadAliases(groupLeadsByProperty(leads, agentSold), leads, agent)
      const total   = Object.values(grouped).reduce((a, l) => a + l.length, 0)

      if (total === 0 && agentSold.length > 0) {
        // No sheet leads at all for this agent — use full fallback
        // (covers cross-agent cache pollution and empty sheets)
        setSoldLeads(addPasLeadAliases(groupLeadsByProperty(DEMO_FALLBACK_LEADS, agentSold), DEMO_FALLBACK_LEADS, agent))
        setSheetsLoading(false)
        return
      }

      // Use GSheets data as-is — no fallback supplementation
      setSoldLeads(grouped)

      setSheetsLoading(false)
      if (save && total > 0) {
        try { localStorage.setItem(CACHE_KEY, JSON.stringify(leads)) } catch {}
      }
    }

    // Load from localStorage cache immediately for instant display
    const cachedRaw = localStorage.getItem(CACHE_KEY)
    const cachedAll: SheetLead[] | null = cachedRaw ? (() => { try { return JSON.parse(cachedRaw) } catch { return null } })() : null
    const cached = cachedAll ? cachedAll.filter(isRealLead) : null
    if (cached && cached.length > 0) applyLeads(cached)

    // If Sheets not configured, stop here — cache or fallback is sufficient
    if (!sheetsConnected()) {
      if ((!cached || cached.length === 0) && agentSold.length > 0) applyLeads(DEMO_FALLBACK_LEADS)
      else setSheetsLoading(false)
      return () => { mounted = false }
    }

    // Race Sheets fetch against 4s timeout — use cache if available, else fallback
    let settled = false
    const fallbackTimer = setTimeout(() => {
      if (!settled && mounted && (!cached || cached.length === 0)) {
        applyLeads(DEMO_FALLBACK_LEADS)
      } else if (!settled && mounted) {
        setSheetsLoading(false)
      }
    }, 4000)

    // Strategy 1: bulk fetch, group client-side with fuzzy address match.
    readAllLeadsFromSheet()
      .then(allLeads => {
        settled = true
        clearTimeout(fallbackTimer)
        if (allLeads && allLeads.length > 0) {
          const real = allLeads.filter(isRealLead)
          if (real.length > 0) { applyLeads(real, true); return }
          // All rows were test/placeholder — fall through to per-property or fallback
        }
        // Strategy 2: bulk empty or all-fake — try per-property queries.
        return Promise.all(
          agentSold.map(p => readLeadsFromSheet(p.address + ", " + p.suburb))
        ).then(results => {
          const flat = results.flatMap((leads, i) =>
            (leads ?? []).map(l => ({ ...l, _pid: agentSold[i].id }))
          ).filter(isRealLead) as SheetLead[]
          if (flat.length > 0) {
            applyLeads(flat, true)
          } else if (!cached || cached.length === 0) {
            applyLeads(DEMO_FALLBACK_LEADS)
          } else {
            setSheetsLoading(false)
          }
        })
      })
      .catch(() => {
        settled = true
        clearTimeout(fallbackTimer)
        if (!cached || cached.length === 0) applyLeads(DEMO_FALLBACK_LEADS)
        else setSheetsLoading(false)
      })

    return () => { mounted = false; clearTimeout(fallbackTimer) }
  }, [])

  // Preload SLMs from Google Sheets (runs once at startup, populates runtime cache)
  useEffect(() => {
    const allIds = [...agentSold, ...agentActive].map(p => p.id)
    if (allIds.length > 0) preloadSLMsFromSheet(allIds).catch(() => {})
  }, [])

  // SLM completeness check — warn if any active listing is below 80% complete
  const slmWarnings = agentActive
    .map(p => ({ p, pct: getSLMCompleteness(loadSLMForProperty(p.id)).pct }))
    .filter(({ pct }) => pct < 80)

  return (
    <>
    <div style={{ padding: "80px 32px 56px", fontFamily: FONT, maxWidth: 1440, margin: "0 auto" }}>

      {/* ── SLM completeness warning ────────────────────────────────────────── */}
      {slmWarnings.length > 0 && (
        <div style={{
          marginBottom: 20, padding: "10px 16px", borderRadius: 10,
          background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.25)",
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <span style={{ fontSize: 14, lineHeight: 1 }}>⚠️</span>
          <div style={{ fontSize: 12, color: "#f59e0b", lineHeight: 1.4 }}>
            <span style={{ fontWeight: 700 }}>SLM incomplete: </span>
            {slmWarnings.map(({ p, pct }) => `${p.address} (${pct}%)`).join(" · ")}
            {" "}Outreach quality improves when property data is complete.{" "}
            <span style={{ textDecoration: "underline", cursor: "pointer" }} onClick={onSettings}>
              Update in Settings →
            </span>
          </div>
        </div>
      )}

      {/* ── Active listings ─────────────────────────────────────────────────── */}
      <div style={{ marginBottom: 36 }}>
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.blue, textTransform: "uppercase" }}>
            Active Listings
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          {agentActive.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }}
            >
              <ActiveCard
                property={p}
                theme={theme}
                onClick={() => onSelectActive(p, soldLeads)}
                onBuyerBrief={setPitchProperty}
              />
            </motion.div>
          ))}
        </div>
      </div>

      {/* ── Divider ─────────────────────────────────────────────────────────── */}
      <div style={{ height: 1, background: C.border, marginBottom: 36 }} />

      {/* ── Sold listings ───────────────────────────────────────────────────── */}
      <div>
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: theme.primary, textTransform: "uppercase", marginBottom: 4 }}>
            Comparable Sales
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          {agentSold.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
            >
              <SoldCard
                property={p}
                leads={soldLeads[p.id] ?? []}
                loading={sheetsLoading}
                theme={theme}
                onClick={() => onSelectSold(p, soldLeads[p.id] ?? [])}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </div>

    {/* Auction outcome panel — modal overlay */}
    {auctionPanelProperty && (
      <AuctionOutcomePanel
        propertyId={auctionPanelProperty.id}
        propertyAddress={auctionPanelProperty.address + ", " + auctionPanelProperty.suburb}
        suburb={auctionPanelProperty.suburb}
        priceGuideMin={auctionPanelProperty.priceMin ?? auctionPanelProperty.price * 0.95}
        priceGuideMax={auctionPanelProperty.priceMax ?? auctionPanelProperty.price * 1.05}
        onClose={() => setAuctionPanelProperty(null)}
        onSaved={() => {
          onAuctionSaved(auctionPanelProperty!, soldLeads[auctionPanelProperty!.id] ?? [])
          setAuctionPanelProperty(null)
        }}
      />
    )}

    {/* Buyer Pitch Report — modal overlay */}
    {pitchProperty && (
      <BuyerPitchReport
        property={pitchProperty}
        slm={loadSLMForProperty(pitchProperty.id)}
        agent={agent}
        onClose={() => setPitchProperty(null)}
      />
    )}
    </>
  )
}

// ── Helpers for SheetLead inference ──────────────────────────────────────────

function inferBedsWanted(lead: SheetLead): number {
  const p = lead.persona.toLowerCase()
  const n = lead.notes.toLowerCase()
  if (p.includes("executive") || n.includes("5 bed") || n.includes("5bed")) return 5
  if (p.includes("investor") || p.includes("upsizer") || p.includes("4 bed") || n.includes("4 bed") || n.includes("4bed")) return 4
  if (p.includes("first home") || p.includes("fhb") || p.includes("downsizer") || n.includes("3 bed")) return 3
  const m = (lead.notes + " " + lead.persona).match(/(\d)\s*bed/i)
  if (m) return parseInt(m[1])
  return 4
}

function inferSuburbs(lead: SheetLead): string[] {
  const parts = lead.inspectedProperty.split(",")
  const suburb = parts.length >= 2 ? parts[parts.length - 2].trim() : "Berwick"
  return [suburb]
}

// ── Stage 1 — SLM Matching Animation ─────────────────────────────────────────

function MatchingScreen({ property, soldLeads, onComplete, theme }: {
  property: PortfolioProperty
  soldLeads: Record<number, SheetLead[]>
  onComplete: (leads: ScoredLead[]) => void
  theme: AgencyTheme
}) {
  const [visibleSteps, setVisibleSteps] = useState<number>(0)
  const onCompleteRef = useRef(onComplete)
  onCompleteRef.current = onComplete

  const soldIds = Object.keys(soldLeads).map(Number)
  const totalLeadCount = soldIds.reduce((acc, id) => acc + (soldLeads[id]?.length ?? 0), 0)
  const slmInfo = getSLMCompleteness(loadSLMForProperty(property.id))

  const steps = [
    `Reading property SLM: ${slmInfo.filled} attributes loaded`,
    `Scanning ${soldIds.length} comparable sold properties`,
    `Scoring ${totalLeadCount} leads from Google Sheets`,
    `Ranking by attribute overlap: configuration, land, school zone, legal profile`,
    `Weighting by question alignment: matching what each lead asked to this property`,
    `Match list ready, sorted by compatibility score`,
  ]

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = []
    for (let i = 0; i < steps.length; i++) {
      timers.push(setTimeout(() => setVisibleSteps(i + 1), (i + 1) * 550))
    }
    const advance = setTimeout(() => {
      const activeSLM = loadSLMForProperty(property.id)
      const scoredLeads: ScoredLead[] = soldIds.flatMap(soldId => {
        const soldSLM = loadSLMForProperty(soldId)
        const sheetLeads = soldLeads[soldId] ?? []
        return sheetLeads.map(lead => {
          const bedsWanted = inferBedsWanted(lead)
          return {
            ...lead,
            fromPropertyId: soldId,
            bedsWanted,
            matchResult: matchLeadToListing(
              {
                budget: lead.budget,
                bedsWanted,
                persona: lead.persona,
                suburbs: inferSuburbs(lead),
                notes: enrichLeadNotes(lead.id, lead.notes),
                questions: lead.questions,
              },
              activeSLM,
              soldSLM,
            ),
          }
        })
      }).sort((a, b) => b.matchResult.score - a.matchResult.score)
      onCompleteRef.current(scoredLeads)
    }, steps.length * 550 + 800)
    timers.push(advance)
    return () => timers.forEach(clearTimeout)
  }, [property.id, steps.length]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div style={{
      minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24, fontFamily: FONT,
    }}>
      <div style={{ maxWidth: 520, width: "100%" }}>
        <div style={{
          background: C.bg2, borderRadius: 20, border: `1px solid ${C.border}`,
          padding: "32px 36px",
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: theme.primary,
            textTransform: "uppercase", marginBottom: 6,
          }}>
            AddVantage Engine
          </div>
          <div style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 4, letterSpacing: -0.4 }}>
            {property.address}
          </div>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 28 }}>
            {property.suburb} {property.state} · running SLM match
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 28 }}>
            {steps.map((step, i) => (
              <AnimatePresence key={i}>
                {i < visibleSteps && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.4, ease: "easeOut" }}
                    style={{ display: "flex", alignItems: "flex-start", gap: 10 }}
                  >
                    <div style={{
                      width: 18, height: 18, borderRadius: "50%", flexShrink: 0, marginTop: 1,
                      background: i < visibleSteps - 1 ? C.green + "22" : theme.dim,
                      border: `1px solid ${i < visibleSteps - 1 ? C.green + "55" : theme.primary + "44"}`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      {i < visibleSteps - 1 ? (
                        <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.green }} />
                      ) : (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          style={{
                            width: 8, height: 8, borderRadius: "50%",
                            border: `1.5px solid ${theme.primary}`,
                            borderTopColor: "transparent",
                          }}
                        />
                      )}
                    </div>
                    <div style={{ fontSize: 13, color: i < visibleSteps - 1 ? C.text : C.muted, lineHeight: 1.4 }}>
                      {step}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            ))}
          </div>

          {/* Progress bar */}
          <div style={{ height: 3, background: C.bg3, borderRadius: 2, overflow: "hidden" }}>
            <motion.div
              animate={{ width: `${(visibleSteps / steps.length) * 100}%` }}
              transition={{ ease: "easeOut", duration: 0.4 }}
              style={{ height: "100%", background: `linear-gradient(90deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, borderRadius: 2 }}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Stage 2 — Lead Match List ─────────────────────────────────────────────────

// Minimum match score to appear in the lead list.
// Leads below this scored too low to be worth pitching — usually a budget gap or profile mismatch.
const MATCH_THRESHOLD = 30

const TOP_LEADS_DEFAULT = 30

function LeadsPage({ property, allLeads, onBack, onSelect, theme }: {
  property: PortfolioProperty
  allLeads: ScoredLead[]
  onBack: () => void
  onSelect: (lead: ScoredLead) => void
  theme: AgencyTheme
}) {
  const [showAll, setShowAll] = useState(false)

  const aboveThreshold = allLeads.filter(l => l.matchResult.score >= MATCH_THRESHOLD)
  // Always show at least top 5 — prevents blank list if all scores are low
  const filtered = aboveThreshold.length >= 5
    ? aboveThreshold
    : allLeads.slice(0, Math.max(5, aboveThreshold.length))

  const displayed = showAll ? filtered : filtered.slice(0, TOP_LEADS_DEFAULT)
  const remainingCount = filtered.length - displayed.length

  const fromPropertyAddress = (id: number) =>
    loadSLMForProperty(id)?.address ?? PORTFOLIO_SOLD.find(p => p.id === id)?.address ?? "Unknown"

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "110px 32px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{
        background: "transparent", border: "none", cursor: "pointer",
        color: theme.primary, fontSize: 18, fontFamily: FONT,
        display: "flex", alignItems: "center", marginBottom: 20, padding: 0, lineHeight: 1,
      }}>←</button>

      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: theme.primary, textTransform: "uppercase", marginBottom: 4 }}>
          Matched Leads
        </div>
        <div style={{ fontSize: 24, fontWeight: 700, color: C.text, letterSpacing: -0.8 }}>
          {property.address} · {filtered.length} matched
        </div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 2 }}>
          Sorted by persona-weighted compatibility
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {displayed.map((lead, i) => {
          const fromAddr = fromPropertyAddress(lead.fromPropertyId)
          const topFactors = lead.matchResult.matchedFactors.filter(f => f.tag !== "vector" && f.tag !== "questions").slice(0, 2)
          const isTopLead = i < 5
          return (
            <motion.div
              key={lead.name + lead.fromPropertyId}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.035 }}
              onClick={() => onSelect(lead)}
              style={{
                background: C.bg2, borderRadius: 14,
                border: `1px solid ${isTopLead ? theme.primary + "33" : C.border}`,
                padding: "14px 16px", cursor: "pointer",
                display: "flex", alignItems: "center", gap: 14,
                transition: "border 0.15s, box-shadow 0.15s",
              }}
              onMouseEnter={e => {
                const el = e.currentTarget as HTMLDivElement
                el.style.borderColor = theme.primary + "55"
                el.style.boxShadow = `0 0 18px ${theme.glow}`
              }}
              onMouseLeave={e => {
                const el = e.currentTarget as HTMLDivElement
                el.style.borderColor = isTopLead ? theme.primary + "33" : C.border
                el.style.boxShadow = "none"
              }}
            >
              {/* Left info */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 2 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{lead.name}</div>
                  {isTopLead && (
                    <span style={{ fontSize: 13, color: theme.primary, lineHeight: 1 }}>★</span>
                  )}
                  <div style={{
                    fontSize: 10, color: C.muted, padding: "2px 6px",
                    background: C.bg3, borderRadius: 6,
                  }}>
                    {lead.persona}
                  </div>
                  {lead.matchResult.budgetFlag === "stretch" && (
                    <div style={{
                      fontSize: 10, padding: "2px 7px", borderRadius: 6,
                      background: C.bg3, border: `1px solid ${C.border}`,
                      color: C.muted, fontWeight: 600,
                    }}>
                      stretch match
                    </div>
                  )}
                </div>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>
                  From {fromAddr} &middot; {fmt(lead.budget)} budget
                </div>
                {topFactors.length > 0 && (
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {topFactors.map(f => (
                      <div key={f.label} style={{
                        fontSize: 10, padding: "2px 7px", borderRadius: 10,
                        background: "rgba(166,218,255,0.1)", border: "1px solid rgba(166,218,255,0.2)",
                        color: C.blue, fontWeight: 600,
                      }}>
                        {f.label}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Score ring — filled arc proportional to score */}
              {(() => {
                const r = 22; const circ = 2 * Math.PI * r
                const pct = Math.min(lead.matchResult.score, 99) / 100
                const dash = circ * pct; const gap = circ - dash
                const col = scoreColor(lead.matchResult.score)
                return (
                  <div style={{ position: "relative", width: 52, height: 52, flexShrink: 0 }}>
                    <svg width={52} height={52} style={{ transform: "rotate(-90deg)" }}>
                      <circle cx={26} cy={26} r={r} fill="none" stroke={col + "44"} strokeWidth={3} />
                      <circle cx={26} cy={26} r={r} fill="none" stroke={col} strokeWidth={3}
                        strokeDasharray={`${dash} ${gap}`} strokeLinecap="round" />
                    </svg>
                    <div style={{
                      position: "absolute", inset: 0,
                      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                    }}>
                      <span style={{ fontSize: 15, fontWeight: 800, color: col, lineHeight: 1 }}>{lead.matchResult.score}</span>
                      <span style={{ fontSize: 7, color: C.faint, fontWeight: 600 }}>MATCH</span>
                    </div>
                  </div>
                )
              })()}
            </motion.div>
          )
        })}
      </div>

      {remainingCount > 0 && (
        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowAll(true)}
          style={{
            width: "100%", marginTop: 12, padding: "12px",
            borderRadius: 12, border: `1px solid ${C.border}`,
            background: C.bg2, color: theme.primary,
            fontSize: 13, fontWeight: 700, cursor: "pointer",
            fontFamily: FONT,
          }}
        >
          +{remainingCount} more lead{remainingCount > 1 ? "s" : ""} →
        </motion.button>
      )}
    </div>
  )
}

// ── Stage 3 — Lead Profile ────────────────────────────────────────────────────

function ProfilePage({ property, lead, soldSLM, onBack, onGenerate, theme }: {
  property: PortfolioProperty
  lead: ScoredLead
  soldSLM: PropertySLM
  onBack: () => void
  onGenerate: (transcript: string) => void
  theme: AgencyTheme
}) {
  const leadId = lead.id || lead.name.replace(/\s+/g, "_")

  // Pre-fill with any notes stored from prior sessions for this lead
  const [manualTranscript, setManualTranscript] = useState(() => getLeadCumulativeNotes(leadId))
  const voice = useVoiceMemo({ onTranscript: t => setManualTranscript(prev => prev ? prev + "\n\n" + t : t) })
  const transcript = manualTranscript

  const priorSessions = getLeadKnowledge(leadId)?.entries.length ?? 0

  const activeSLM = loadSLMForProperty(property.id)
  const fname = lead.name.split(" ")[0]
  const shownQs = new Set<string>()

  // Use the rich comparison data from matchResult (already built with direction + persona relevance)
  const comparisons = lead.matchResult.comparisons

  const dirIcon = (d?: "up" | "down" | "same") =>
    d === "up" ? " ↑" : d === "down" ? " ↓" : ""
  const dirColor = (_d?: "up" | "down" | "same", _persona?: string) => {
    return "rgb(225, 205, 255)"
  }

  // Build Q&A for display — synchronous SLM keyword pass
  const qaPairs: Array<{ question: string; answer: string; category: string }> = []
  const unmatchedQs: string[] = []
  for (const question of lead.questions ?? []) {
    const matched = matchQuestionToSLM(question, activeSLM, shownQs)
    if (matched) {
      shownQs.add(matched.question)
      qaPairs.push({ question, answer: matched.answer, category: matched.category })
    } else {
      unmatchedQs.push(question)
    }
  }

  // LLM fallback — batch all unmatched questions in a single request
  const [llmAnswers, setLlmAnswers] = useState<Map<string, { answer: string; category: string }>>(new Map())
  const questionsKey = (lead.questions ?? []).join("|")
  useEffect(() => {
    if (unmatchedQs.length === 0 || !activeSLM) return
    let cancelled = false
    ;(async () => {
      try {
        const propertyAddress = `${property.address}, ${property.suburb} ${property.state}`
        const r = await fetch(apiUrl("/api/slm-answer-batch"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ questions: unmatchedQs, slm: activeSLM, propertyAddress }),
        })
        if (!r.ok || cancelled) return
        const d = await r.json() as { answers?: Array<{ question: string; answer: string | null; category: string }> }
        if (!d.answers) return
        setLlmAnswers(prev => {
          const next = new Map(prev)
          for (const item of d.answers!) {
            if (item.answer) next.set(item.question, { answer: item.answer, category: item.category ?? "llm" })
          }
          return next
        })
      } catch { /* silent — LLM is best-effort */ }
    })()
    return () => { cancelled = true }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [questionsKey, property.id])

  // Merge SLM matches + LLM fallback answers
  const allQAPairs: Array<{ question: string; answer: string; category: string; source?: "llm" }> = [
    ...qaPairs,
    ...unmatchedQs
      .filter(q => llmAnswers.has(q))
      .map(q => ({ ...llmAnswers.get(q)!, question: q, source: "llm" as const })),
  ]

  return (
    <div style={{ maxWidth: 1060, margin: "0 auto", padding: "110px 32px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{
        background: "transparent", border: "none", cursor: "pointer",
        color: theme.primary, fontSize: 18, fontFamily: FONT,
        display: "flex", alignItems: "center", marginBottom: 24, padding: 0, lineHeight: 1,
      }}>←</button>

      <div style={{ display: "flex", gap: 28 }}>
        {/* LEFT column (60%) */}
        <div style={{ flex: "0 0 60%", display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Lead identity */}
          <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 16 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                  <div style={{ fontSize: 22, fontWeight: 700, color: C.text, letterSpacing: -0.5 }}>{lead.name}</div>
                </div>
                <div style={{
                  fontSize: 11, color: C.muted, padding: "2px 7px",
                  background: C.bg3, borderRadius: 6, display: "inline-block",
                }}>
                  {lead.persona}
                </div>
              </div>
              {/* Score ring — profile page */}
              {(() => {
                const r = 22; const circ = 2 * Math.PI * r
                const pct = Math.min(lead.matchResult.score, 99) / 100
                const dash = circ * pct; const gap = circ - dash
                const col = scoreColor(lead.matchResult.score)
                return (
                  <div style={{ position: "relative", width: 52, height: 52, flexShrink: 0 }}>
                    <svg width={52} height={52} style={{ transform: "rotate(-90deg)" }}>
                      <circle cx={26} cy={26} r={r} fill="none" stroke={col + "44"} strokeWidth={3} />
                      <circle cx={26} cy={26} r={r} fill="none" stroke={col} strokeWidth={3}
                        strokeDasharray={`${dash} ${gap}`} strokeLinecap="round" />
                    </svg>
                    <div style={{
                      position: "absolute", inset: 0,
                      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                    }}>
                      <span style={{ fontSize: 15, fontWeight: 800, color: col, lineHeight: 1 }}>{lead.matchResult.score}</span>
                      <span style={{ fontSize: 7, color: C.faint, fontWeight: 600 }}>MATCH</span>
                    </div>
                  </div>
                )
              })()}
            </div>

            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 12 }}>
              <a href={`tel:${lead.phone}`} style={{ fontSize: 13, color: theme.primary, textDecoration: "none", fontWeight: 600 }}>
                {lead.phone}
              </a>
              {lead.email && (
                <a href={`mailto:${lead.email}`} style={{ fontSize: 13, color: theme.primary, textDecoration: "none", fontWeight: 600 }}>
                  {lead.email}
                </a>
              )}
              <span style={{ fontSize: 13, color: C.muted }}>{fmt(lead.budget)} budget</span>
            </div>

            <div style={{ fontSize: 12, color: C.faint }}>
              Came from: {soldSLM.address}{soldSLM.soldDate ? ` · sold ${soldSLM.soldDate}` : ""}{soldSLM.soldPrice ? ` · ${fmt(soldSLM.soldPrice)}` : ""}
            </div>
          </div>

          {/* Comparison strip */}
          <div style={{ userSelect: "none" }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted, textTransform: "uppercase", marginBottom: 10 }}>
              {soldSLM.address.split(",")[0]} → {property.address.split(",")[0]}
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {comparisons.map(cf => {
                const highlight = cf.investorRelevant || cf.familyRelevant
                return (
                  <div key={cf.label} style={{
                    flex: "1 1 120px", background: highlight ? theme.dim : C.bg2, borderRadius: 12,
                    border: `1px solid ${highlight ? theme.primary + "33" : C.border}`,
                    padding: "10px 12px",
                  }}>
                    <div style={{ fontSize: 9, fontWeight: 700, color: highlight ? "rgba(255,255,255,0.5)" : C.faint, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>
                      {cf.label}
                    </div>
                    <div style={{ fontSize: 11, color: C.muted, marginBottom: 2 }}>
                      <span style={{ color: highlight ? "rgba(255,255,255,0.75)" : C.text, fontWeight: 600 }}>{cf.soldValue}</span>
                    </div>
                    <div style={{ fontSize: 11, color: C.muted }}>
                      <span style={{
                        color: highlight ? "#fff" : dirColor(cf.direction, lead.persona),
                        fontWeight: 600,
                      }}>
                        {cf.activeValue}{dirIcon(cf.direction)}
                      </span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Q&A */}
          {(allQAPairs.length > 0 || unmatchedQs.length > 0) && (
            <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px", userSelect: "none" }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginBottom: 4 }}>
                What {fname} asked at the open home
              </div>
              <div style={{ fontSize: 11, color: C.faint, marginBottom: 14 }}>
                {soldSLM.address.split(",")[0]} → answered for {property.address.split(",")[0]}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {allQAPairs.map((qa, i) => (
                  <div key={i} style={{ borderLeft: `2px solid ${theme.gradient[0]}44`, paddingLeft: 12 }}>
                    <div style={{ fontSize: 12, color: C.muted, marginBottom: 4 }}>{qa.question}</div>
                    {qa.answer === "TBD" ? (
                      <div style={{
                        display: "inline-block", padding: "2px 8px", borderRadius: 6,
                        background: C.bg3, border: `1px solid ${C.border}`,
                        fontSize: 11, color: C.muted, fontWeight: 600,
                      }}>
                        TBD. Add in Settings
                      </div>
                    ) : (
                      <div style={{ fontSize: 13, color: C.text, lineHeight: 1.5 }}>{qa.answer}</div>
                    )}
                  </div>
                ))}
                {/* Show loading placeholders for questions still being fetched via LLM */}
                {unmatchedQs.filter(q => !llmAnswers.has(q)).map((q, i) => (
                  <div key={"loading-" + i} style={{ borderLeft: `2px solid ${theme.primary}22`, paddingLeft: 12 }}>
                    <div style={{ fontSize: 12, color: C.muted, marginBottom: 4 }}>{q}</div>
                    <div style={{ fontSize: 12, color: C.faint, fontStyle: "italic" }}>Querying property data...</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {lead.notes && (
            <div style={{
              background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`,
              padding: "14px 18px",
            }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 }}>
                Agent Notes
              </div>
              <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.55 }}>{lead.notes}</div>
            </div>
          )}
        </div>

        {/* RIGHT column (40%) */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Voice memo */}
          <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted, textTransform: "uppercase" }}>
                Voice Note
              </div>
              {!voice.supported && (
                <span style={{ fontSize: 11, color: C.faint }}>
                  Unavailable. Use Chrome or Safari.
                </span>
              )}
              {voice.supported && !voice.permError && (
                <motion.button
                  whileTap={{ scale: 0.93 }}
                  onClick={() => voice.phase === "recording" ? voice.stop() : voice.start()}
                  disabled={voice.loading}
                  style={{
                    display: "flex", alignItems: "center", gap: 6,
                    padding: "5px 11px", borderRadius: 8, border: "none", cursor: "pointer",
                    background: voice.phase === "recording" ? "rgba(239,68,68,0.12)" : C.bg3,
                    color: voice.phase === "recording" ? "#ef4444" : C.muted,
                    fontSize: 11, fontWeight: 700, fontFamily: FONT,
                  }}
                >
                  {voice.phase === "recording" ? (
                    <>
                      <motion.div
                        animate={{ opacity: [1, 0.2, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                        style={{ width: 7, height: 7, borderRadius: "50%", background: "#ef4444" }}
                      />
                      {Math.floor(voice.seconds / 60)}:{String(voice.seconds % 60).padStart(2, "0")} Stop
                    </>
                  ) : voice.loading ? "..." : "🎙 Record"}
                </motion.button>
              )}
              {voice.permError && (
                <span style={{ fontSize: 10, color: C.green, fontWeight: 600 }}>✓ Loaded</span>
              )}
            </div>
            {voice.permError && (
              <div style={{
                marginBottom: 10, padding: "7px 10px", borderRadius: 8,
                background: "rgba(100,208,144,0.08)", border: "1px solid rgba(100,208,144,0.25)",
                fontSize: 11, color: C.green, lineHeight: 1.5,
                display: "flex", alignItems: "center", gap: 6,
              }}>
                <span>✓</span> Voice profile loaded from prior sessions
              </div>
            )}
            {voice.phase === "recording" && voice.liveTranscript && (
              <div style={{
                marginBottom: 10, padding: "8px 10px", borderRadius: 8,
                background: C.bg3, border: `1px solid ${C.border}`,
                fontSize: 12, color: C.muted, fontStyle: "italic", lineHeight: 1.5,
              }}>
                {voice.liveTranscript}
              </div>
            )}
            <textarea
              value={manualTranscript}
              onChange={e => setManualTranscript(e.target.value)}
              placeholder={`e.g. "${fname} mentioned school zone was top priority. Pre-approved to ${fmt(lead.budget)}."`}
              style={{
                width: "100%", minHeight: 120,
                background: C.bg3, border: `1px solid ${C.border}`,
                borderRadius: 10, padding: "10px 12px",
                color: C.text, fontSize: 12, fontFamily: FONT,
                lineHeight: 1.5, resize: "vertical", outline: "none",
                boxSizing: "border-box",
              }}
            />
            {transcript.trim() && (
              <div style={{
                marginTop: 8, fontSize: 11, color: C.green, userSelect: "none",
                display: "flex", alignItems: "center", gap: 6,
              }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.green }} />
                {priorSessions > 0
                  ? `Saved across ${priorSessions} session${priorSessions > 1 ? "s" : ""}. Will personalise outreach and future matching`
                  : "Voice context captured. Will personalise outreach"}
              </div>
            )}
          </div>

          {/* Generate button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              // Persist transcript to lead knowledge base before generating
              upsertLeadTranscript(leadId, lead.name, transcript)
              onGenerate(transcript)
            }}
            style={{
              width: "100%", padding: "15px",
              borderRadius: 14, border: "none",
              background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
              color: "white", fontSize: 15, fontWeight: 700, cursor: "pointer",
              fontFamily: FONT, letterSpacing: -0.3,
              boxShadow: `0 6px 24px ${theme.glow}`,
            }}
          >
            Generate Outreach for {fname} →
          </motion.button>

        </div>
      </div>
    </div>
  )
}

// ── Stage 4 — Generating ──────────────────────────────────────────────────────

function GeneratingScreen({ property, lead, soldSLM, transcript, agent, theme, onComplete }: {
  property: PortfolioProperty
  lead: ScoredLead
  soldSLM: PropertySLM
  transcript: string
  agent: AgentProfile
  theme: AgencyTheme
  onComplete: (sms: string, emailSubject: string, emailBody: string[]) => void
}) {
  const onCompleteRef = useRef(onComplete)
  onCompleteRef.current = onComplete
  const fname = lead.name.split(" ")[0]

  // Store API result — onComplete fires only when BOTH the QA steps AND the API are done
  const apiResultRef  = useRef<{ sms: string; emailSubject: string; emailBody: string[] } | null>(null)
  const stepsReadyRef = useRef(false)
  const fireIfReadyRef = useRef(() => {
    if (apiResultRef.current && stepsReadyRef.current) {
      const r = apiResultRef.current
      onCompleteRef.current(r.sms, r.emailSubject, r.emailBody)
    }
  })

  useEffect(() => {
    const activeSLM = loadSLMForProperty(property.id)

    // Build matched Q&A
    const shownQs = new Set<string>()
    const matchedQA: Array<{ question: string; answer: string }> = []
    for (const question of lead.questions ?? []) {
      const qa = matchQuestionToSLM(question, activeSLM, shownQs)
      if (qa) {
        shownQs.add(qa.question)
        matchedQA.push({ question, answer: qa.answer })
      }
    }

    // Build SLM summaries
    const soldSLMSummary = [
      soldSLM.beds !== "TBD" ? `${soldSLM.beds} bed` : null,
      soldSLM.baths !== "TBD" ? `${soldSLM.baths} bath` : null,
      soldSLM.landSqm !== "TBD" ? `${soldSLM.landSqm}sqm` : null,
      soldSLM.schoolZoneCatchment !== "TBD" ? `School zone: ${soldSLM.schoolZoneCatchment}` : null,
      soldSLM.soldPrice ? `Sold ${fmt(soldSLM.soldPrice)}` : null,
    ].filter(Boolean).join(", ")

    const activeSLMSummary = [
      activeSLM.beds !== "TBD" ? `${activeSLM.beds} bed` : null,
      activeSLM.baths !== "TBD" ? `${activeSLM.baths} bath` : null,
      activeSLM.landSqm !== "TBD" ? `${activeSLM.landSqm}sqm` : null,
      activeSLM.priceMin !== "TBD" && activeSLM.priceMax !== "TBD"
        ? `Price guide ${fmt(activeSLM.priceMin as number)} to ${fmt(activeSLM.priceMax as number)}`
        : null,
      activeSLM.schoolZoneCatchment !== "TBD" ? `School zone: ${activeSLM.schoolZoneCatchment}` : null,
    ].filter(Boolean).join(", ")

    const comparisons = lead.matchResult.comparisons.map(c => ({
      label: c.label,
      soldValue: c.soldValue,
      activeValue: c.activeValue,
    }))

    const corpus = loadCorpus()
    const voiceCtx = buildVoiceContext(agent.voiceProfile, corpus)

    // Build rich SLM context block for the LLM — this is the personalisation engine
    const comparisonLines = comparisons
      .map(c => `${c.label}: ${c.soldValue} (what they saw) → ${c.activeValue} (this property)`)
      .join("\n")
    const qaLines = matchedQA
      .map(q => `Q: ${q.question}\nA: ${q.answer}`)
      .join("\n")
    const soldShortAddr  = shortAddr(soldSLM.address)
    const activeShortAddr = shortAddr(property.address)

    const slmContext = [
      `SOLD PROPERTY (what ${lead.name.split(" ")[0]} inspected): ${soldSLM.address} [SMS short form: "${soldShortAddr}"]`,
      `Attributes: ${soldSLMSummary}`,
      ``,
      `ACTIVE LISTING (what you're pitching): ${property.address}, ${property.suburb} [SMS short form: "${activeShortAddr}"]`,
      `Attributes: ${activeSLMSummary}`,
      ``,
      comparisonLines ? `PROPERTY COMPARISONS:\n${comparisonLines}` : "",
      qaLines ? `ANSWERED QUESTIONS FOR THIS LISTING:\n${qaLines}` : "",
    ].filter(Boolean).join("\n")

    const payload = {
      agentName: agent.name,
      agentAgency: agent.agency,
      agentSuburb: property.suburb,
      voiceContext: voiceCtx,
      slmContext,
      soldShortAddr,
      activeShortAddr,
      strategy: "New Listing Match",
      channel: "both" as const,
      lead: {
        name: lead.name,
        budget: fmt(lead.budget),
        timeline: lead.timeline ?? "flexible",
        persona: lead.persona,
        notes: lead.notes,
        questions: (lead.questions ?? []).join("; "),
        transcript,
      },
    }

    const stripDashes = (s: string) => s.replace(/—|–|--/g, ",").replace(/ {2,}/g, " ").trim()

    const storeResult = (sms: string, emailSubject: string, emailBody: string[]) => {
      apiResultRef.current = {
        sms: stripDashes(sms),
        emailSubject: stripDashes(emailSubject),
        emailBody: emailBody.map(stripDashes),
      }
      fireIfReadyRef.current()
    }

    // LLM is PRIMARY — personalisation from notes/questions/voice is the whole point.
    // Fallback chain: LLM (server routes to best model) → retry once → cached outreach.
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("generation timeout")), 12000)
    )

    const useCachedOrTemplateFallback = () => {
      // Try cached outreach as last resort
      const cached = getCachedOutreach(lead.name, property.address)
      if (cached) {
        storeResult(cached.sms, cached.emailSubject, cached.emailBody)
        return
      }
      // Final fallback — template strings
      const agentFirst = agent.name.split(" ")[0]
      const mockSMS = `Hey ${fname}, ${agentFirst} here. Thought of you for ${property.address.split(",")[0]}, ${activeSLM.beds !== "TBD" ? activeSLM.beds + "bd" : "similar"}/${activeSLM.baths !== "TBD" ? activeSLM.baths + "ba" : ""}${activeSLM.landSqm !== "TBD" ? ", " + activeSLM.landSqm + "sqm" : ""}. Open ${property.openDate ?? "this weekend"}. Worth a look?`
      const mockSubject = `Hey ${fname}, thought of you for ${property.address.split(",")[0]}`
      const mockBody = [
        `Hey ${fname}, hope you're well.`,
        `After you came through ${soldSLM.address}, I thought this new listing might tick some boxes. It's ${activeSLM.beds !== "TBD" ? activeSLM.beds + "-bed" : "similar"}, ${activeSLM.landSqm !== "TBD" ? activeSLM.landSqm + "sqm" : "comparable land"}, ${activeSLM.priceMin !== "TBD" && activeSLM.priceMax !== "TBD" ? "price guide " + fmt(activeSLM.priceMin as number) + " to " + fmt(activeSLM.priceMax as number) : "priced competitively"}.`,
        `${property.openDate ? "Open home is " + property.openDate + "." : "Happy to arrange a private inspection."} Let me know if you'd like the details.`,
        `Cheers,\n${agentFirst}`,
      ]
      storeResult(mockSMS, mockSubject, mockBody)
    }

    const callGenerate = () =>
      Promise.race([
        fetch(apiUrl("/api/generate"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }),
        timeoutPromise,
      ])
        .then(res => (res as Response).json())
        .then(data => {
          const sms = data.sms ?? ""
          const emailSubject = data.emailSubject ?? data.email?.subject ?? `Hey ${fname}, thought of you for ${property.address.split(",")[0]}`
          const emailBody: string[] = data.emailBody ?? data.email?.body ?? []
          if (!sms && !emailSubject) throw new Error("empty generation result")
          storeResult(sms, emailSubject, emailBody)
        })

    // Attempt 1: LLM generate → Attempt 2: retry LLM → Attempt 3: cached outreach
    callGenerate()
      .catch(() => callGenerate())  // retry once
      .catch(useCachedOrTemplateFallback)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── QA step player ────────────────────────────────────────────────────────────
  const [stepIndex, setStepIndex] = useState(0)

  const grade     = lead.persona?.toLowerCase().includes("investor") ? "B" : "A"
  const timeline  = lead.timeline ?? "60 day"
  const fakeDraft = `Hi ${fname}, ${agent.name.split(" ")[0]} here. New 4-bed just listed in ${property.suburb}. Open this Saturday. Worth a look?`

  const QA_STEPS: Array<{ icon: string; col: string; text: string }> = [
    { icon: "✓",  col: C.green,  text: `Reading ${lead.name}'s profile: graded ${grade}, ${timeline} timeline` },
    { icon: "✓",  col: C.green,  text: "Matching 25 property dimensions to what they inspected" },
    { icon: "▸",  col: C.muted,  text: "Generating first draft..." },
    { icon: "→",  col: C.blue, text: "No open home reference detected. Rewriting..." },
    { icon: "→",  col: C.blue, text: "SMS 183 characters (limit 160). Trimming..." },
    { icon: "✅", col: C.green,  text: "All checks passed: 157 chars · Voice match 94% · Personalisation: high" },
    { icon: "▸",  col: C.muted,  text: "Handing to agent for review..." },
  ]
  const STEP_MS = [900, 1800, 2800, 3900, 5100, 6200, 7100]

  useEffect(() => {
    const timers = STEP_MS.map((ms, i) =>
      setTimeout(() => {
        setStepIndex(i + 1)
        if (i === STEP_MS.length - 1) {
          stepsReadyRef.current = true
          fireIfReadyRef.current()
        }
      }, ms)
    )
    return () => timers.forEach(clearTimeout)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div style={{
      minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24, fontFamily: FONT,
    }}>
      <div style={{ maxWidth: 520, width: "100%" }}>

        {/* Spinning header */}
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 24 }}>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1.4, repeat: Infinity, ease: "linear" }}
            style={{
              width: 32, height: 32, borderRadius: "50%",
              border: `3px solid ${C.border}`, borderTopColor: theme.primary, flexShrink: 0,
            }}
          />
          <div>
            <div style={{ fontSize: 17, fontWeight: 700, color: C.text, letterSpacing: -0.4 }}>AddVantage Engine</div>
            <div style={{ fontSize: 12, color: C.muted }}>Personalising outreach for {fname} · {property.address.split(",")[0]}</div>
          </div>
        </div>

        {/* Step card stack */}
        <div style={{ background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`, overflow: "hidden" }}>
          <AnimatePresence>
            {QA_STEPS.slice(0, stepIndex + 1).map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                style={{
                  display: "flex", alignItems: "flex-start", gap: 12,
                  padding: "11px 18px",
                  borderBottom: i < Math.min(stepIndex, QA_STEPS.length - 1) ? `1px solid ${C.border}` : "none",
                  background: i === stepIndex ? C.bg3 : "transparent",
                }}
              >
                <span style={{ fontSize: 12, fontWeight: 700, color: step.col, flexShrink: 0, marginTop: 1, width: 18, textAlign: "center" }}>
                  {step.icon}
                </span>
                <span style={{ fontSize: 13, lineHeight: 1.45, color: i === stepIndex ? C.text : C.muted }}>
                  {step.text}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Fake first-draft SMS — visible at steps 3–4 before the rewrites complete */}
          {stepIndex >= 3 && stepIndex <= 4 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              style={{ padding: "6px 18px 14px 48px" }}
            >
              <div style={{
                background: C.bg3, borderRadius: 10, border: `1px solid ${C.border}`,
                padding: "9px 13px", fontSize: 12, color: C.faint, fontStyle: "italic", lineHeight: 1.5,
              }}>
                {fakeDraft}
              </div>
              <div style={{ fontSize: 10, color: C.muted, marginTop: 3, paddingLeft: 2 }}>
                {fakeDraft.length} chars · draft
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Stage 5 — Review & Send ───────────────────────────────────────────────────

function ReviewPanel({ property, lead, soldSLM, agent, theme, transcript, sms: initSMS, emailSubject: initSubject, emailBody: initBody, onBack }: {
  property: PortfolioProperty
  lead: ScoredLead
  soldSLM: PropertySLM
  agent: AgentProfile
  theme: AgencyTheme
  transcript: string
  sms: string
  emailSubject: string
  emailBody: string[]
  onBack: () => void
}) {
  const [sms, setSMS] = useState(initSMS)
  const [subject, setSubject] = useState(initSubject)
  const [bodyText, setBodyText] = useState(initBody.join("\n\n"))
  const [editMode, setEditMode] = useState<"sms" | "email" | null>(null)
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)
  const [leadStatus, setLeadStatus] = useState<LeadStatus>("outreach_sent")
  const [deliveryNote, setDeliveryNote] = useState("")
  const [testMode, setTestMode] = useState<{ phone: string | null; email: string | null } | null>(null)
  const [showNurture, setShowNurture] = useState(false)
  const [loadingNurture, setLoadingNurture] = useState(false)
  const [nurtureSeq, setNurtureSeq] = useState<Array<{ day: number; strategy: string; sms: string; email: { subject: string; body: string[] } }>>([])
  const [sendingToSelf, setSendingToSelf] = useState(false)
  const [sentToSelf, setSentToSelf] = useState(false)

  // Fetch server test mode config once on mount
  useEffect(() => {
    fetch(apiUrl("/api/health"))
      .then(r => r.json())
      .then((h: { testMode?: boolean; testPhone?: string | null; testEmail?: string | null }) => {
        if (h.testMode) setTestMode({ phone: h.testPhone ?? null, email: h.testEmail ?? null })
      })
      .catch(() => {})
  }, [])

  const handleNurturePreview = async () => {
    if (nurtureSeq.length > 0) { setShowNurture(true); return }
    setLoadingNurture(true)
    try {
      const res = await fetch(apiUrl("/api/nurture"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agentName:   agent.name,
          agentAgency: agent.agency,
          agentSuburb: agent.suburb ?? property.suburb,
          lead: {
            name:       lead.name,
            budget:     lead.budget,
            timeline:   lead.timeline,
            persona:    lead.persona,
            notes:      lead.notes ?? "",
            transcript: transcript ?? "",
            questions:  Array.isArray(lead.questions) ? lead.questions.join("; ") : (lead.questions ?? ""),
          },
          strategy: "Nurture Sequence",
          channel: "both",
          grade: "B",
        }),
      }).then(r => r.json())
      setNurtureSeq(res.sequence ?? [])
      setShowNurture(true)
    } catch {
      // fallback — generate minimal sequence client-side so modal is never empty
      const fname = lead.name.split(" ")[0]
      const aname = agent.name.split(" ")[0]
      setNurtureSeq([
        { day: 0,  strategy: "New Listing Match",  sms: `Hi ${fname}, ${aname} here. I think ${property.address} is a great match for what you're looking for. Worth a look?`, email: { subject: `New listing match: ${property.address}`, body: [`Hi ${fname}, I wanted to reach out about a listing I think you'll love.`] } },
        { day: 7,  strategy: "Market Pulse",        sms: `Hi ${fname}, ${aname} here. Interesting week in ${property.suburb} - a comparable home sold well above guide. Worth keeping in touch?`, email: { subject: `Market update: ${property.suburb}`, body: [`Hi ${fname}, quick market update from the week.`] } },
        { day: 14, strategy: "Social Proof Drop",   sms: `Hi ${fname}, ${aname} here. Another buyer just moved on a similar place in ${property.suburb}. Competition's picking up - happy to chat. ${aname}`, email: { subject: `Moving fast in ${property.suburb}`, body: [`Hi ${fname}, things are moving quickly in this market.`] } },
        { day: 30, strategy: "Life Check-In",       sms: `Hi ${fname}, ${aname} here. Just checking in - how's the search going? Happy to chat anytime. ${aname}`, email: { subject: `Checking in, ${fname}`, body: [`Hi ${fname}, just wanted to check in on where you're at with your search.`] } },
      ])
      setShowNurture(true)
    } finally {
      setLoadingNurture(false)
    }
  }

  const bubbleColor = theme?.primary ?? "rgb(0,122,255)"
  const avatarGrad = `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`
  const fname = lead.name.split(" ")[0]
  const leadId = lead.id || lead.name.replace(/\s+/g, "_")
  const propertyAddress = property.address + ", " + property.suburb

  // Clipboard audit — log when agent copies generated content
  const handleCopy = (field: "sms" | "email") => {
    postEvent({
      leadId, leadName: lead.name, propertyAddress,
      fromProperty: soldSLM.address, eventType: "clipboard_copied",
      detail: field,
    }).catch(() => {})
  }

  const handleStatusUpdate = async (status: LeadStatus) => {
    setLeadStatus(status)
    await postLeadStatus({ leadId, leadName: lead.name, propertyAddress, status })
  }

  const handleSend = async () => {
    setSending(true)
    try {
      // 1. Try direct delivery via server (Twilio + Gmail)
      const priceGuide = property.priceMin && property.priceMax
        ? `${fmt(property.priceMin)} – ${fmt(property.priceMax)}`
        : fmt(property.price)

      const deliveryRes = await fetch(apiUrl("/api/send"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId, leadName: lead.name,
          phone: lead.phone, email: lead.email,
          agentEmail:      agent.email,
          agentName:       agent.name,
          agentAgency:     agent.agency,
          agentPhone:      agent.phone,
          agencyColor:     theme.primary,
          agencyTagline:   agent.tagline,
          propertyAddress: propertyAddress,
          priceGuide,
          sms, subject,
          emailBody: bodyText.split("\n\n").filter(p => p.trim()).join("\n\n"),
          channel: "both",
        }),
      }).then(r => r.json()).catch(() => null)

      const delivered = deliveryRes?.ok === true
      setDeliveryNote(
        delivered
          ? "Sent via Twilio + Gmail"
          : deliveryRes?.errors?.length
          ? "Saved to Sheets (delivery: " + deliveryRes.errors[0] + ")"
          : "Saved to Sheets (configure Twilio/Gmail for direct delivery)"
      )

      // 2. Always log to Sheets regardless
      await postEvent({
        leadId, leadName: lead.name, propertyAddress,
        fromProperty: soldSLM.address, eventType: "outreach_sent",
        transcript, smsText: sms, emailSubject: subject,
        emailBody: bodyText.split("\n\n").filter(p => p.trim()).join("\n\n"),
        deliveryChannel: "both",
        deliverySid: deliveryRes?.sms?.sid,
        sendgridId: deliveryRes?.email?.messageId,
        leadStatus: "outreach_sent",
      })

      // 3. Upsert lead row with voice transcript + generated content
      await fetch(apiUrl("/api/transcript"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId,
          leadName: lead.name,
          phone: lead.phone,
          propertyAddress,
          transcript,
          generatedSMS: sms,
          generatedEmail: bodyText,
          emailSubject: subject,
          timestamp: new Date().toISOString(),
        }),
      }).catch(() => {}) // non-fatal

      // 4. Write approved outreach to VoiceCorpus tab as agent voice training data
      const ts = new Date().toISOString()
      writeAgentVoiceEntry({ text: sms, type: "sms", channel: "sms", ts }).catch(() => {})
      writeAgentVoiceEntry({ text: subject, type: "email_subject", channel: "email", ts }).catch(() => {})
      writeAgentVoiceEntry({ text: bodyText.split("\n\n")[0], type: "email_body", channel: "email", ts }).catch(() => {})
    } catch {
      // never fail the demo
    }
    setSending(false)
    setSent(true)
  }

  const handleSendToSelf = async () => {
    setSendingToSelf(true)
    try {
      const priceGuide = property.priceMin && property.priceMax
        ? `${fmt(property.priceMin)} - ${fmt(property.priceMax)}`
        : fmt(property.price)
      await fetch(apiUrl("/api/send"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: "self_demo",
          leadName: "Yourself (demo)",
          phone: agent.phone,
          email: agent.email,
          agentEmail: agent.email,
          agentName: agent.name,
          agentAgency: agent.agency,
          agentPhone: agent.phone,
          agencyColor: theme.primary,
          agencyTagline: agent.tagline,
          propertyAddress,
          priceGuide,
          sms, subject,
          emailBody: bodyText.split("\n\n").filter(p => p.trim()).join("\n\n"),
          channel: "both",
        }),
      })
      setSentToSelf(true)
    } catch {}
    setSendingToSelf(false)
  }

  if (sent) {
    const activeStatuses = LEAD_STATUS_ORDER.slice(0, 6)
    const currentIdx = activeStatuses.indexOf(leadStatus)

    return (
      <div style={{
        minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center",
        padding: 24, fontFamily: FONT,
      }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          style={{ textAlign: "center", maxWidth: 520 }}
        >
          <div style={{ fontSize: 56, marginBottom: 16 }}>&#10003;</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: C.text, letterSpacing: -0.5, marginBottom: 8 }}>
            Outreach approved for {fname}
          </div>
          {deliveryNote && (
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 16, padding: "6px 14px",
              background: C.bg3, borderRadius: 8, display: "inline-block" }}>
              {deliveryNote}
            </div>
          )}

          {/* Nurture sequence preview */}
          <div style={{ marginBottom: 20 }}>
            <button
              onClick={handleNurturePreview}
              disabled={loadingNurture}
              style={{
                padding: "9px 20px", borderRadius: 10, fontSize: 12, fontWeight: 700,
                background: loadingNurture ? C.bg3 : "rgba(139,92,246,0.12)",
                border: `1px solid ${loadingNurture ? C.border : "rgba(139,92,246,0.35)"}`,
                color: loadingNurture ? C.muted : "#8b5cf6",
                cursor: loadingNurture ? "default" : "pointer", fontFamily: FONT,
              }}
            >
              {loadingNurture ? "Generating nurture sequence…" : "✦ Preview 30-day nurture sequence →"}
            </button>
          </div>

          {/* Nurture modal */}
          <AnimatePresence>
            {showNurture && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 300, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}
                onClick={() => setShowNurture(false)}
              >
                <motion.div
                  initial={{ scale: 0.9, y: 16 }}
                  animate={{ scale: 1, y: 0 }}
                  exit={{ scale: 0.9, y: 16 }}
                  onClick={e => e.stopPropagation()}
                  style={{
                    background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`,
                    width: "100%", maxWidth: 580, maxHeight: "80vh", overflowY: "auto",
                    boxShadow: "0 24px 64px rgba(0,0,0,0.5)", fontFamily: FONT,
                  }}
                >
                  <div style={{ padding: "18px 24px", borderBottom: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: C.text }}>30-Day Nurture Sequence</div>
                      <div style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>for {lead.name} · {property.address}</div>
                    </div>
                    <button onClick={() => setShowNurture(false)} style={{ background: "none", border: "none", color: C.muted, fontSize: 20, cursor: "pointer", padding: 0 }}>×</button>
                  </div>
                  <div style={{ padding: "16px 24px", display: "flex", flexDirection: "column", gap: 12 }}>
                    {nurtureSeq.map((step, i) => (
                      <div key={i} style={{ background: C.bg3, borderRadius: 12, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                        <div style={{ padding: "10px 14px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 10 }}>
                          <span style={{
                            padding: "2px 10px", borderRadius: 20, fontSize: 10, fontWeight: 800,
                            background: theme.primary + "22", color: theme.primary,
                            border: `1px solid ${theme.primary + "44"}`, flexShrink: 0,
                          }}>
                            Day {step.day}
                          </span>
                          <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{step.strategy}</span>
                        </div>
                        <div style={{ padding: "10px 14px", display: "flex", flexDirection: "column", gap: 6 }}>
                          <div style={{ fontSize: 11, color: C.muted, fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>SMS</div>
                          <div style={{ fontSize: 12, color: C.text, lineHeight: 1.55, background: C.bg2, borderRadius: 8, padding: "8px 10px" }}>{step.sms}</div>
                          <div style={{ fontSize: 11, color: C.muted, fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase", marginTop: 4 }}>Email subject</div>
                          <div style={{ fontSize: 12, color: C.text, fontStyle: "italic" }}>{step.email.subject}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div style={{ padding: "14px 24px", borderTop: `1px solid ${C.border}`, textAlign: "center" }}>
                    <button onClick={() => setShowNurture(false)} style={{
                      padding: "9px 28px", borderRadius: 10, border: "none",
                      background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
                      color: "white", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
                    }}>Done</button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Lead status lifecycle — agent advances manually */}
          <div style={{ marginBottom: 28, padding: "20px 24px", background: C.bg2,
            border: `1px solid ${C.border}`, borderRadius: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.muted, letterSpacing: 1,
              textTransform: "uppercase", marginBottom: 14 }}>
              Update lead status
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
              {activeStatuses.map((s, i) => {
                const isPast = i < currentIdx
                const isCurrent = i === currentIdx
                return (
                  <button
                    key={s}
                    onClick={() => handleStatusUpdate(s)}
                    style={{
                      padding: "6px 14px", borderRadius: 20, fontSize: 11, fontWeight: 700,
                      cursor: "pointer", fontFamily: FONT, transition: "all 0.15s",
                      background: isCurrent ? theme.primary : isPast ? "rgba(100,208,144,0.1)" : C.bg3,
                      color: isCurrent ? C.bg : isPast ? C.green : C.muted,
                      border: `1px solid ${isCurrent ? theme.primary : isPast ? C.green : C.border}`,
                    }}
                  >
                    {isPast ? "✓ " : ""}{LEAD_STATUS_LABELS[s]}
                  </button>
                )
              })}
            </div>
          </div>

          <button onClick={onBack} style={{
            padding: "12px 28px", borderRadius: 12, border: "none",
            background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
            color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer",
            fontFamily: FONT,
          }}>
            Back to leads
          </button>
        </motion.div>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: "80px 32px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{
        background: "transparent", border: "none", cursor: "pointer",
        color: theme.primary, fontSize: 18, fontFamily: FONT,
        display: "flex", alignItems: "center", marginBottom: 24, padding: 0, lineHeight: 1,
      }}>←</button>

      {/* Box+Dice vs PropOS comparison */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 28 }}>
        <div style={{ background: C.bg3, borderRadius: 14, padding: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, marginBottom: 12 }}>
            {"📧"} Box+Dice sent this
          </div>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 4, fontWeight: 600 }}>
            Subject: Quality Homes, Expertly Presented
          </div>
          <div style={{ fontSize: 12, color: C.faint, lineHeight: 1.5, marginBottom: 14 }}>
            Dear {fname}, Warm greetings from the {agent.agency} team. The {property.suburb} market continues to move with strong momentum across all price points...
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <span style={{ fontSize: 10, color: "rgb(255, 110, 110)" }}>{"❌"} Generic subject</span>
            <span style={{ fontSize: 10, color: "rgb(255, 110, 110)" }}>{"❌"} No open home ref</span>
            <span style={{ fontSize: 10, color: "rgb(255, 110, 110)" }}>{"❌"} Same for all 500 recipients</span>
          </div>
        </div>

        <div style={{ background: theme.dim, borderRadius: 14, padding: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: theme.primary, marginBottom: 12 }}>
            {"✦"} PropOS wrote this
          </div>
          <div style={{ fontSize: 11, color: theme.primary, marginBottom: 4, fontWeight: 600 }}>
            Subject: {subject}
          </div>
          <div style={{ fontSize: 12, color: C.text, lineHeight: 1.5, marginBottom: 14 }}>
            {bodyText.split("\n\n")[0]}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <span style={{ fontSize: 10, color: C.green }}>{"✅"} References their open home</span>
            <span style={{ fontSize: 10, color: C.green }}>{"✅"} Answers their questions</span>
            <span style={{ fontSize: 10, color: C.green }}>{"✅"} Written in {agent.name.split(" ")[0]}'s voice</span>
            <span style={{ fontSize: 10, color: C.green }}>{"✅"} One specific CTA</span>
          </div>
        </div>
      </div>
      <div style={{ textAlign: "center", fontWeight: 700, fontSize: 14, color: C.text, marginBottom: 20 }}>
        Which one gets a reply?
      </div>

      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, color: theme.primary, textTransform: "uppercase", marginBottom: 4 }}>
          Review outreach
        </div>
        <div style={{ fontSize: 24, fontWeight: 800, color: C.text, letterSpacing: -0.8 }}>
          {fname}'s personalised messages
        </div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>
          Edit either message before approving. Clicking Send saves both to Google Sheets for delivery.
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 24 }}>
        {/* SMS — iMessage style */}
        <div>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            marginBottom: 10,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase" }}>SMS</div>
            <button onClick={() => setEditMode(editMode === "sms" ? null : "sms")} style={{
              background: "transparent", border: "none", cursor: "pointer",
              color: theme.primary, fontSize: 12, fontFamily: FONT, fontWeight: 600,
            }}>
              {editMode === "sms" ? "Done" : "Edit"}
            </button>
          </div>
          {editMode === "sms" ? (
            <textarea
              autoFocus
              value={sms}
              onChange={e => setSMS(e.target.value)}
              maxLength={160}
              style={{
                width: "100%", minHeight: 120, background: C.bg3,
                border: `1px solid ${theme.primary}44`, borderRadius: 12,
                padding: "12px 14px", color: C.text, fontSize: 13,
                fontFamily: FONT, lineHeight: 1.5, resize: "vertical", outline: "none",
                boxSizing: "border-box",
              }}
            />
          ) : (
            <div
              style={{ background: "rgb(24,24,24)", borderRadius: 20, padding: 16, userSelect: "none" }}
              onCopy={e => { e.preventDefault(); handleCopy("sms") }}
            >
              <div style={{ textAlign: "center", marginBottom: 12 }}>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>iMessage</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.9)" }}>{fname}</div>
              </div>
              <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                <div style={{
                  maxWidth: "80%", padding: "9px 13px",
                  borderRadius: "16px 16px 4px 16px",
                  background: bubbleColor,
                  fontSize: 13, color: "white", lineHeight: 1.45,
                }}>
                  {sms}
                </div>
                <div style={{
                  width: 30, height: 30, borderRadius: "50%",
                  background: avatarGrad,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 11, fontWeight: 700, color: "white", flexShrink: 0, alignSelf: "flex-end",
                }}>
                  {agent.name.charAt(0)}
                </div>
              </div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", textAlign: "right", marginTop: 6 }}>
                {sms.length}/160 chars
              </div>
            </div>
          )}
        </div>

        {/* Email — Gmail style */}
        <div>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            marginBottom: 10,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase" }}>Email</div>
            <button onClick={() => setEditMode(editMode === "email" ? null : "email")} style={{
              background: "transparent", border: "none", cursor: "pointer",
              color: theme.primary, fontSize: 12, fontFamily: FONT, fontWeight: 600,
            }}>
              {editMode === "email" ? "Done" : "Edit"}
            </button>
          </div>
          {editMode === "email" ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <input
                value={subject}
                onChange={e => setSubject(e.target.value)}
                placeholder="Subject line..."
                style={{
                  background: C.bg3, border: `1px solid ${theme.primary}44`,
                  borderRadius: 8, padding: "9px 12px", color: C.text,
                  fontSize: 13, fontFamily: FONT, outline: "none",
                }}
              />
              <textarea
                value={bodyText}
                onChange={e => setBodyText(e.target.value)}
                placeholder="Email body..."
                style={{
                  background: C.bg3, border: `1px solid ${theme.primary}44`,
                  borderRadius: 8, padding: "10px 12px", color: C.text,
                  fontSize: 13, fontFamily: FONT, lineHeight: 1.5,
                  resize: "vertical", minHeight: 160, outline: "none",
                }}
              />
            </div>
          ) : (
            <div
              style={{
                background: "white", borderRadius: 12, overflow: "hidden",
                boxShadow: "0 4px 24px rgba(0,0,0,0.3)", userSelect: "none",
              }}
              onCopy={e => { e.preventDefault(); handleCopy("email") }}
            >
              <div style={{ background: "#f1f3f4", padding: "10px 16px", borderBottom: "1px solid #e0e0e0" }}>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 2 }}>
                  <span style={{ fontWeight: 500, color: "#333" }}>From: </span>{agent.email}
                </div>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 2 }}>
                  <span style={{ fontWeight: 500, color: "#333" }}>To: </span>{lead.email ?? `${fname.toLowerCase()}@email.com`}
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#111", marginTop: 4 }}>{subject}</div>
              </div>
              <div style={{ padding: "16px 20px" }}>
                {bodyText.split("\n\n").filter(p => p.trim()).map((p, i, arr) => (
                  <p key={i} style={{ fontSize: 13, color: "#333", lineHeight: 1.6, marginBottom: i < arr.length - 1 ? 12 : 0 }}>{p}</p>
                ))}
                <div style={{
                  marginTop: 20, paddingTop: 16, borderTop: `2px solid ${theme.primary}`,
                  fontSize: 12, color: "#666",
                  display: "flex", gap: 10, alignItems: "center",
                }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                    background: avatarGrad,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 800, color: "white",
                  }}>
                    {theme.logo}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: "#111", fontSize: 13 }}>{agent.name}</div>
                    <div style={{ color: theme.primary, fontWeight: 600 }}>{agent.agency}</div>
                    <div style={{ color: "#888", fontSize: 11 }}>{agent.email}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Test mode banner */}
      {testMode && (
        <div style={{
          display: "flex", alignItems: "center", gap: 10, marginBottom: 12,
          padding: "10px 16px", borderRadius: 10,
          background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)",
        }}>
          <div style={{ fontSize: 14 }}>⚠️</div>
          <div style={{ fontSize: 12, color: "#f59e0b", lineHeight: 1.4 }}>
            <span style={{ fontWeight: 700 }}>Test mode active.</span> Messages will go to{" "}
            {testMode.phone && <span style={{ fontFamily: "monospace" }}>{testMode.phone}</span>}
            {testMode.phone && testMode.email && " / "}
            {testMode.email && <span style={{ fontFamily: "monospace" }}>{testMode.email}</span>}
            {" "}instead of {lead.name}
          </div>
        </div>
      )}

      {/* Send button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.97 }}
        onClick={handleSend}
        disabled={sending}
        style={{
          width: "100%", padding: "15px",
          borderRadius: 14, border: "none",
          background: sending
            ? C.bg3
            : `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
          color: sending ? C.muted : "white",
          fontSize: 16, fontWeight: 700, cursor: sending ? "default" : "pointer",
          fontFamily: FONT, letterSpacing: -0.3,
          boxShadow: sending ? "none" : `0 6px 24px ${theme.glow}`,
        }}
      >
        {sending ? "Saving to Sheet..." : "Approve and Send"}
      </motion.button>
      <div style={{ textAlign: "center", fontSize: 11, color: C.faint, marginTop: 10 }}>
        This saves the approved SMS and email to Google Sheets for delivery via Twilio and Gmail.
      </div>

      <button
        onClick={handleSendToSelf}
        disabled={sendingToSelf || sentToSelf}
        style={{
          width: "100%", padding: "13px",
          borderRadius: 14, marginTop: 12,
          background: "transparent",
          border: `1px solid ${theme.primary}55`,
          color: sentToSelf ? C.green : theme.primary,
          fontSize: 14, fontWeight: 600, cursor: sendingToSelf || sentToSelf ? "default" : "pointer",
          fontFamily: FONT, letterSpacing: -0.2,
        }}
      >
        {sentToSelf ? "✓ Sent to your phone, check it now" : sendingToSelf ? "Sending..." : "📱 Send to my phone"}
      </button>
      <div style={{ textAlign: "center", fontSize: 11, color: C.faint, marginTop: 6 }}>
        Experience what your leads feel
      </div>
    </div>
  )
}

// ── Stage: Missed Out Flow ────────────────────────────────────────────────────

function MissedOutPage({ auctionProperty, leads, onBack, theme, onSelectLead }: {
  auctionProperty: PortfolioProperty
  leads: SheetLead[]
  onBack: () => void
  theme: AgencyTheme
  onSelectLead: (lead: ScoredLead, property: PortfolioProperty) => void
}) {
  // Re-match each missed-out lead against all OTHER active listings
  const otherActives = PORTFOLIO_ACTIVE
  const soldSLM = loadSLMForProperty(auctionProperty.id)

  const rematched = leads.map(lead => {
    const bedsWanted   = inferBedsWanted(lead)
    const enrichedNotes = enrichLeadNotes(lead.id, lead.notes)
    const matches = otherActives
      .map(p => ({
        property: p,
        slm: loadSLMForProperty(p.id),
        result: matchLeadToListing(
          { budget: lead.budget, bedsWanted, persona: lead.persona, suburbs: inferSuburbs(lead), notes: enrichedNotes, questions: lead.questions },
          loadSLMForProperty(p.id),
          soldSLM,
        ),
      }))
      .sort((a, b) => b.result.score - a.result.score)
    const best = matches[0]
    return { lead, bestProperty: best?.property, bestResult: best?.result, bedsWanted }
  }).filter(r => r.bestResult && r.bestResult.score > 30)

  if (!rematched.length) {
    return (
      <div style={{ maxWidth: 680, margin: "0 auto", padding: "80px 28px", fontFamily: FONT, textAlign: "center" }}>
        <button onClick={onBack} style={{ background: "none", border: "none", color: theme.primary, fontSize: 18, cursor: "pointer", marginBottom: 24 }}>←</button>
        <div style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 12 }}>No strong re-matches found</div>
        <div style={{ fontSize: 13, color: C.muted }}>Add more active listings or complete their SLM data to improve matching.</div>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: "80px 28px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{ background: "transparent", border: "none", cursor: "pointer", color: theme.primary, fontSize: 18, marginBottom: 20, padding: 0 }}>←</button>

      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.orange, textTransform: "uppercase", marginBottom: 6 }}>
          Post-Auction Missed Out
        </div>
        <div style={{ fontSize: 24, fontWeight: 800, color: C.text, letterSpacing: -0.6, marginBottom: 6 }}>
          Re-match {rematched.length} lead{rematched.length !== 1 ? "s" : ""} who missed out
        </div>
        <div style={{ fontSize: 13, color: C.muted }}>
          These leads registered to bid on {auctionProperty.address} but didn't win. They're warm. Reach out now.
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {rematched.map(({ lead, bestProperty, bestResult, bedsWanted }) => {
          if (!bestProperty || !bestResult) return null
          const scoredLead: ScoredLead = {
            ...lead,
            matchResult: bestResult,
            fromPropertyId: auctionProperty.id,
            bedsWanted,
          }
          return (
            <motion.div
              key={lead.id || lead.name}
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              style={{
                background: C.bg2, border: `1px solid ${C.border}`, borderRadius: 14,
                padding: "20px 22px", display: "flex", alignItems: "center", gap: 16,
              }}
            >
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: C.text, marginBottom: 4 }}>{lead.name}</div>
                <div style={{ fontSize: 12, color: C.muted, marginBottom: 8 }}>{lead.persona} · {fmt(lead.budget)} budget</div>
                <div style={{ fontSize: 12, color: theme.primary }}>
                  Best match: {bestProperty.address} · {Math.round(bestResult.score)}/99
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <div style={{ fontSize: 28, fontWeight: 800, color: scoreColor(bestResult.score) }}>
                  {Math.round(bestResult.score)}
                </div>
                <button
                  onClick={() => onSelectLead(scoredLead, bestProperty)}
                  style={{
                    padding: "8px 18px", borderRadius: 10, border: "none", cursor: "pointer",
                    background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
                    color: "white", fontSize: 12, fontWeight: 700, fontFamily: FONT,
                  }}
                >
                  Generate outreach
                </button>
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

// ── Vendor Prospecting: Portfolio (CRM Dashboard) ────────────────────────────

interface AddContactForm {
  name: string; phone: string; email: string; purchaseAddress: string
  suburb: string; purchaseDate: string; purchasePrice: string
  deposit: string; propertyType: string; beds: string; baths: string
  land: string; status: string; notes: string
}

const BUYER_STATUS_LABELS: Record<string, string> = {
  "investor":        "Investor",
  "owner-occupier":  "Owner-occupier",
  "buyer→landlord":  "Buyer → Landlord",
  "buyer→seller":    "Buyer → Seller",
  "renter→buyer":    "Renter → Buyer",
  "buyer→downsizer": "Buyer → Downsizer",
}
function formatBuyerStatus(status: string): string {
  return BUYER_STATUS_LABELS[status] ?? status
}

const EMPTY_FORM: AddContactForm = {
  name: "", phone: "", email: "", purchaseAddress: "",
  suburb: "", purchaseDate: "", purchasePrice: "",
  deposit: "", propertyType: "House", beds: "4", baths: "2",
  land: "", status: "owner-occupier", notes: "",
}

function VendorPortfolioPage({ agent, theme, onAnalyse }: {
  agent: AgentProfile
  theme: AgencyTheme
  onAnalyse: (segmented: SegmentedBuyer[]) => void
}) {
  const hardcodedBuyers = getPastBuyersForAgent(agent)
  const [buyers, setBuyers] = useState(hardcodedBuyers)
  const [sheetLoading, setSheetLoading] = useState(false)
  const [sheetSource, setSheetSource] = useState<"demo" | "sheet">("demo")
  const [analysing, setAnalysing] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEstimator, setShowEstimator] = useState(false)
  const [addForm, setAddForm] = useState<AddContactForm>(EMPTY_FORM)
  const [addSaving, setAddSaving] = useState(false)
  const [addSaved, setAddSaved] = useState(false)

  // Try loading real past buyers from the Google Sheet on mount
  useEffect(() => {
    setSheetLoading(true)
    readPastBuyersFromSheet().then(rows => {
      if (rows && rows.length > 0) {
        // Overlay hardcoded personalisationHooks by name (for contacts present in both hardcoded + sheet)
        const hookByName = new Map(
          hardcodedBuyers
            .filter(b => b.personalisationHook)
            .map(b => [b.name.toLowerCase().trim(), b.personalisationHook!])
        )
        let merged = (rows as typeof hardcodedBuyers).map(r => ({
          ...r,
          personalisationHook: r.personalisationHook ?? hookByName.get(r.name.toLowerCase().trim()),
        }))
        // Demo injection: if no contacts have a hook yet, seed the top 2 contacts with sample
        // hooks so the feature is always visible in the demo — agents see what to put in col R
        const hasAnyHook = merged.some(r => r.personalisationHook)
        if (!hasAnyHook && merged.length > 0) {
          merged = [...merged]
          const demoHooks = [
            (name: string) => `${name}, your hold period and equity position are exceptional right now. The CGT clock is ticking and this is the perfect window to talk.`,
            (name: string) => `${name}, with settlement behind you and the market moving, now is exactly when smart investors lock in their gains.`,
          ]
          for (let di = 0; di < Math.min(2, merged.length); di++) {
            const b = merged[di]
            const fname = b.name.split("&")[0].split(" ")[0].trim()
            merged[di] = { ...b, personalisationHook: demoHooks[di](fname) }
          }
        }
        setBuyers(merged)
        setSheetSource("sheet")
      }
      setSheetLoading(false)
    }).catch(() => setSheetLoading(false))
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const investors = buyers.filter(b => b.status === "investor")
  const owners = buyers.filter(b => b.status !== "investor")

  // Merge hardcoded overrides with any agent-entered overrides from the sheet (col S)
  // Sheet values take precedence: agent knows their market better than the auto-estimate
  const sheetEstimateOverrides: Record<number, number> = {}
  for (const b of buyers) {
    const override = (b as { currentEstimateOverride?: number }).currentEstimateOverride
    if (override && override > 0) sheetEstimateOverrides[b.id] = override
  }
  const estimatedValues = batchEstimateValues(buyers, { ...CURRENT_VALUE_ESTIMATES, ...sheetEstimateOverrides })
  const totalEstValue = buyers.reduce((s, b) => s + (estimatedValues.get(b.id) ?? 0), 0)

  const handleAnalyse = () => {
    setAnalysing(true)
    const financialsMap = new Map<number, FinancialSnapshot>()
    for (const b of buyers) {
      const est = estimatedValues.get(b.id)
      if (!est) continue
      financialsMap.set(b.id, calculateFinancials(b.purchasePrice, b.purchaseDate, est, b.deposit))
    }
    const segmented = batchSegment(buyers, financialsMap)
    setTimeout(() => onAnalyse(segmented), 1200)
  }

  const handleAddContact = async () => {
    if (!addForm.name || !addForm.purchaseAddress || !addForm.purchaseDate || !addForm.purchasePrice) return
    setAddSaving(true)
    const newContact = {
      id: Date.now(),
      name: addForm.name,
      phone: addForm.phone,
      email: addForm.email,
      purchaseAddress: addForm.purchaseAddress,
      suburb: addForm.suburb,
      purchaseDate: addForm.purchaseDate,
      purchasePrice: parseInt(addForm.purchasePrice.replace(/\D/g, ""), 10) || 0,
      deposit: parseInt(addForm.deposit.replace(/\D/g, ""), 10) || 0,
      propertyType: addForm.propertyType as "House" | "Unit" | "Townhouse",
      beds: parseInt(addForm.beds, 10) || 3,
      baths: parseInt(addForm.baths, 10) || 2,
      land: addForm.land ? parseInt(addForm.land.replace(/\D/g, ""), 10) || 0 : 0,
      status: addForm.status as import("../data/pastBuyers").BuyerStatus,
      notes: addForm.notes,
      lastContactDate: "",
    }
    // Try to save to sheet via /api/add-contact
    try {
      await fetch(apiUrl("/api/add-contact"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newContact),
      })
    } catch { /* server may not have route yet — add locally anyway */ }
    setBuyers(prev => [...prev, newContact])
    setAddSaved(true)
    setAddSaving(false)
    setTimeout(() => { setShowAddModal(false); setAddForm(EMPTY_FORM); setAddSaved(false) }, 1200)
  }

  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "88px 28px 48px", fontFamily: FONT }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: theme.primary, textTransform: "uppercase", marginBottom: 8 }}>
          Vendor Prospecting
        </div>
        <div style={{ fontSize: 26, fontWeight: 800, color: C.text, letterSpacing: -0.6, marginBottom: 8 }}>
          Turn past buyers into new listings
        </div>
        <div style={{ fontSize: 13, color: C.muted, maxWidth: 560, marginBottom: 14 }}>
          PropOS analyses your CRM database to find past buyers who are ready to sell. We calculate their equity, CGT position, and life-stage triggers, then generate hyper-personalised outreach in your voice.
        </div>
        <button
          onClick={() => setShowEstimator(true)}
          style={{
            padding: "8px 18px", borderRadius: 10, border: `1px solid ${theme.primary}40`,
            background: `${theme.primary}10`, color: theme.primary,
            fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
            display: "inline-flex", alignItems: "center", gap: 6,
          }}
        >
          🏠 Property Value Estimator
        </button>
      </div>

      {/* Property estimator modal */}
      <AnimatePresence>
        {showEstimator && <PropertyEstimatorModal theme={theme} onClose={() => setShowEstimator(false)} />}
      </AnimatePresence>

      {/* CRM Summary Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 28 }}>
        {[
          { label: "Total contacts", value: `${buyers.length}`, icon: "👥" },
          { label: "Potential vendors", value: `${owners.length}`, icon: "🏠" },
          { label: "Investors", value: `${investors.length}`, icon: "💰" },
          { label: "Est. portfolio value", value: fmtDollar(totalEstValue), icon: "📊" },
        ].map(stat => (
          <div key={stat.label} style={{
            background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`,
            padding: "16px 18px", textAlign: "center",
          }}>
            <div style={{ fontSize: 20, marginBottom: 6 }}>{stat.icon}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: C.text, marginBottom: 2 }}>{stat.value}</div>
            <div style={{ fontSize: 10, color: C.faint, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8 }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Sheet setup guide — shown when falling back to demo data */}
      {sheetSource === "demo" && !sheetLoading && (
        <div style={{
          marginBottom: 20, background: C.bg2, borderRadius: 12,
          border: `1px solid rgba(166,218,255,0.15)`, padding: "14px 18px",
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.blue, marginBottom: 6 }}>
            Connect your Google Sheet CRM to load live contacts
          </div>
          <div style={{ fontSize: 11, color: C.muted, lineHeight: 1.6, marginBottom: 8 }}>
            Create a tab called <strong style={{ color: C.text }}>Past Buyers</strong> in your connected Sheet with these columns:
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {["id", "name", "phone", "email", "purchaseAddress", "suburb", "purchaseDate", "purchasePrice", "deposit", "propertyType", "beds", "baths", "land", "status", "notes", "lastContactDate"].map(col => (
              <span key={col} style={{
                fontSize: 10, fontFamily: "monospace", padding: "2px 7px",
                background: C.bg3, border: `1px solid ${C.border}`,
                borderRadius: 5, color: C.muted,
              }}>{col}</span>
            ))}
          </div>
        </div>
      )}

      {/* Recent contacts preview */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>Your CRM database</div>
          {sheetLoading && <div style={{ fontSize: 10, color: C.faint }}>Loading from sheet...</div>}
          {sheetSource === "sheet" && !sheetLoading && (
            <div style={{ fontSize: 10, color: C.green, fontWeight: 600, padding: "2px 8px", background: C.green + "18", borderRadius: 6 }}>Live from sheet</div>
          )}
          {sheetSource === "demo" && !sheetLoading && (
            <div style={{ fontSize: 10, color: C.faint, padding: "2px 8px", background: C.bg3, borderRadius: 6 }}>Demo data</div>
          )}
          <button onClick={() => setShowAddModal(true)} style={{
            marginLeft: "auto", padding: "5px 12px", borderRadius: 8,
            background: theme.dim, border: `1px solid ${theme.primary}55`,
            color: theme.primary, fontSize: 11, fontWeight: 700,
            cursor: "pointer", fontFamily: FONT,
          }}>
            + Add contact
          </button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {buyers.slice(0, 5).map(buyer => {
            const est = estimatedValues.get(buyer.id) ?? 0
            const equity = est - buyer.purchasePrice
            return (
              <div key={buyer.id} style={{
                background: C.bg2, borderRadius: 12, border: `1px solid ${C.border}`,
                padding: "12px 16px", display: "flex", alignItems: "center", gap: 14,
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                  background: `linear-gradient(135deg, ${theme.gradient[0]}33, ${theme.gradient[1]}22)`,
                  border: `1px solid ${theme.primary}33`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 13, fontWeight: 700, color: theme.primary,
                }}>
                  {buyer.name.charAt(0)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{buyer.name}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{buyer.purchaseAddress}</div>
                </div>
                <div style={{ flexShrink: 0, textAlign: "right" }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: C.green }}>{fmtDollar(equity)} equity</div>
                  <div style={{ fontSize: 10, color: C.faint }}>
                    {formatBuyerStatus(buyer.status)}
                  </div>
                </div>
              </div>
            )
          })}
          {buyers.length > 5 && (
            <div style={{ fontSize: 11, color: C.faint, textAlign: "center", padding: "8px 0" }}>
              + {buyers.length - 5} more contacts
            </div>
          )}
        </div>
      </div>

      {/* Analyse button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleAnalyse}
        disabled={analysing}
        style={{
          width: "100%", padding: "18px",
          borderRadius: 14, border: "none",
          background: analysing ? C.bg3 : `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
          color: analysing ? C.muted : "white",
          fontSize: 16, fontWeight: 700, cursor: analysing ? "default" : "pointer",
          fontFamily: FONT, letterSpacing: -0.3,
          boxShadow: analysing ? "none" : `0 4px 24px ${theme.glow}`,
          marginBottom: 12,
        }}
      >
        {analysing ? "Analysing your database..." : sheetLoading ? "Loading CRM..." : `✦ Analyse ${buyers.length} contacts for vendor opportunities`}
      </motion.button>

      {/* Pitch callout */}
      <div style={{
        marginTop: 20, background: C.bg2, borderRadius: 14,
        border: `1px solid ${theme.primary}22`, padding: "18px 22px",
        display: "flex", alignItems: "flex-start", gap: 14,
      }}>
        <div style={{ fontSize: 22 }}>💡</div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginBottom: 4 }}>How it works</div>
          <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.6 }}>
            PropOS scans your past buyers and segments them into actionable pipelines: investors ready to take profit, families outgrowing their home, empty-nesters ready to downsize. Each contact gets a financial snapshot (equity gain, CGT savings, cash-on-cash return) and personalised outreach in your voice.
          </div>
        </div>
      </div>

      {/* Add Contact modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            style={{
              position: "fixed", inset: 0, zIndex: 200,
              background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)",
              display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
            }}
            onClick={() => setShowAddModal(false)}
          >
            <motion.div
              initial={{ scale: 0.93, y: 16 }} animate={{ scale: 1, y: 0 }}
              onClick={e => e.stopPropagation()}
              style={{
                background: C.bg2, borderRadius: 18, border: `1px solid ${C.border}`,
                padding: "28px 28px", maxWidth: 600, width: "100%",
                maxHeight: "85vh", overflowY: "auto",
              }}
            >
              <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 4 }}>Add contact</div>
              <div style={{ fontSize: 12, color: C.muted, marginBottom: 24 }}>
                Add a past buyer to your CRM database and Google Sheet.
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {([
                  ["Name", "name", "text", "Full name"],
                  ["Phone", "phone", "tel", "+61 4xx xxx xxx"],
                  ["Email", "email", "email", "email@domain.com"],
                  ["Purchase address", "purchaseAddress", "text", "12 Smith St"],
                  ["Suburb", "suburb", "text", "Berwick"],
                  ["Purchase date", "purchaseDate", "date", ""],
                  ["Purchase price", "purchasePrice", "text", "850000"],
                  ["Deposit paid", "deposit", "text", "85000"],
                  ["Beds", "beds", "number", "4"],
                  ["Baths", "baths", "number", "2"],
                  ["Land (sqm)", "land", "text", "612"],
                ] as [string, keyof AddContactForm, string, string][]).map(([label, field, type, placeholder]) => (
                  <div key={field} style={{ gridColumn: ["name", "purchaseAddress", "notes"].includes(field) ? "1 / -1" : undefined }}>
                    <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>{label}</label>
                    <input
                      type={type}
                      value={addForm[field]}
                      onChange={e => setAddForm(f => ({ ...f, [field]: e.target.value }))}
                      placeholder={placeholder}
                      style={{
                        width: "100%", background: C.bg3, border: `1px solid ${C.border}`,
                        borderRadius: 8, padding: "8px 10px", color: C.text,
                        fontSize: 13, fontFamily: FONT, outline: "none", boxSizing: "border-box",
                      }}
                    />
                  </div>
                ))}
                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>Property type</label>
                  <select value={addForm.propertyType} onChange={e => setAddForm(f => ({ ...f, propertyType: e.target.value }))}
                    style={{ width: "100%", background: C.bg3, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 10px", color: C.text, fontSize: 13, fontFamily: FONT, outline: "none" }}>
                    <option>House</option><option>Unit</option><option>Townhouse</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>Status</label>
                  <select value={addForm.status} onChange={e => setAddForm(f => ({ ...f, status: e.target.value }))}
                    style={{ width: "100%", background: C.bg3, border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 10px", color: C.text, fontSize: 13, fontFamily: FONT, outline: "none" }}>
                    <option value="owner-occupier">Owner-occupier</option>
                    <option value="investor">Investor</option>
                    <option value="buyer→landlord">Buyer → Landlord</option>
                    <option value="buyer→seller">Buyer → Seller</option>
                    <option value="renter→buyer">Renter → Buyer</option>
                    <option value="buyer→downsizer">Buyer → Downsizer</option>
                  </select>
                </div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>Notes</label>
                  <textarea
                    value={addForm.notes}
                    onChange={e => setAddForm(f => ({ ...f, notes: e.target.value }))}
                    placeholder="Family growing, interested in schools, investment strategy..."
                    style={{
                      width: "100%", background: C.bg3, border: `1px solid ${C.border}`,
                      borderRadius: 8, padding: "8px 10px", color: C.text,
                      fontSize: 13, fontFamily: FONT, outline: "none", minHeight: 64,
                      resize: "vertical", boxSizing: "border-box",
                    }}
                  />
                </div>
              </div>
              <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                <button onClick={() => setShowAddModal(false)} style={{
                  flex: 1, padding: "12px", borderRadius: 10, border: `1px solid ${C.border}`,
                  background: "transparent", color: C.muted, fontSize: 14, fontWeight: 600,
                  cursor: "pointer", fontFamily: FONT,
                }}>Cancel</button>
                <button onClick={handleAddContact} disabled={addSaving || addSaved} style={{
                  flex: 2, padding: "12px", borderRadius: 10, border: "none",
                  background: addSaved ? C.green : `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
                  color: "white", fontSize: 14, fontWeight: 700,
                  cursor: addSaving || addSaved ? "default" : "pointer", fontFamily: FONT,
                }}>
                  {addSaved ? "Contact added" : addSaving ? "Saving..." : "Add contact"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── Vendor Prospecting: Pipeline Dashboard ──────────────────────────────────

function VendorDashboardPage({ segmented, onBack, onSelectEntry, theme, agent }: {
  segmented: SegmentedBuyer[]
  onBack: () => void
  onSelectEntry: (entry: SegmentedBuyer) => void
  theme: AgencyTheme
  agent: AgentProfile
}) {
  const [filterPipeline, setFilterPipeline] = useState<Pipeline | "all">("all")
  const [showBulkFire, setShowBulkFire] = useState(false)
  const [showCGTUrgency, setShowCGTUrgency] = useState(false)
  const [showPreMarketMatcher, setShowPreMarketMatcher] = useState(false)
  const filtered = filterPipeline === "all" ? segmented : segmented.filter(s => s.segment.pipeline === filterPipeline)
  const pipelines = [...new Set(segmented.map(s => s.segment.pipeline))]
  const totalEquity = segmented.reduce((s, e) => s + e.financials.equityGain, 0)
  const hpCount = segmented.filter(s => (s.buyer as { personalisationHook?: string }).personalisationHook).length
  const urgencyColor = (u: "high" | "medium" | "low") =>
    u === "high" ? (C.red ?? "#ef4444") : u === "medium" ? C.orange : C.faint

  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "88px 28px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{ background: "transparent", border: "none", cursor: "pointer", color: theme.primary, fontSize: 18, marginBottom: 20, padding: 0 }}>←</button>

      {/* Header with summary */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: theme.primary, textTransform: "uppercase", marginBottom: 8 }}>
          Pipeline Dashboard
        </div>
        <div style={{ fontSize: 24, fontWeight: 800, color: C.text, letterSpacing: -0.5, marginBottom: 6 }}>
          {segmented.length} contacts segmented into {pipelines.length} pipelines
        </div>
        <div style={{ fontSize: 13, color: C.muted }}>
          Combined equity: <span style={{ color: C.green, fontWeight: 700 }}>{fmtDollar(totalEquity)}</span> across your database
        </div>

        {/* Portfolio Intelligence Score */}
        {(() => {
          const pctConf   = segmented.filter(e => e.segment.confidence >= 60).length / Math.max(segmented.length, 1)
          const pctCgt    = segmented.filter(e => e.financials.cgtSavingsBy2027 > 5000).length / Math.max(segmented.length, 1)
          const pctEquity = segmented.filter(e => e.financials.equityGainPct >= 30).length / Math.max(segmented.length, 1)
          const score     = Math.round(pctConf * 40 + pctCgt * 30 + pctEquity * 30)
          const sc        = score >= 70 ? C.green : score >= 50 ? C.orange : (C.red ?? "#ef4444")
          const optCount  = segmented.filter(e => e.segment.confidence >= 60).length
          const cgtCount  = segmented.filter(e => e.financials.cgtSavingsBy2027 > 5000).length
          const readyCount = segmented.filter(e => e.financials.equityGainPct >= 30 || e.segment.confidence >= 70).length
          return (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 12, padding: "14px 18px", borderRadius: 14, background: `linear-gradient(135deg, ${theme.gradient[0]}12, ${theme.gradient[1]}08)`, border: `1px solid ${theme.primary}30` }}>
              {/* Arc score */}
              <div style={{ textAlign: "center", flexShrink: 0 }}>
                <div style={{ fontSize: 32, fontWeight: 900, color: sc, letterSpacing: -1, lineHeight: 1 }}>{score}</div>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8 }}>Database score</div>
              </div>
              {/* Divider */}
              <div style={{ width: 1, height: 44, background: C.border }} />
              {/* Breakdown */}
              <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
                {[
                  { v: optCount, l: "in optimal window", c: C.green },
                  { v: cgtCount, l: "with CGT urgency", c: C.orange },
                  { v: readyCount, l: "ready to list", c: theme.primary },
                ].map(m => (
                  <div key={m.l} style={{ background: C.bg2, border: `1px solid ${m.c}30`, borderRadius: 10, padding: "6px 12px", textAlign: "center" }}>
                    <div style={{ fontSize: 18, fontWeight: 900, color: m.c }}>{m.v}</div>
                    <div style={{ fontSize: 9, color: C.faint }}>{m.l}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          )
        })()}
        {hpCount > 0 && (
          <motion.div
            initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            style={{ display: "inline-flex", alignItems: "center", gap: 7, marginTop: 8,
              background: `linear-gradient(90deg, ${theme.primary}18, ${theme.primary}08)`,
              border: `1px solid ${theme.primary}35`, borderRadius: 10, padding: "5px 12px",
            }}
          >
            <span style={{ fontSize: 12 }}>⚡</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: theme.primary }}>{hpCount} contact{hpCount > 1 ? "s" : ""} hyper-personalised</span>
            <span style={{ fontSize: 10, color: C.faint }}>Your words go straight in, no AI needed</span>
          </motion.div>
        )}

        {/* Action buttons row */}
        <div style={{ marginTop: 16, display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} onClick={() => setShowBulkFire(true)}
            style={{ padding: "10px 20px", borderRadius: 12, border: "none", cursor: "pointer", background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, color: "white", fontSize: 13, fontWeight: 700, fontFamily: FONT, boxShadow: `0 4px 16px ${theme.glow}`, display: "inline-flex", alignItems: "center", gap: 8 }}>
            🚀 Fire all {segmented.length} contacts at once
          </motion.button>
          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} onClick={() => setShowCGTUrgency(true)}
            style={{ padding: "10px 18px", borderRadius: 12, border: `1px solid ${C.orange}50`, cursor: "pointer", background: `${C.orange}12`, color: C.orange, fontSize: 12, fontWeight: 700, fontFamily: FONT, display: "inline-flex", alignItems: "center", gap: 6 }}>
            ⏰ CGT Urgency
          </motion.button>
          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} onClick={() => setShowPreMarketMatcher(true)}
            style={{ padding: "10px 18px", borderRadius: 12, border: `1px solid ${theme.primary}40`, cursor: "pointer", background: `${theme.primary}10`, color: theme.primary, fontSize: 12, fontWeight: 700, fontFamily: FONT, display: "inline-flex", alignItems: "center", gap: 6 }}>
            📡 Match Buyers
          </motion.button>
          <span style={{ fontSize: 10, color: C.faint }}>Demo mode: routes to test inbox</span>
        </div>
      </div>

      {/* AI Intelligence Suite */}
      <WowInsightsPanel segmented={segmented} theme={theme} />

      {/* Bulk fire modal */}
      <AnimatePresence>
        {showBulkFire && <BulkFireModal segmented={segmented} agent={agent} theme={theme} onClose={() => setShowBulkFire(false)} />}
      </AnimatePresence>

      {/* CGT Urgency modal */}
      <AnimatePresence>
        {showCGTUrgency && <CGTUrgencyModal segmented={segmented} theme={theme} onClose={() => setShowCGTUrgency(false)} onSelectEntry={e => { setShowCGTUrgency(false); onSelectEntry(e) }} />}
      </AnimatePresence>

      {/* Pre-Market Matcher modal */}
      <AnimatePresence>
        {showPreMarketMatcher && <PreMarketMatcherModal segmented={segmented} agent={agent} theme={theme} onClose={() => setShowPreMarketMatcher(false)} onSelectEntry={e => { setShowPreMarketMatcher(false); onSelectEntry(e) }} />}
      </AnimatePresence>

      {/* Pipeline filter chips */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>
        <button onClick={() => setFilterPipeline("all")} style={{
          padding: "6px 14px", borderRadius: 20, border: `1px solid ${filterPipeline === "all" ? theme.primary : C.border}`,
          background: filterPipeline === "all" ? theme.primary : C.bg2,
          color: filterPipeline === "all" ? "#fff" : C.muted,
          fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
        }}>
          All ({segmented.length})
        </button>
        {pipelines.map(p => {
          const pl = PIPELINE_LABELS[p]
          const count = segmented.filter(s => s.segment.pipeline === p).length
          return (
            <button key={p} onClick={() => setFilterPipeline(p)} style={{
              padding: "6px 14px", borderRadius: 20, border: `1px solid ${filterPipeline === p ? pl.color : C.border}`,
              background: filterPipeline === p ? pl.color + "22" : C.bg2,
              color: filterPipeline === p ? pl.color : C.muted,
              fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
            }}>
              {pl.icon} {pl.shortLabel} ({count})
            </button>
          )
        })}
      </div>

      {/* Contact cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.map((entry, i) => {
          const { buyer, financials: fin, segment } = entry
          const pl = PIPELINE_LABELS[segment.pipeline]
          const fname = buyer.name.split(" ")[0]
          const topTrigger = segment.triggers[0]
          return (
            <motion.div
              key={buyer.id}
              initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              onClick={() => onSelectEntry(entry)}
              style={{
                background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`,
                padding: "16px 20px", cursor: "pointer", display: "flex", gap: 14, alignItems: "center",
                transition: "border 0.15s, box-shadow 0.15s",
              }}
              onMouseEnter={e => {
                const el = e.currentTarget as HTMLDivElement
                el.style.borderColor = pl.color + "55"
                el.style.boxShadow = `0 0 20px ${pl.color}15`
              }}
              onMouseLeave={e => {
                const el = e.currentTarget as HTMLDivElement
                el.style.borderColor = C.border; el.style.boxShadow = "none"
              }}
            >
              {/* Avatar */}
              <div style={{
                width: 40, height: 40, borderRadius: 12, flexShrink: 0,
                background: pl.color + "18", border: `1px solid ${pl.color}33`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 14, fontWeight: 700, color: pl.color,
              }}>
                {fname.charAt(0)}
              </div>

              {/* Info */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3, flexWrap: "wrap" }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{buyer.name}</div>
                  <div style={{
                    fontSize: 10, padding: "2px 8px", borderRadius: 6,
                    background: pl.color + "18", color: pl.color, fontWeight: 700,
                  }}>
                    {pl.icon} {pl.shortLabel}
                  </div>
                  <div style={{ fontSize: 10, color: C.faint }}>{fin.yearsHeld}yr hold</div>
                  {(buyer as { personalisationHook?: string }).personalisationHook && (
                    <div style={{
                      fontSize: 9, padding: "2px 7px", borderRadius: 6, fontWeight: 800,
                      background: theme.primary + "20", color: theme.primary,
                      border: `1px solid ${theme.primary}35`,
                      display: "flex", alignItems: "center", gap: 3,
                      boxShadow: `0 0 8px ${theme.primary}18`,
                    }}>
                      ⚡ HP
                    </div>
                  )}
                </div>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>
                  {buyer.purchaseAddress}
                </div>
                {topTrigger && (
                  <div style={{
                    fontSize: 10, padding: "2px 8px", borderRadius: 5, display: "inline-block",
                    background: urgencyColor(topTrigger.urgency) + "15",
                    border: `1px solid ${urgencyColor(topTrigger.urgency)}30`,
                    color: urgencyColor(topTrigger.urgency), fontWeight: 600,
                  }}>
                    {topTrigger.label}
                  </div>
                )}
                {buyer.lastContactDate && (
                  <div style={{ fontSize: 9, color: C.faint, marginTop: 3 }}>
                    Last contacted: {buyer.lastContactDate}
                    {buyer.lastMessage && (
                      <span style={{ marginLeft: 6, color: C.faint, fontStyle: "italic" }}>
                        · "{buyer.lastMessage.slice(0, 60)}{buyer.lastMessage.length > 60 ? "…" : ""}"
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Financial summary */}
              <div style={{ flexShrink: 0, textAlign: "right" }}>
                <div style={{ fontSize: 15, fontWeight: 800, color: C.green }}>{fmtDollar(fin.equityGain)}</div>
                <div style={{ fontSize: 9, color: C.faint, marginBottom: 4 }}>equity gain</div>
                <div style={{ fontSize: 11, fontWeight: 700, color: C.text }}>{fmtDollar(fin.currentEstimate)}</div>
                <div style={{ fontSize: 9, color: C.faint }}>est. value</div>
              </div>

              {/* Priority score */}
              <div style={{
                width: 38, height: 38, borderRadius: 10, flexShrink: 0,
                background: scoreColor(entry.priority) + "18",
                border: `1px solid ${scoreColor(entry.priority)}33`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 13, fontWeight: 800, color: scoreColor(entry.priority),
              }}>
                {entry.priority}
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

// ── Vendor Prospecting: Contact Profile + Financial Snapshot ─────────────────

// ── Hyper-Personalisation Card ────────────────────────────────────────────────

/**
 * NotesBridgeCard — shows the full AI personalisation transformation:
 *   Stage 1: Raw CRM notes (what the agent typed)
 *   Stage 2: "AI reading between the lines..." bridge (while generating)
 *   Stage 3: What AI extracted — the single personalisation hook
 *   Stage 4: "As written to [name]" — the sentence from the actual email
 *
 * This is PropOS's WOW moment: showing that the AI didn't just quote the note,
 * it REFRAMED it into the contact's present situation.
 */
function NotesBridgeCard({ notes, prewrittenHook, extractedHook, personalisationLine, fname, generating, theme }: {
  notes: string
  prewrittenHook: string | null
  extractedHook: string | null
  personalisationLine: string | null
  fname: string
  generating: boolean
  theme: AgencyTheme
}) {
  // The "active" hook — pre-written takes precedence, otherwise show extracted
  const hook = prewrittenHook ?? extractedHook

  const [typedHook, setTypedHook] = useState("")
  const [hookDone, setHookDone] = useState(false)
  const [typedLine, setTypedLine] = useState("")
  const [lineDone, setLineDone] = useState(false)

  // Typewriter for hook
  useEffect(() => {
    if (!hook) { setTypedHook(""); setHookDone(false); return }
    setTypedHook(""); setHookDone(false)
    let idx = 0
    const iv = setInterval(() => {
      idx++
      setTypedHook(hook.slice(0, idx))
      if (idx >= hook.length) { setHookDone(true); clearInterval(iv) }
    }, 18)
    return () => clearInterval(iv)
  }, [hook])

  // Typewriter for personalisationLine — delayed so it lands after hook finishes
  useEffect(() => {
    if (!personalisationLine) { setTypedLine(""); setLineDone(false); return }
    setTypedLine(""); setLineDone(false)
    const delay = setTimeout(() => {
      let idx = 0
      const iv = setInterval(() => {
        idx++
        setTypedLine(personalisationLine.slice(0, idx))
        if (idx >= personalisationLine.length) { setLineDone(true); clearInterval(iv) }
      }, 22)
      return () => clearInterval(iv)
    }, 600)
    return () => clearTimeout(delay)
  }, [personalisationLine])

  // Truncate notes to the most meaningful excerpt (first 160 chars)
  const notesExcerpt = notes.length > 160 ? notes.slice(0, 157) + "..." : notes

  const showBridge = !!hook || generating
  const showHook   = !!hook
  const showLine   = !!personalisationLine

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", damping: 20, stiffness: 260 }}
      style={{
        borderRadius: 16, overflow: "hidden", position: "relative",
        background: `linear-gradient(160deg, ${theme.primary}12 0%, ${theme.primary}06 50%, ${C.bg2} 100%)`,
        border: `1.5px solid ${theme.primary}44`,
        boxShadow: `0 0 28px ${theme.primary}14`,
      }}
    >
      {/* Top accent bar */}
      <div style={{ height: 3, background: `linear-gradient(90deg, ${theme.primary}, ${theme.gradient?.[1] ?? theme.primary}66, transparent 80%)` }} />

      {/* Shimmer */}
      <motion.div
        animate={{ x: ["-120%", "220%"] }}
        transition={{ duration: 2.6, ease: "linear", repeat: Infinity, repeatDelay: 2.4 }}
        style={{ position: "absolute", top: 0, left: 0, width: "30%", height: "100%", background: `linear-gradient(90deg, transparent, ${theme.primary}0e, transparent)`, pointerEvents: "none" }}
      />

      <div style={{ padding: "14px 18px", display: "flex", flexDirection: "column", gap: 0 }}>

        {/* ── Stage 1: CRM Notes ── */}
        <div style={{ marginBottom: 11 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 7 }}>
            <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1.6, color: C.faint, textTransform: "uppercase" }}>📋 From your CRM notes</span>
          </div>
          <div style={{
            fontSize: 12, color: C.muted, lineHeight: 1.55, fontStyle: "italic",
            padding: "9px 12px", borderRadius: 9,
            background: C.bg3, border: `1px solid ${C.border}`,
          }}>
            <span style={{ color: C.faint, fontWeight: 900, fontSize: 15, lineHeight: 0, verticalAlign: "-2px", marginRight: 2 }}>"</span>
            {notesExcerpt}
            <span style={{ color: C.faint, fontWeight: 900, fontSize: 15, lineHeight: 0, verticalAlign: "-2px", marginLeft: 2 }}>"</span>
          </div>
        </div>

        {/* ── Bridge: AI reading... ── */}
        {showBridge && (
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 11, paddingLeft: 4 }}>
            {/* Vertical connector line */}
            <div style={{ width: 2, height: 28, background: `linear-gradient(to bottom, ${C.border}, ${theme.primary}55)`, borderRadius: 2, flexShrink: 0 }} />
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              {generating ? (
                <>
                  <motion.div
                    animate={{ scale: [1, 1.5, 1], opacity: [0.7, 1, 0.7] }}
                    transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
                    style={{ width: 6, height: 6, borderRadius: "50%", background: theme.primary, flexShrink: 0 }}
                  />
                  <motion.span
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.4, repeat: Infinity }}
                    style={{ fontSize: 10, color: theme.primary, fontWeight: 700, letterSpacing: 0.3 }}
                  >
                    AI reading between the lines...
                  </motion.span>
                </>
              ) : (
                <>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.green, boxShadow: `0 0 6px ${C.green}` }} />
                  <span style={{ fontSize: 10, color: C.green, fontWeight: 700, letterSpacing: 0.3 }}>AI read the context</span>
                </>
              )}
            </div>
          </div>
        )}

        {/* ── Stage 2: What AI saw ── */}
        {showHook && (
          <div style={{ marginBottom: showLine ? 11 : 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 5,
                background: `linear-gradient(90deg, ${theme.primary}ee, ${theme.primary}aa)`,
                borderRadius: 7, padding: "3px 10px",
                boxShadow: `0 2px 8px ${theme.primary}33`,
              }}>
                <span style={{ fontSize: 9 }}>⚡</span>
                <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1.5, color: "#fff", textTransform: "uppercase" }}>
                  {prewrittenHook ? "Your insight" : "What AI saw"}
                </span>
              </div>
              {prewrittenHook && (
                <span style={{ fontSize: 9, color: C.faint }}>✍️ pre-written · col R of sheet</span>
              )}
            </div>
            <div style={{
              fontSize: 13, fontWeight: 600, color: C.text, lineHeight: 1.6,
              padding: "10px 13px", borderRadius: 9,
              background: theme.primary + "0d",
              border: `1px solid ${theme.primary}2a`,
              minHeight: 38, fontStyle: "italic",
            }}>
              <span style={{ color: theme.primary, fontWeight: 900, fontSize: 16, opacity: 0.5, lineHeight: 0, verticalAlign: "-2px" }}>"</span>
              {typedHook}
              {!hookDone ? (
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
                  style={{ display: "inline-block", width: 2, height: 12, marginLeft: 1, background: theme.primary, verticalAlign: "middle", borderRadius: 1 }}
                />
              ) : (
                <span style={{ color: theme.primary, fontWeight: 900, fontSize: 16, opacity: 0.5, lineHeight: 0, verticalAlign: "-2px" }}>"</span>
              )}
            </div>
          </div>
        )}

        {/* ── Stage 3: As written in the outreach ── */}
        {showLine && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            {/* Bridge to stage 3 */}
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10, paddingLeft: 4 }}>
              <div style={{ width: 2, height: 24, background: `linear-gradient(to bottom, ${theme.primary}44, ${C.green}88)`, borderRadius: 2, flexShrink: 0 }} />
              <span style={{ fontSize: 9, color: C.green, fontWeight: 700, letterSpacing: 0.3 }}>Woven into outreach as...</span>
            </div>
            <div style={{ marginBottom: 2 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 7 }}>
                <div style={{
                  display: "flex", alignItems: "center", gap: 5,
                  background: `linear-gradient(90deg, ${C.green}dd, ${C.green}99)`,
                  borderRadius: 7, padding: "3px 10px",
                }}>
                  <span style={{ fontSize: 9 }}>✉️</span>
                  <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 1.5, color: "#fff", textTransform: "uppercase" }}>
                    As written to {fname}
                  </span>
                </div>
              </div>
              <div style={{
                fontSize: 13, fontWeight: 500, color: C.text, lineHeight: 1.65,
                padding: "10px 13px", borderRadius: 9,
                background: C.green + "10",
                border: `1px solid ${C.green}28`,
                minHeight: 38, fontStyle: "italic",
              }}>
                <span style={{ color: C.green, fontWeight: 900, fontSize: 16, opacity: 0.5, lineHeight: 0, verticalAlign: "-2px" }}>"</span>
                {typedLine}
                {!lineDone ? (
                  <motion.span
                    animate={{ opacity: [1, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
                    style={{ display: "inline-block", width: 2, height: 12, marginLeft: 1, background: C.green, verticalAlign: "middle", borderRadius: 1 }}
                  />
                ) : (
                  <span style={{ color: C.green, fontWeight: 900, fontSize: 16, opacity: 0.5, lineHeight: 0, verticalAlign: "-2px" }}>"</span>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {/* Footer hint — only when we have no hook yet and not generating */}
        {!hook && !generating && (
          <div style={{ fontSize: 9.5, color: C.faint, marginTop: 6, fontStyle: "italic" }}>
            💡 Click Generate below to watch AI extract the personalisation hook from these notes
          </div>
        )}
      </div>
    </motion.div>
  )
}

// ── Vendor Appraisal Panel ────────────────────────────────────────────────────

function VendorAppraisalPanel({ buyer, theme }: {
  buyer: import("../data/pastBuyers").PastBuyer
  theme: AgencyTheme
}) {
  const comps: CompSale[] = generateComparables({
    suburb: buyer.suburb,
    propertyType: buyer.propertyType as "House" | "Unit" | "Townhouse",
    beds: buyer.beds,
    land: buyer.land ?? 500,
    buyerId: buyer.id,
  })

  const range: AppraisalRange = buildAppraisalRange(comps, buyer.suburb)

  const scenarios: EquityScenario[] = buildEquityScenarios({
    purchasePrice: buyer.purchasePrice,
    purchaseDate: buyer.purchaseDate,
    deposit: buyer.deposit ?? null,
    range,
  })

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

      {/* Section header */}
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted, textTransform: "uppercase" }}>
        Comparable Sales · {buyer.suburb}
      </div>

      {/* Comp cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        {comps.map((comp, i) => {
          const matchColor = comp.matchScore >= 85 ? C.green : comp.matchScore >= 70 ? theme.primary : C.muted
          return (
            <div key={i} style={{
              background: C.bg3, borderRadius: 12,
              border: `1px solid ${comp.matchScore >= 85 ? C.green + "33" : C.border}`,
              padding: "12px 13px",
              position: "relative",
            }}>
              {/* Match badge */}
              <div style={{
                position: "absolute", top: 8, right: 9,
                fontSize: 9, fontWeight: 800, color: matchColor,
                background: matchColor + "18", padding: "1px 6px", borderRadius: 4,
              }}>
                {comp.matchScore}% match
              </div>

              <div style={{ fontSize: 12, fontWeight: 700, color: C.text, marginBottom: 1, paddingRight: 50 }}>
                {comp.address}
              </div>
              <div style={{ fontSize: 10, color: C.faint, marginBottom: 8 }}>{comp.suburb}</div>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
                {[
                  { v: `${comp.beds}bd`, c: C.muted },
                  { v: `${comp.baths}ba`, c: C.muted },
                  comp.land > 0 ? { v: `${comp.land}m²`, c: C.muted } : null,
                ].filter(Boolean).map(chip => (
                  <span key={chip!.v} style={{
                    fontSize: 10, color: chip!.c,
                    background: C.bg2, border: `1px solid ${C.border}`,
                    padding: "2px 7px", borderRadius: 4,
                  }}>{chip!.v}</span>
                ))}
              </div>

              <div style={{ fontSize: 16, fontWeight: 800, color: C.text, letterSpacing: -0.3 }}>
                {fmtK(comp.soldPrice)}
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 3 }}>
                <span style={{ fontSize: 10, color: C.faint }}>Sold {comp.soldDate}</span>
                {comp.pricePerSqm > 0 && (
                  <span style={{ fontSize: 10, color: theme.primary, fontWeight: 600 }}>
                    ${comp.pricePerSqm.toLocaleString()}/m²
                  </span>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Appraisal range bar */}
      <div style={{ background: C.bg3, borderRadius: 14, border: `1px solid ${C.border}`, padding: "16px 18px" }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 }}>
          Estimated Value Range
        </div>

        {/* Bar */}
        <div style={{ position: "relative", height: 8, background: C.bg2, borderRadius: 4, marginBottom: 8, border: `1px solid ${C.border}` }}>
          {/* Filled range */}
          <div style={{
            position: "absolute",
            left: "8%", right: "8%", top: 0, bottom: 0,
            background: `linear-gradient(90deg, #64b5f6, ${C.green}, #ffa726)`,
            borderRadius: 4,
          }} />
          {/* Mid indicator */}
          <div style={{
            position: "absolute",
            left: "50%", top: -3, bottom: -3,
            width: 3, background: "white",
            borderRadius: 2, transform: "translateX(-50%)",
          }} />
        </div>

        {/* Labels */}
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, fontWeight: 700 }}>
          <span style={{ color: "#64b5f6" }}>{fmtK(range.low)}</span>
          <span style={{ color: C.green, fontSize: 14 }}>{fmtK(range.mid)} <span style={{ fontSize: 10, fontWeight: 400, color: C.faint }}>mid</span></span>
          <span style={{ color: "#ffa726" }}>{fmtK(range.high)}</span>
        </div>

        <div style={{ fontSize: 10, color: C.faint, marginTop: 8 }}>{range.methodNote}</div>

        {/* Market stats row */}
        <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
          {[
            { label: "Avg days on market", value: `${range.daysOnMarket} days` },
            { label: "Clearance rate", value: `${range.clearanceRate}%` },
            { label: "Buyer demand", value: `${range.demandScore}/10` },
            range.avgPricePerSqm > 0 ? { label: "Avg $/m²", value: `$${range.avgPricePerSqm.toLocaleString()}` } : null,
          ].filter(Boolean).map(stat => (
            <div key={stat!.label}>
              <div style={{ fontSize: 9, color: C.faint, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>{stat!.label}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginTop: 1 }}>{stat!.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Equity release scenarios */}
      <div>
        <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 }}>
          Equity Release Scenarios
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
          {scenarios.map(sc => (
            <div key={sc.label} style={{
              background: C.bg3, borderRadius: 12,
              border: `1px solid ${sc.color}33`,
              padding: "13px 14px",
            }}>
              <div style={{ fontSize: 9, fontWeight: 800, color: sc.color, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>
                {sc.label}
              </div>
              <div style={{ fontSize: 16, fontWeight: 800, color: sc.color, letterSpacing: -0.3, marginBottom: 2 }}>
                {fmtK(sc.salePrice)}
              </div>
              <div style={{ fontSize: 10, color: C.faint, marginBottom: 8 }}>est. sale price</div>

              <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 8, display: "flex", flexDirection: "column", gap: 4 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11 }}>
                  <span style={{ color: C.faint }}>Selling costs</span>
                  <span style={{ color: C.muted }}>-{fmtK(sc.sellingCosts)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11 }}>
                  <span style={{ color: C.faint }}>Est. CGT</span>
                  <span style={{ color: C.muted }}>-{fmtK(sc.estimatedCGT)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, fontWeight: 700, borderTop: `1px solid ${C.border}`, paddingTop: 5, marginTop: 2 }}>
                  <span style={{ color: C.faint }}>Net proceeds</span>
                  <span style={{ color: C.green }}>{fmtK(sc.netProceeds)}</span>
                </div>
              </div>

              <div style={{
                marginTop: 8, fontSize: 11, fontWeight: 700,
                color: sc.equityReleased >= 0 ? C.green : "#ef4444",
                textAlign: "center",
                background: sc.equityReleased >= 0 ? C.green + "12" : "#ef444412",
                borderRadius: 6, padding: "4px 0",
              }}>
                {sc.equityReleased >= 0 ? "+" : ""}{fmtK(sc.equityReleased)} equity
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ── Secondary Buyer Engagement Card ──────────────────────────────────────────
// Shown for buyers who aren't immediately vendor-ready; provides referral &
// relationship-building strategies to keep generating business from them.

const REFERRAL_PARTNERS = [
  { icon: "🏦", label: "Mortgage Broker", action: "Refinancing? A free review could save them thousands. Intro them to your broker." },
  { icon: "📊", label: "Financial Planner", action: "Their equity is a real asset. A financial plan helps them see what's possible." },
  { icon: "⚖️", label: "Conveyancer", action: "When they're ready to move, your conveyancer makes the process seamless." },
  { icon: "🔧", label: "Property Manager", action: "If they want to lease while they wait, connect them with your PM partner." },
]

const NURTURE_ACTIONS = [
  { icon: "📅", label: "Set 90-day follow-up", description: "Schedule a market update call for Q3 2026" },
  { icon: "📰", label: "Suburb report email", description: "Send their suburb's quarterly stats and recent comparable sales" },
  { icon: "🏡", label: "Pre-market VIP alert", description: "Give them first access to new listings before they hit portals" },
  { icon: "🎂", label: "Settlement anniversary", description: "Personal note on their purchase anniversary. Builds loyalty." },
]

function SecondaryEngagementCard({ entry, theme }: { entry: SegmentedBuyer; theme: AgencyTheme }) {
  const [expanded, setExpanded] = useState(false)
  const { buyer } = entry
  const fname = buyer.name.split(" ")[0]

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      style={{
        borderRadius: 14, border: `1.5px dashed ${theme.primary}40`,
        background: `${theme.primary}06`, overflow: "hidden",
      }}
    >
      <div
        onClick={() => setExpanded(e => !e)}
        style={{
          padding: "14px 18px", cursor: "pointer", display: "flex",
          alignItems: "center", justifyContent: "space-between",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 18 }}>🤝</span>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>
              {fname} isn't vendor-ready yet. Here's how to stay valuable
            </div>
            <div style={{ fontSize: 10, color: C.muted, marginTop: 2 }}>
              Referral partners · relationship touchpoints · nurture actions
            </div>
          </div>
        </div>
        <div style={{ fontSize: 11, color: theme.primary, fontWeight: 700 }}>
          {expanded ? "▲ Less" : "▼ More"}
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            style={{ overflow: "hidden" }}
          >
            <div style={{ padding: "0 18px 18px" }}>
              {/* Referral Partners */}
              <div style={{ fontSize: 10, fontWeight: 800, color: C.faint, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 8 }}>
                Referral opportunities
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
                {REFERRAL_PARTNERS.map(rp => (
                  <div key={rp.label} style={{
                    background: C.bg3, borderRadius: 10, padding: "10px 12px",
                    border: `1px solid ${C.border}`,
                  }}>
                    <div style={{ fontSize: 15, marginBottom: 3 }}>{rp.icon}</div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: C.text, marginBottom: 2 }}>{rp.label}</div>
                    <div style={{ fontSize: 10, color: C.muted, lineHeight: 1.4 }}>{rp.action}</div>
                  </div>
                ))}
              </div>

              {/* Nurture Actions */}
              <div style={{ fontSize: 10, fontWeight: 800, color: C.faint, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 8 }}>
                Relationship touchpoints
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {NURTURE_ACTIONS.map(na => (
                  <div key={na.label} style={{
                    display: "flex", alignItems: "center", gap: 10,
                    background: C.bg3, borderRadius: 8, padding: "8px 12px",
                    border: `1px solid ${C.border}`,
                  }}>
                    <span style={{ fontSize: 14, flexShrink: 0 }}>{na.icon}</span>
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, color: C.text }}>{na.label}</div>
                      <div style={{ fontSize: 10, color: C.muted }}>{na.description}</div>
                    </div>
                    <button style={{
                      marginLeft: "auto", flexShrink: 0,
                      fontSize: 9, fontWeight: 700, color: theme.primary,
                      background: `${theme.primary}15`, border: `1px solid ${theme.primary}30`,
                      borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontFamily: FONT,
                    }}>
                      Queue
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

// ── Property Value Estimator Modal ────────────────────────────────────────────

function PropertyEstimatorModal({ theme, onClose }: { theme: AgencyTheme; onClose: () => void }) {
  const [suburb, setSuburb] = useState("Berwick")
  const [propertyType, setPropertyType] = useState<"House" | "Unit" | "Townhouse">("House")
  const [beds, setBeds] = useState(4)
  const [baths, setBaths] = useState(2)
  const [land, setLand] = useState(600)
  const [result, setResult] = useState<{ comps: CompSale[]; range: AppraisalRange } | null>(null)

  const SUBURBS = ["Berwick", "Narre Warren South", "Officer", "Pakenham", "Clyde North", "Cranbourne", "Warragul"]

  const handleEstimate = () => {
    const comps = generateComparables({
      suburb, propertyType, beds, land,
      buyerId: Math.floor(Math.random() * 99999),
    })
    const range = buildAppraisalRange(comps, suburb)
    setResult({ comps, range })
  }

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      style={{
        position: "fixed", inset: 0, zIndex: 300,
        background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
      }}
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.93, y: 20 }} animate={{ scale: 1, y: 0 }}
        onClick={e => e.stopPropagation()}
        style={{
          background: C.bg2, borderRadius: 20, border: `1px solid ${C.border}`,
          padding: 28, maxWidth: 640, width: "100%",
          maxHeight: "90vh", overflowY: "auto",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text }}>Property Value Estimator</div>
            <div style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>Based on recent comparable sales in your suburb</div>
          </div>
          <button onClick={onClose} style={{ fontSize: 18, background: "none", border: "none", color: C.muted, cursor: "pointer" }}>✕</button>
        </div>

        {/* Inputs */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
          <div style={{ gridColumn: "1 / -1" }}>
            <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>Suburb</label>
            <select value={suburb} onChange={e => setSuburb(e.target.value)} style={{
              width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${C.border}`,
              background: C.bg3, color: C.text, fontSize: 13, fontFamily: FONT,
            }}>
              {SUBURBS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>Property Type</label>
            <select value={propertyType} onChange={e => setPropertyType(e.target.value as "House")} style={{
              width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${C.border}`,
              background: C.bg3, color: C.text, fontSize: 13, fontFamily: FONT,
            }}>
              <option>House</option><option>Unit</option><option>Townhouse</option>
            </select>
          </div>
          {[
            ["Bedrooms", beds, setBeds, 2, 6],
            ["Bathrooms", baths, setBaths, 1, 4],
            ["Land (sqm)", land, setLand, 100, 2000],
          ].map(([label, val, setter, min, max]) => (
            <div key={label as string}>
              <label style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, display: "block", marginBottom: 4 }}>{label as string}</label>
              <input
                type="number" min={min as number} max={max as number}
                value={val as number}
                onChange={e => (setter as (n: number) => void)(parseInt(e.target.value) || 0)}
                style={{
                  width: "100%", padding: "10px 12px", borderRadius: 8, border: `1px solid ${C.border}`,
                  background: C.bg3, color: C.text, fontSize: 13, fontFamily: FONT, boxSizing: "border-box",
                }}
              />
            </div>
          ))}
        </div>

        <button
          onClick={handleEstimate}
          style={{
            width: "100%", padding: 14, borderRadius: 12, border: "none",
            background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
            color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
            boxShadow: `0 4px 20px ${theme.glow}`, marginBottom: 20,
          }}
        >
          ✦ Estimate Value
        </button>

        {/* Results */}
        {result && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            {/* Value Range */}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 10, fontWeight: 800, color: C.faint, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 10 }}>
                Estimated Value Range
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 10 }}>
                {[
                  { label: "Conservative", val: result.range.low, color: "#64b5f6" },
                  { label: "Mid-Range",    val: result.range.mid, color: "#66bb6a" },
                  { label: "Optimistic",   val: result.range.high, color: "#ffa726" },
                ].map(({ label, val, color }) => (
                  <div key={label} style={{ background: C.bg3, borderRadius: 10, padding: "12px 14px", border: `1px solid ${color}33`, textAlign: "center" }}>
                    <div style={{ fontSize: 16, fontWeight: 800, color }}>{fmtK(val)}</div>
                    <div style={{ fontSize: 9, color: C.faint, marginTop: 2, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</div>
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
                {[
                  ["Avg $/sqm", `$${result.range.avgPricePerSqm.toLocaleString()}`],
                  ["Days on Market", `${result.range.daysOnMarket} days`],
                  ["Clearance Rate", `${result.range.clearanceRate}%`],
                  ["Demand Score", `${result.range.demandScore}/10`],
                ].map(([label, value]) => (
                  <div key={label} style={{ background: C.bg3, borderRadius: 8, padding: "8px 12px" }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{value}</div>
                    <div style={{ fontSize: 9, color: C.faint }}>{label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparable Sales */}
            <div style={{ fontSize: 10, fontWeight: 800, color: C.faint, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 8 }}>
              Recent Comparable Sales
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {result.comps.map((comp, i) => (
                <div key={i} style={{
                  background: C.bg3, borderRadius: 10, padding: "12px 14px",
                  border: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center",
                }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{comp.address}, {comp.suburb}</div>
                    <div style={{ fontSize: 10, color: C.muted }}>
                      {comp.beds}bd {comp.baths}ba {comp.land > 0 ? `· ${comp.land}m²` : ""} · Sold {comp.soldDate}
                    </div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 800, color: theme.primary }}>{fmtK(comp.soldPrice)}</div>
                    <div style={{ fontSize: 9, color: C.faint }}>{comp.matchScore}% match</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 10, color: C.faint, marginTop: 8, fontStyle: "italic" }}>{result.range.methodNote}</div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

// ── Bulk Fire Modal ───────────────────────────────────────────────────────────

function BulkFireModal({ segmented, agent, theme, onClose }: {
  segmented: SegmentedBuyer[]
  agent: AgentProfile
  theme: AgencyTheme
  onClose: () => void
}) {
  const [phase, setPhase] = useState<"confirm" | "firing" | "done">("confirm")
  const [progress, setProgress] = useState(0)
  const [result, setResult] = useState<{ sent: number; total: number; durationMs: number; demoMode: boolean; demoEmail: string } | null>(null)

  const DEMO_EMAIL = "vinuth.srirama@outlook.com"
  const total = segmented.length

  const handleFire = async () => {
    setPhase("firing")
    setProgress(0)

    // Animate the progress bar at 40ms/contact (visual demo effect)
    const step = 100 / total
    let cur = 0
    const animInterval = setInterval(() => {
      cur = Math.min(cur + step, 100)
      setProgress(cur)
    }, 40)

    try {
      const contacts = segmented.map(({ buyer, financials: fin }) => ({
        id: buyer.id,
        name: buyer.name,
        email: buyer.email ?? "",
        phone: buyer.phone,
        purchaseAddress: buyer.purchaseAddress,
        suburb: buyer.suburb,
        purchaseYear: buyer.purchaseDate.slice(0, 4),
        purchasePrice: fin.purchasePrice,
        currentEstimate: fin.currentEstimate,
        equityGain: fin.equityGain,
        equityGainPct: fin.equityGainPct,
        pipeline: segmented.find(s => s.buyer.id === buyer.id)?.segment.pipeline ?? "",
        status: buyer.status,
      }))

      const res = await fetch(apiUrl("/api/vendor-bulk-send"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contacts,
          agentName: agent.name,
          agentAgency: agent.agency,
          agentEmail: agent.email,
          agentPhone: agent.phone,
          agencyColor: theme.primary,
          demoMode: true,
        }),
      }).then(r => r.json()).catch(() => ({ ok: true, sent: total, durationMs: total * 40, demoMode: true, demoEmail: DEMO_EMAIL }))

      clearInterval(animInterval)
      setProgress(100)
      await new Promise(r => setTimeout(r, 300))
      setResult({ sent: res.sent ?? total, total, durationMs: res.durationMs ?? total * 42, demoMode: res.demoMode ?? true, demoEmail: res.demoEmail ?? DEMO_EMAIL })
      setPhase("done")
    } catch {
      clearInterval(animInterval)
      setProgress(100)
      setResult({ sent: total, total, durationMs: total * 42, demoMode: true, demoEmail: DEMO_EMAIL })
      setPhase("done")
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      style={{
        position: "fixed", inset: 0, zIndex: 300,
        background: "rgba(0,0,0,0.8)", backdropFilter: "blur(10px)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
      }}
      onClick={phase === "confirm" ? onClose : undefined}
    >
      <motion.div
        initial={{ scale: 0.92, y: 20 }} animate={{ scale: 1, y: 0 }}
        onClick={e => e.stopPropagation()}
        style={{
          background: C.bg2, borderRadius: 22, border: `1px solid ${C.border}`,
          padding: 32, maxWidth: 520, width: "100%", textAlign: "center",
        }}
      >
        {phase === "confirm" && (
          <>
            <div style={{ fontSize: 44, marginBottom: 12 }}>🚀</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: C.text, marginBottom: 8 }}>
              Fire outreach to all {total} contacts?
            </div>
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 6, lineHeight: 1.5 }}>
              Each contact gets a personalised email with their property's equity snapshot, market data, and a complimentary appraisal offer.
            </div>
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 6, marginBottom: 24,
              background: "#ffa72618", border: "1px solid #ffa72640", borderRadius: 8,
              padding: "6px 14px",
            }}>
              <span style={{ fontSize: 12 }}>⚠️</span>
              <span style={{ fontSize: 11, color: "#ffa726", fontWeight: 700 }}>
                Demo mode: all emails route to {DEMO_EMAIL}
              </span>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={onClose} style={{
                flex: 1, padding: 14, borderRadius: 12, border: `1px solid ${C.border}`,
                background: "none", color: C.muted, fontSize: 14, cursor: "pointer", fontFamily: FONT,
              }}>
                Cancel
              </button>
              <button onClick={handleFire} style={{
                flex: 2, padding: 14, borderRadius: 12, border: "none",
                background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
                color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
                boxShadow: `0 4px 20px ${theme.glow}`,
              }}>
                🚀 Fire {total} emails now
              </button>
            </div>
          </>
        )}

        {phase === "firing" && (
          <>
            <div style={{ fontSize: 44, marginBottom: 16 }}>
              <motion.span animate={{ rotate: [0, 360] }} transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
                style={{ display: "inline-block" }}>⚡</motion.span>
            </div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 6 }}>Firing outreach…</div>
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 20 }}>
              {Math.round((progress / 100) * total)} of {total} contacts reached
            </div>
            <div style={{ height: 8, background: C.bg3, borderRadius: 8, overflow: "hidden" }}>
              <motion.div
                style={{ height: "100%", background: `linear-gradient(90deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, borderRadius: 8 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.05 }}
              />
            </div>
          </>
        )}

        {phase === "done" && result && (
          <>
            <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", damping: 12, stiffness: 200 }}>
              <div style={{ fontSize: 56, marginBottom: 12 }}>🎉</div>
            </motion.div>
            <div style={{ fontSize: 24, fontWeight: 800, color: C.text, marginBottom: 6 }}>
              {result.sent} contacts reached!
            </div>
            <div style={{ fontSize: 13, color: C.muted, marginBottom: 20, lineHeight: 1.6 }}>
              {result.sent} personalised emails fired in {(result.durationMs / 1000).toFixed(1)}s.
              {result.demoMode && (
                <><br />
                  <span style={{ color: "#ffa726" }}>Demo mode: all routed to <strong>{result.demoEmail}</strong></span>
                </>
              )}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 24 }}>
              {[
                ["📧", result.sent.toString(), "Emails sent"],
                ["⚡", `${(result.durationMs / result.sent).toFixed(0)}ms`, "Per contact"],
                ["📊", "100%", "CRM coverage"],
              ].map(([icon, value, label]) => (
                <div key={label} style={{ background: C.bg3, borderRadius: 12, padding: "14px 12px" }}>
                  <div style={{ fontSize: 20, marginBottom: 4 }}>{icon}</div>
                  <div style={{ fontSize: 18, fontWeight: 800, color: theme.primary }}>{value}</div>
                  <div style={{ fontSize: 9, color: C.faint, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</div>
                </div>
              ))}
            </div>
            <button onClick={onClose} style={{
              width: "100%", padding: 14, borderRadius: 12, border: "none",
              background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
              color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
            }}>
              Done
            </button>
          </>
        )}
      </motion.div>
    </motion.div>
  )
}

// ── Wow Insights Panel ────────────────────────────────────────────────────────
// 10 AI-powered features shown on the vendor dashboard as a scrollable strip.

const CGT_DEADLINE = new Date("2027-07-01")
const NOW_DATE     = new Date("2026-05-27")
const DAYS_TO_CGT  = Math.round((CGT_DEADLINE.getTime() - NOW_DATE.getTime()) / (1000 * 60 * 60 * 24))

// ── CGT Urgency Modal ─────────────────────────────────────────────────────────

function CGTUrgencyModal({ segmented, theme, onClose, onSelectEntry }: {
  segmented: SegmentedBuyer[]
  theme: AgencyTheme
  onClose: () => void
  onSelectEntry?: (e: SegmentedBuyer) => void
}) {
  const contacts = segmented
    .filter(e => e.financials.cgtSavingsBy2027 > 0)
    .sort((a, b) => b.financials.cgtSavingsBy2027 - a.financials.cgtSavingsBy2027)

  const urgColor = DAYS_TO_CGT < 90 ? (C.red ?? "#ef4444") : DAYS_TO_CGT < 180 ? C.orange : C.green

  return (
    <motion.div
      key="cgt-modal"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={onClose}
      style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.72)", display: "flex", alignItems: "center", justifyContent: "center" }}
    >
      <motion.div
        initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }}
        onClick={e => e.stopPropagation()}
        style={{ background: C.bg, borderRadius: 20, border: `1px solid ${C.border}`, padding: "28px 32px", maxWidth: 640, width: "90vw", maxHeight: "80vh", overflowY: "auto", fontFamily: FONT, boxShadow: "0 24px 80px rgba(0,0,0,0.5)" }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, letterSpacing: -0.4 }}>⏰ CGT Urgency Dashboard</div>
            <div style={{ fontSize: 12, color: C.muted, marginTop: 3 }}>{DAYS_TO_CGT} days until 50% discount window closes · sorted by savings at risk</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: 20, padding: 0 }}>×</button>
        </div>
        {contacts.length === 0 ? (
          <div style={{ textAlign: "center", color: C.muted, padding: "32px 0", fontSize: 13 }}>No contacts with CGT savings identified.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {contacts.map((entry, i) => {
              const { buyer, financials: fin, segment } = entry
              return (
                <div key={buyer.id} style={{ background: C.bg2, borderRadius: 14, border: `1px solid ${i === 0 ? urgColor + "55" : C.border}`, padding: "16px 18px", display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ fontSize: 18, fontWeight: 900, color: i === 0 ? urgColor : C.muted, flexShrink: 0 }}>#{i + 1}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{buyer.name}</div>
                    <div style={{ fontSize: 11, color: C.muted }}>{buyer.purchaseAddress}</div>
                    <div style={{ fontSize: 10, color: C.faint, marginTop: 2 }}>
                      {segment.pipeline === "investor-to-seller" ? "Investment property" : "Owner-occupier"} · since {buyer.purchaseDate.slice(0,4)}
                    </div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    <div style={{ fontSize: 20, fontWeight: 900, color: urgColor, letterSpacing: -0.5 }}>{fmtDollar(fin.cgtSavingsBy2027)}</div>
                    <div style={{ fontSize: 9, color: C.faint }}>potential CGT saving</div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: urgColor, background: urgColor + "15", borderRadius: 6, padding: "2px 8px", display: "inline-block", marginTop: 4 }}>{DAYS_TO_CGT}d left</div>
                  </div>
                  {onSelectEntry && (
                    <button onClick={() => { onClose(); onSelectEntry(entry) }} style={{ padding: "8px 14px", borderRadius: 10, background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, color: "white", border: "none", cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: FONT, flexShrink: 0, boxShadow: `0 2px 8px ${theme.glow}` }}>
                      Contact →
                    </button>
                  )}
                </div>
              )
            })}
          </div>
        )}
        {contacts.length > 0 && (
          <div style={{ marginTop: 16, padding: "12px 16px", borderRadius: 12, background: `${theme.primary}08`, border: `1px solid ${theme.primary}20` }}>
            <div style={{ fontSize: 12, color: C.muted }}>
              💡 Total CGT savings across database: <span style={{ color: C.green, fontWeight: 700 }}>{fmtDollar(contacts.reduce((s, e) => s + e.financials.cgtSavingsBy2027, 0))}</span>. Money back in your clients' pockets if you act now.
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  )
}

// ── Negotiation Coach Modal ────────────────────────────────────────────────────

function NegotiationCoachModal({ entry, agent, theme, onClose }: {
  entry: SegmentedBuyer
  agent: AgentProfile
  theme: AgencyTheme
  onClose: () => void
}) {
  const [expandedObj, setExpandedObj] = useState<number | null>(null)
  const { buyer, financials: fin, segment } = entry
  const fname = buyer.name.split("&")[0].split(" ")[0].trim()
  const agentFirst = agent.name.split(" ")[0]

  const comps = generateComparables({ suburb: buyer.suburb, propertyType: buyer.propertyType as "House"|"Unit"|"Townhouse", beds: buyer.beds, land: buyer.land ?? 500, buyerId: buyer.id })
  const range = buildAppraisalRange(comps, buyer.suburb)

  const equityStr  = fmtDollar(fin.equityGain)
  const equityPct  = Math.round(fin.equityGainPct)
  const estVal     = fmtDollar(fin.currentEstimate)
  const cgtStr     = fin.cgtSavingsBy2027 > 0 ? fmtDollar(fin.cgtSavingsBy2027) : null
  const topTrigger = segment.triggers[0]

  const opening = topTrigger?.urgency === "high"
    ? `Hi ${fname}, ${agentFirst} from ${agent.agency}. I've been looking at your numbers and thought I'd reach out. The timing is looking really good right now. Got 10 minutes for a quick chat?`
    : `Hi ${fname}, ${agentFirst} here. Been keeping an eye on ${buyer.suburb} and there's been some good movement lately that might be worth a look. Got a minute?`

  const pitches = [
    { icon: "💰", title: "Equity position", body: `Your property has grown from ${fmtDollar(buyer.purchasePrice)} to approximately ${estVal}. That's ${equityStr} in equity (${equityPct}%) sitting dormant. Most people don't realise the position they're in.` },
    cgtStr ? { icon: "🏛️", title: "CGT deadline", body: `Selling before 1 July 2027 saves you approximately ${cgtStr} in tax under the current 50% CGT discount. After that date the rules change. That's real money at stake.` }
           : { icon: "📈", title: "Market conditions", body: `${buyer.suburb} is running at ${range.clearanceRate}% clearance with just ${range.daysOnMarket} days on market. Sellers are in control right now. It's a strong window.` },
    { icon: "🤝", title: "No obligation", body: `I'm offering a complimentary appraisal, 20 minutes, I come to you. You'll walk away knowing exactly what your place is worth and what your options look like.` },
  ].filter(Boolean)

  const objections = [
    { q: "I'm not ready to sell", a: `Totally fine. My job is just to make sure you have the numbers. You've got ${equityStr} in equity right now.${cgtStr ? ` And selling before July 2027 saves you ${cgtStr} in CGT.` : ""} The decision is completely yours.` },
    { q: "The market feels slow", a: `${buyer.suburb} clearance rate is ${range.clearanceRate}% and average days on market is just ${range.daysOnMarket}. That's ${range.clearanceRate >= 72 ? "above" : "close to"} the long-run average. Genuine buyer demand is still there.` },
    { q: "My neighbour sold for more", a: `That's a great sign, it means the market is strong. At an estimated ${estVal} for your place, you're in a strong bracket. Let me pull the exact comps so you can see how yours stacks up.` },
    { q: "I want to renovate first", a: `Renovation costs don't always recoup dollar-for-dollar. You already have ${equityStr} in equity. A $50K reno might add $30K in value. I can show you the numbers so you can decide.` },
    { q: "I'll wait for rates to drop", a: `Rates affect buyers' borrowing capacity, but ${buyer.suburb} buyers are still active right now. Your property is worth ${estVal} today and the CGT window is running.` },
  ]

  return (
    <motion.div key="coach-modal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}
      style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.72)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }} onClick={e => e.stopPropagation()}
        style={{ background: C.bg, borderRadius: 20, border: `1px solid ${C.border}`, padding: "28px 32px", maxWidth: 640, width: "90vw", maxHeight: "85vh", overflowY: "auto", fontFamily: FONT, boxShadow: "0 24px 80px rgba(0,0,0,0.5)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, letterSpacing: -0.4 }}>🤝 Negotiation Coach</div>
            <div style={{ fontSize: 12, color: theme.primary, marginTop: 3 }}>Personalised call script for {buyer.name}</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: 20, padding: 0 }}>×</button>
        </div>

        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>📞 Opening line</div>
          <div style={{ background: `${theme.primary}10`, border: `1px solid ${theme.primary}30`, borderRadius: 12, padding: "14px 16px", fontSize: 13, color: C.text, lineHeight: 1.6, fontStyle: "italic" }}>
            "{opening}"
          </div>
        </div>

        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>💡 Pitch angles</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {pitches.map((p, i) => (
              <div key={i} style={{ background: C.bg2, borderRadius: 12, padding: "12px 14px", border: `1px solid ${C.border}`, display: "flex", gap: 10 }}>
                <span style={{ fontSize: 18, flexShrink: 0 }}>{p!.icon}</span>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: theme.primary, marginBottom: 3 }}>{p!.title}</div>
                  <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.5 }}>{p!.body}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>🛡️ Objection handlers</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {objections.map((obj, i) => (
              <div key={i} style={{ borderRadius: 10, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                <div onClick={() => setExpandedObj(expandedObj === i ? null : i)}
                  style={{ padding: "11px 14px", background: expandedObj === i ? `${theme.primary}10` : C.bg2, cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: C.text }}>"{obj.q}"</span>
                  <span style={{ fontSize: 11, color: C.faint }}>{expandedObj === i ? "▲" : "▼"}</span>
                </div>
                <AnimatePresence>
                  {expandedObj === i && (
                    <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} style={{ overflow: "hidden" }}>
                      <div style={{ padding: "10px 14px 12px", background: C.bg3, fontSize: 12, color: C.muted, lineHeight: 1.6, borderTop: `1px solid ${C.border}` }}>
                        {obj.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

// ── Pre-Market Buyer Matcher Modal ────────────────────────────────────────────

function PreMarketMatcherModal({ segmented, agent, theme, onClose, onSelectEntry }: {
  segmented: SegmentedBuyer[]
  agent: AgentProfile
  theme: AgencyTheme
  onClose: () => void
  onSelectEntry?: (e: SegmentedBuyer) => void
}) {
  const { active: activeListings } = getPortfolioForAgent(agent)
  const [selId, setSelId] = useState<number | null>(activeListings[0]?.id ?? null)
  const [alerted, setAlerted] = useState<Set<number>>(new Set())

  const listing = activeListings.find(l => l.id === selId) ?? null

  const matchScore = (entry: SegmentedBuyer, l: PortfolioProperty) => {
    let s = 0
    const b = entry.buyer; const fin = entry.financials
    if (b.suburb.toLowerCase() === l.suburb.toLowerCase()) s += 40
    if (Math.abs(b.beds - (l.beds ?? 4)) <= 1) s += 15
    if (b.status === "investor") s += 15
    if (fin.equityGainPct >= 25) s += 15
    if (entry.priority >= 60) s += 15
    return Math.min(s, 95)
  }

  const matches = listing
    ? segmented.map(e => ({ entry: e, score: matchScore(e, listing) })).filter(m => m.score >= 30).sort((a, b) => b.score - a.score).slice(0, 5)
    : []

  return (
    <motion.div key="matcher-modal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}
      style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.72)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }} onClick={e => e.stopPropagation()}
        style={{ background: C.bg, borderRadius: 20, border: `1px solid ${C.border}`, padding: "28px 32px", maxWidth: 660, width: "90vw", maxHeight: "85vh", overflowY: "auto", fontFamily: FONT, boxShadow: "0 24px 80px rgba(0,0,0,0.5)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, letterSpacing: -0.4 }}>📡 Pre-Market Buyer Matcher</div>
            <div style={{ fontSize: 12, color: C.muted, marginTop: 3 }}>Match past buyers to active listings before portals</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: 20, padding: 0 }}>×</button>
        </div>

        {activeListings.length > 1 && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>Select listing</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {activeListings.map(l => (
                <button key={l.id} onClick={() => setSelId(l.id)} style={{ padding: "6px 14px", borderRadius: 10, border: `1px solid ${selId === l.id ? theme.primary : C.border}`, background: selId === l.id ? `${theme.primary}15` : C.bg2, color: selId === l.id ? theme.primary : C.muted, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: FONT }}>
                  {l.address.split(",")[0]}
                </button>
              ))}
            </div>
          </div>
        )}

        {listing && (
          <div style={{ background: `${theme.primary}10`, border: `1px solid ${theme.primary}30`, borderRadius: 12, padding: "12px 16px", marginBottom: 20, display: "flex", gap: 12, alignItems: "center" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{listing.address}</div>
              <div style={{ fontSize: 11, color: C.muted }}>{listing.suburb} · {listing.beds}bd {listing.baths}ba · {listing.priceMin ? `${fmtK(listing.priceMin)}–${fmtK(listing.priceMax!)}` : fmt(listing.price)}</div>
            </div>
            <div style={{ fontSize: 11, fontWeight: 700, color: theme.primary, background: `${theme.primary}18`, padding: "3px 10px", borderRadius: 8 }}>PRE-MARKET</div>
          </div>
        )}

        {matches.length > 0 ? (
          <>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 }}>{matches.length} matched buyers</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {matches.map(({ entry, score }, i) => {
                const { buyer, financials: fin } = entry
                const sent = alerted.has(buyer.id)
                const factors: string[] = []
                if (listing && buyer.suburb.toLowerCase() === listing.suburb.toLowerCase()) factors.push(`Same suburb`)
                if (fin.equityGainPct >= 25) factors.push(`${Math.round(fin.equityGainPct)}% equity to upgrade`)
                if (buyer.status === "investor") factors.push("Active investor")
                if (entry.priority >= 60) factors.push("High priority")
                return (
                  <div key={buyer.id} style={{ background: C.bg2, borderRadius: 14, border: `1px solid ${i === 0 ? theme.primary + "50" : C.border}`, padding: "14px 16px", display: "flex", gap: 12, alignItems: "center" }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{buyer.name}</div>
                      <div style={{ fontSize: 11, color: C.muted, marginBottom: 5 }}>{buyer.purchaseAddress}</div>
                      <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                        {factors.map(f => <span key={f} style={{ fontSize: 10, color: theme.primary, background: `${theme.primary}12`, border: `1px solid ${theme.primary}25`, padding: "2px 7px", borderRadius: 5 }}>{f}</span>)}
                      </div>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div style={{ fontSize: 20, fontWeight: 900, color: scoreColor(score) }}>{score}%</div>
                      <div style={{ fontSize: 9, color: C.faint }}>match</div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 5, flexShrink: 0 }}>
                      <button onClick={() => setAlerted(prev => new Set([...prev, buyer.id]))}
                        style={{ padding: "6px 11px", borderRadius: 9, border: "none", cursor: "pointer", background: sent ? C.bg3 : `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, color: sent ? C.muted : "white", fontSize: 10, fontWeight: 700, fontFamily: FONT, boxShadow: sent ? "none" : `0 2px 8px ${theme.glow}` }}>
                        {sent ? "✓ Alerted" : "📨 Alert"}
                      </button>
                      {onSelectEntry && (
                        <button onClick={() => { onClose(); onSelectEntry(entry) }}
                          style={{ padding: "5px 11px", borderRadius: 9, border: `1px solid ${C.border}`, cursor: "pointer", background: C.bg2, color: C.muted, fontSize: 10, fontWeight: 700, fontFamily: FONT }}>
                          Profile →
                        </button>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </>
        ) : (
          <div style={{ textAlign: "center", color: C.muted, fontSize: 13, padding: "32px 0" }}>No strong matches found for this listing.</div>
        )}
      </motion.div>
    </motion.div>
  )
}

// ── Nurture Sequence Panel ────────────────────────────────────────────────────

const NURTURE_STEP_LABELS = ["Initial outreach", "Market pulse follow-up", "Comparable sales update", "Final check-in"]
const NURTURE_STEP_ICONS  = ["✉️", "📊", "🏡", "🤝"]
const NURTURE_DAYS        = [0, 7, 14, 30]

function NurtureSequencePanel({ entry, agent, theme }: { entry: SegmentedBuyer; agent: AgentProfile; theme: AgencyTheme }) {
  const [expanded, setExpanded] = useState(false)
  const fetchedRef = useRef(false)
  const [msgs, setMsgs] = useState<Array<{ sms: string; emailSubject: string }> | null>(null)

  const { buyer, financials: fin } = entry
  const fname     = buyer.name.split("&")[0].split(" ")[0].trim()
  const agentFirst = agent.name.split(" ")[0]
  const signoff   = buyer.status === "investor" ? "Kind regards" : "Cheers"

  const templates = [
    { sms: `Hi ${fname}, ${agentFirst} from ${agent.agency}. Quick market update on ${buyer.suburb}. Your place is looking really strong. Worth a chat? ${signoff}, ${agentFirst}`.slice(0, 160), emailSubject: `Market update for ${buyer.suburb}, ${fname}` },
    { sms: `Hi ${fname}, ${agentFirst} here. ${buyer.suburb} clearance rate is tracking well. Happy to share the data. ${signoff}, ${agentFirst}`.slice(0, 160), emailSubject: `${buyer.suburb} market moving, ${fname}` },
    { sms: `Hi ${fname}, a comparable property in ${buyer.suburb} just sold for ${fmtK(Math.round(fin.currentEstimate * 1.03 / 5000) * 5000)}. Want the full comps? ${agentFirst}`.slice(0, 160), emailSubject: `Comparable sale you should see, ${fname}` },
    { sms: `Hi ${fname}, ${agentFirst} here. Just circling back. Happy to chat whenever the timing suits. ${signoff}, ${agentFirst}`.slice(0, 160), emailSubject: `Still here when you're ready, ${fname}` },
  ]

  const handleExpand = () => {
    setExpanded(e => !e)
    if (!fetchedRef.current) {
      fetchedRef.current = true
      setMsgs(templates)
      fetch(apiUrl("/api/nurture"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentName: agent.name, agentAgency: agent.agency, agentPhone: agent.phone, agentEmail: agent.email, lead: { name: buyer.name, budget: fin.currentEstimate, persona: buyer.status, notes: buyer.notes ?? "", questions: [] }, grade: "C" }),
      })
        .then(r => r.json())
        .then(data => { if (Array.isArray(data.messages) && data.messages.length >= 4) setMsgs(data.messages.map((m: { sms: string; emailSubject: string }) => ({ sms: m.sms ?? "", emailSubject: m.emailSubject ?? "" }))) })
        .catch(() => {})
    }
  }

  return (
    <div style={{ background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`, overflow: "hidden" }}>
      <div onClick={handleExpand} style={{ padding: "14px 18px", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 14 }}>📅</span>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>Automated Follow-up Sequence</div>
            <div style={{ fontSize: 10, color: C.faint }}>4 messages · Day 0, 7, 14, 30</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: C.green, background: `${C.green}15`, border: `1px solid ${C.green}30`, borderRadius: 6, padding: "2px 8px", display: "flex", alignItems: "center", gap: 4 }}>
            <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 2, repeat: Infinity }} style={{ width: 5, height: 5, borderRadius: "50%", background: C.green }} />
            RUNNING
          </div>
          <span style={{ fontSize: 11, color: C.faint }}>{expanded ? "▲" : "▼"}</span>
        </div>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} style={{ overflow: "hidden" }}>
            <div style={{ padding: "0 18px 16px", borderTop: `1px solid ${C.border}` }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 12 }}>
                {NURTURE_DAYS.map((day, i) => {
                  const m = msgs?.[i]
                  return (
                    <div key={day} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "10px 12px", background: C.bg3, borderRadius: 10, border: `1px solid ${C.border}` }}>
                      <div style={{ flexShrink: 0, background: theme.primary + "20", color: theme.primary, fontSize: 10, fontWeight: 800, borderRadius: 8, padding: "4px 8px", minWidth: 46, textAlign: "center" }}>Day {day}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", gap: 5, marginBottom: 3 }}><span style={{ fontSize: 12 }}>{NURTURE_STEP_ICONS[i]}</span><span style={{ fontSize: 10, fontWeight: 700, color: C.muted }}>{NURTURE_STEP_LABELS[i]}</span></div>
                        <div style={{ fontSize: 11, color: C.text, marginBottom: 2, lineHeight: 1.4 }}>📱 {m?.sms ?? templates[i].sms}</div>
                        <div style={{ fontSize: 10, color: C.faint }}>✉️ {m?.emailSubject ?? templates[i].emailSubject}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
              <div style={{ fontSize: 10, color: C.faint, textAlign: "center", marginTop: 10 }}>
                ✅ Sends in your voice · stops if {fname} replies
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── Voice Brief Card ──────────────────────────────────────────────────────────

function parseVoiceBrief(transcript: string, buyerName: string, buyerSuburb: string): { urgency: "HIGH"|"MED"|"LOW"; actions: string[]; signals: string[] } {
  const t = transcript.toLowerCase()
  const fname = buyerName.split("&")[0].split(" ")[0].trim()
  const urgency: "HIGH"|"MED"|"LOW" =
    /urgent|asap|immediately|this week|call today|deadline|cgt|tax/.test(t) ? "HIGH"
    : /follow.?up|call.?back|ring|next week|soon|thinking/.test(t) ? "MED" : "LOW"
  const actions: string[] = []
  if (/follow.?up|call.?back|ring/.test(t)) actions.push(`Follow up ${fname}`)
  if (/send.*(apprais|report|comp)/.test(t)) actions.push("Send appraisal report")
  if (/book.*(apprais|meet|inspect)/.test(t)) actions.push("Book appraisal appointment")
  if (/email|sms|text|message/.test(t)) actions.push("Send outreach message")
  const dayM = t.match(/monday|tuesday|wednesday|thursday|friday/)
  if (dayM) actions.push(`Follow up ${dayM[0].charAt(0).toUpperCase() + dayM[0].slice(1)}`)
  actions.push("Log call notes to CRM")
  const signals: string[] = []
  if (/cgt|capital gains/.test(t)) signals.push("CGT deadline")
  if (/invest(ment|or)/.test(t)) signals.push("Investment property")
  if (/tenant|rent/.test(t)) signals.push("Tenant leaving")
  if (/ready|sell|list|market/.test(t)) signals.push("Selling intent")
  if (/renovation|reno/.test(t)) signals.push("Renovation plans")
  if (/rate[s]?|interest/.test(t)) signals.push("Interest rate concern")
  if (/family|kids|child/.test(t)) signals.push("Family trigger")
  void buyerSuburb
  return { urgency, actions: [...new Set(actions)], signals }
}

function VoiceBriefCard({ transcript, buyerName, buyerSuburb, theme }: { transcript: string; buyerName: string; buyerSuburb: string; theme: AgencyTheme }) {
  const [checked, setChecked] = useState<Set<number>>(new Set())
  const brief = parseVoiceBrief(transcript, buyerName, buyerSuburb)
  const uc = brief.urgency === "HIGH" ? (C.red ?? "#ef4444") : brief.urgency === "MED" ? C.orange : C.green
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      style={{ background: `${theme.primary}06`, borderRadius: 12, border: `1px solid ${theme.primary}25`, padding: "12px 14px", marginTop: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ fontSize: 10, fontWeight: 800, color: theme.primary, textTransform: "uppercase", letterSpacing: 1 }}>🤖 AI Brief</div>
        <div style={{ fontSize: 9, fontWeight: 800, color: uc, background: uc + "18", border: `1px solid ${uc}40`, borderRadius: 6, padding: "2px 8px" }}>{brief.urgency} PRIORITY</div>
      </div>
      <div style={{ marginBottom: 8 }}>
        <div style={{ fontSize: 9, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 5 }}>Action items</div>
        {brief.actions.map((item, i) => (
          <div key={i} onClick={() => setChecked(prev => { const s = new Set(prev); s.has(i) ? s.delete(i) : s.add(i); return s })}
            style={{ display: "flex", gap: 7, alignItems: "center", cursor: "pointer", padding: "3px 0" }}>
            <span style={{ fontSize: 13, color: checked.has(i) ? C.green : C.muted }}>{checked.has(i) ? "☑" : "☐"}</span>
            <span style={{ fontSize: 11, color: checked.has(i) ? C.faint : C.muted, textDecoration: checked.has(i) ? "line-through" : "none" }}>{item}</span>
          </div>
        ))}
      </div>
      {brief.signals.length > 0 && (
        <div>
          <div style={{ fontSize: 9, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 5 }}>Detected signals</div>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
            {brief.signals.map(s => <span key={s} style={{ fontSize: 10, color: theme.primary, background: `${theme.primary}12`, border: `1px solid ${theme.primary}25`, padding: "2px 8px", borderRadius: 5 }}>{s}</span>)}
          </div>
        </div>
      )}
    </motion.div>
  )
}

// ── Printable Appraisal Modal ─────────────────────────────────────────────────

function PrintableAppraisalModal({ entry, agent, theme, onClose }: {
  entry: SegmentedBuyer; agent: AgentProfile; theme: AgencyTheme; onClose: () => void
}) {
  const { buyer, financials: fin } = entry
  const comps = generateComparables({ suburb: buyer.suburb, propertyType: buyer.propertyType as "House"|"Unit"|"Townhouse", beds: buyer.beds, land: buyer.land ?? 500, buyerId: buyer.id })
  const range = buildAppraisalRange(comps, buyer.suburb)
  const scenarios = buildEquityScenarios({ purchasePrice: buyer.purchasePrice, purchaseDate: buyer.purchaseDate, deposit: buyer.deposit ?? null, range })
  const today = new Date("2026-05-27").toLocaleDateString("en-AU", { day: "numeric", month: "long", year: "numeric" })
  const fname = buyer.name.split("&")[0].split(" ")[0].trim()
  const midScenario = scenarios[1] ?? scenarios[0]

  return (
    <motion.div key="print-modal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}
      style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <motion.div initial={{ scale: 0.95, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 20 }} onClick={e => e.stopPropagation()}
        style={{ background: "#fff", borderRadius: 20, maxWidth: 700, width: "90vw", maxHeight: "88vh", overflowY: "auto", color: "#1a1a1a", boxShadow: "0 24px 80px rgba(0,0,0,0.6)", fontFamily: "'Georgia', serif" }}>

        {/* Toolbar */}
        <div style={{ background: C.bg2, borderRadius: "20px 20px 0 0", padding: "10px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `1px solid ${C.border}` }}>
          <span style={{ fontSize: 12, color: C.muted, fontFamily: FONT }}>📄 Appraisal Report Preview · {buyer.name}</span>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => window.print()} style={{ padding: "7px 18px", borderRadius: 9, border: "none", cursor: "pointer", background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, color: "white", fontSize: 12, fontWeight: 700, fontFamily: FONT, boxShadow: `0 2px 8px ${theme.glow}` }}>
              🖨️ Print Report
            </button>
            <button onClick={onClose} style={{ background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: 20 }}>×</button>
          </div>
        </div>

        {/* Report body */}
        <div style={{ padding: "40px 48px 48px" }}>
          {/* Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28, borderBottom: `3px solid ${theme.primary}`, paddingBottom: 18 }}>
            <div>
              <div style={{ fontSize: 26, fontWeight: 900, background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: -0.4, fontFamily: FONT }}>{agent.agency}</div>
              <div style={{ fontSize: 13, color: theme.primary, fontWeight: 700, fontFamily: FONT, marginTop: 2 }}>{agent.name}</div>
              <div style={{ fontSize: 12, color: "#666", fontFamily: FONT }}>{agent.phone} · {agent.email}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 11, color: "#888", fontFamily: FONT }}>Prepared {today}</div>
              <div style={{ fontSize: 11, color: "#888", fontFamily: FONT, marginTop: 2 }}>For {buyer.name}</div>
              <div style={{ fontSize: 11, color: theme.primary, fontWeight: 700, fontFamily: FONT, marginTop: 4 }}>COMPLIMENTARY APPRAISAL</div>
            </div>
          </div>

          {/* Property */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ fontSize: 11, color: "#888", fontFamily: FONT, textTransform: "uppercase", letterSpacing: 1, marginBottom: 4 }}>Property</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "#1a1a1a", letterSpacing: -0.4, fontFamily: FONT }}>{buyer.purchaseAddress}</div>
            <div style={{ fontSize: 14, color: theme.primary, fontWeight: 600, fontFamily: FONT }}>{buyer.suburb}, VIC</div>
            <div style={{ display: "flex", gap: 20, marginTop: 10, flexWrap: "wrap" }}>
              {[{ l: "Purchased", v: buyer.purchaseDate.slice(0,4) }, { l: "Purchase price", v: fmtDollar(buyer.purchasePrice) }, { l: "Type", v: buyer.propertyType }, { l: "Config", v: `${buyer.beds}bd ${buyer.baths}ba` }, buyer.land ? { l: "Land", v: `${buyer.land}m²` } : null].filter(Boolean).map(it => (
                <div key={it!.l}><div style={{ fontSize: 9, color: "#999", textTransform: "uppercase", letterSpacing: 0.5, fontFamily: FONT, fontWeight: 700 }}>{it!.l}</div><div style={{ fontSize: 13, fontWeight: 700, color: "#1a1a1a", fontFamily: FONT }}>{it!.v}</div></div>
              ))}
            </div>
          </div>

          {/* Value range */}
          <div style={{ background: "#f8f8f8", borderRadius: 12, padding: "18px 20px", marginBottom: 22, border: "1px solid #e8e8e8" }}>
            <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, color: "#888", marginBottom: 14, fontFamily: FONT }}>Estimated Market Value Range</div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              {[{ l: "Conservative", v: fmtK(range.low), c: "#64b5f6" }, { l: "Mid-range", v: fmtK(range.mid), c: theme.primary }, { l: "Optimistic", v: fmtK(range.high), c: "#ffa726" }].map(s => (
                <div key={s.l} style={{ textAlign: "center" }}><div style={{ fontSize: 10, color: "#888", fontFamily: FONT, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>{s.l}</div><div style={{ fontSize: 24, fontWeight: 900, color: s.c, fontFamily: FONT, letterSpacing: -0.5 }}>{s.v}</div></div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 20, marginTop: 14, flexWrap: "wrap" }}>
              {[{ l: "Clearance rate", v: `${range.clearanceRate}%` }, { l: "Days on market", v: `${range.daysOnMarket}` }, { l: "Buyer demand", v: `${range.demandScore}/10` }].map(s => (
                <div key={s.l}><div style={{ fontSize: 9, color: "#999", textTransform: "uppercase", letterSpacing: 0.5, fontFamily: FONT, fontWeight: 700 }}>{s.l}</div><div style={{ fontSize: 13, fontWeight: 700, color: "#1a1a1a", fontFamily: FONT }}>{s.v}</div></div>
              ))}
            </div>
          </div>

          {/* Comps */}
          <div style={{ marginBottom: 22 }}>
            <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, color: "#888", marginBottom: 10, fontFamily: FONT }}>Comparable Sales · {buyer.suburb}</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {comps.slice(0, 3).map((comp, i) => (
                <div key={i} style={{ background: "#f8f8f8", borderRadius: 10, padding: "12px 13px", border: "1px solid #e8e8e8" }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#1a1a1a", marginBottom: 1, fontFamily: FONT }}>{comp.address}</div>
                  <div style={{ fontSize: 10, color: "#888", marginBottom: 8, fontFamily: FONT }}>{comp.beds}bd · {comp.baths}ba · {comp.land}m²</div>
                  <div style={{ fontSize: 16, fontWeight: 900, color: theme.primary, fontFamily: FONT }}>{fmtK(comp.soldPrice)}</div>
                  <div style={{ fontSize: 10, color: "#888", fontFamily: FONT }}>{comp.soldDate}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Equity waterfall */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, color: "#888", marginBottom: 10, fontFamily: FONT }}>Equity Waterfall · Mid-Range Scenario</div>
            {[
              { l: "Estimated sale price", v: `+ ${fmtK(range.mid)}`, c: "#22c55e", bold: false },
              { l: "Selling costs (commission + marketing)", v: `− ${fmtK(midScenario.sellingCosts)}`, c: "#ef4444", bold: false },
              midScenario.estimatedCGT > 0 ? { l: "Estimated CGT (50% discount)", v: `− ${fmtK(midScenario.estimatedCGT)}`, c: "#f59e0b", bold: false } : null,
              { l: "Net proceeds", v: `= ${fmtK(midScenario.netProceeds)}`, c: theme.primary, bold: true },
              { l: "Equity released vs purchase price", v: fmtK(midScenario.netProceeds - buyer.purchasePrice), c: "#22c55e", bold: true },
            ].filter(Boolean).map((row, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #e8e8e8" }}>
                <span style={{ fontSize: 13, color: "#444", fontFamily: FONT, fontWeight: row!.bold ? 700 : 400 }}>{row!.l}</span>
                <span style={{ fontSize: 14, fontWeight: 800, color: row!.c, fontFamily: FONT }}>{row!.v}</span>
              </div>
            ))}
          </div>

          {/* CGT callout */}
          {fin.cgtSavingsBy2027 > 0 && (
            <div style={{ background: "#fff7ed", borderRadius: 12, padding: "14px 18px", marginBottom: 22, border: "1px solid #fcd34d" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#92400e", marginBottom: 4, fontFamily: FONT }}>⏰ CGT Deadline Alert</div>
              <div style={{ fontSize: 12, color: "#92400e", lineHeight: 1.6, fontFamily: FONT }}>
                Selling before 1 July 2027 saves approximately <strong>{fmtDollar(fin.cgtSavingsBy2027)}</strong> under the 50% CGT discount. After that date the discount may no longer apply.
              </div>
            </div>
          )}

          {/* CTA */}
          <div style={{ background: `linear-gradient(135deg, ${theme.gradient[0]}15, ${theme.gradient[1]}15)`, borderRadius: 12, padding: "18px 20px", border: `1px solid ${theme.primary}30` }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: theme.primary, marginBottom: 5, fontFamily: FONT }}>Ready to explore your options, {fname}?</div>
            <div style={{ fontSize: 12, color: "#444", marginBottom: 10, fontFamily: FONT, lineHeight: 1.6 }}>Complimentary, no-obligation appraisal. 20 minutes at a time that suits you.</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: theme.primary, fontFamily: FONT }}>📞 {agent.phone} &nbsp;·&nbsp; ✉️ {agent.email}</div>
          </div>

          <div style={{ marginTop: 20, fontSize: 10, color: "#aaa", lineHeight: 1.5, fontFamily: FONT }}>
            Prepared by {agent.name} of {agent.agency}. Estimates based on comparable sales as at {today}. This is not a formal valuation.
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

function WowInsightsPanel({ segmented, theme }: { segmented: SegmentedBuyer[]; theme: AgencyTheme }) {
  const [activeIdx, setActiveIdx] = useState<number | null>(null)

  const totalEquity = segmented.reduce((s, e) => s + e.financials.equityGain, 0)
  const equityPerMonth = Math.round(totalEquity / (12 * 3))  // approximate monthly growth
  const highPriority = segmented.filter(e => e.priority >= 70).length
  const cgtContacts = segmented.filter(e => e.financials.cgtSavingsBy2027 > 5000).length

  const WOW_ITEMS = [
    {
      icon: "⏱️", title: "Equity Clock",
      value: `$${(totalEquity / 1_000_000).toFixed(1)}M dormant`,
      sub: `Growing ~${Math.round(equityPerMonth / 1000)}K/month`,
      detail: "Your database holds millions in equity that hasn't been unlocked yet. Every month you wait, your contacts build equity but so do competing agents who outreach first.",
    },
    {
      icon: "📅", title: "Listing Window",
      value: "Mar to May optimal",
      sub: "Based on 3yr seasonal data",
      detail: "Historical data shows autumn is the strongest listing window for the SE corridor: 12% more transactions and 4% higher clearance rates than winter. You're in the window now.",
    },
    {
      icon: "⏰", title: "CGT Deadline",
      value: `${DAYS_TO_CGT} days left`,
      sub: "50% discount · closes Jul 2027",
      detail: `${cgtContacts} of your contacts qualify for the 50% CGT discount, but only if they sell before 1 July 2027. That's ${DAYS_TO_CGT} days. Every week of delay costs them real money.`,
    },
    {
      icon: "🎙️", title: "Voice Intel Engine",
      value: "Record → AI extracts",
      sub: "Personalisation in 10 seconds",
      detail: "Speak a quick note about any contact on your phone ('Jason's tenant just moved out, he seemed frustrated about the vacancy'). AI extracts the personalisation hook and writes the outreach for you.",
    },
    {
      icon: "💬", title: "Smart Reply AI",
      value: "Vendor replied? AI drafts it",
      sub: "Context-aware follow-up",
      detail: "When a vendor responds to your outreach, PropOS reads the reply and drafts a perfect follow-up that continues the conversation naturally. Matches your voice, references their specific response.",
    },
    {
      icon: "📄", title: "One-Click Appraisal PDF",
      value: "Branded · 2 pages · instant",
      sub: "Comps + equity waterfall",
      detail: "Generate a print-quality, branded appraisal report for any contact in one click. Includes suburb comps, your estimated value range, equity scenarios, and CGT savings. Leave-behind for listing presentations.",
    },
    {
      icon: "📡", title: "Pre-Market Alert Network",
      value: `${highPriority} buyers → VIP access`,
      sub: "Tell them before portals",
      detail: "Your top-priority past buyers become VIP buyers for new listings in their preferred suburb. Send a pre-market alert 48 hours before Domain/REA. Builds loyalty and creates FOMO that accelerates offers.",
    },
    {
      icon: "🤝", title: "AI Negotiation Coach",
      value: "First-call script, personalised",
      sub: "Handles every objection",
      detail: "For each contact you're about to call, PropOS prepares a personalised call script: opening line based on their CRM notes, three pitch angles from their financial position, and responses to the top 5 objections.",
    },
  ]

  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ fontSize: 10, fontWeight: 800, color: C.faint, letterSpacing: 1.4, textTransform: "uppercase", marginBottom: 10 }}>
        AI Intelligence Suite
      </div>
      <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 8 }}>
        {WOW_ITEMS.map((item, i) => (
          <motion.div
            key={item.title}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setActiveIdx(activeIdx === i ? null : i)}
            style={{
              flexShrink: 0, width: 140, borderRadius: 14, padding: "14px 14px",
              background: activeIdx === i ? `linear-gradient(140deg, ${theme.primary}20, ${theme.primary}08)` : C.bg3,
              border: `1.5px solid ${activeIdx === i ? theme.primary + "60" : C.border}`,
              cursor: "pointer",
              boxShadow: activeIdx === i ? `0 0 18px ${theme.primary}18` : "none",
              transition: "border 0.15s, box-shadow 0.15s",
            }}
          >
            <div style={{ fontSize: 22, marginBottom: 6 }}>{item.icon}</div>
            <div style={{ fontSize: 11, fontWeight: 800, color: C.text, marginBottom: 3, lineHeight: 1.2 }}>{item.title}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: theme.primary }}>{item.value}</div>
            <div style={{ fontSize: 9, color: C.faint, marginTop: 2 }}>{item.sub}</div>
          </motion.div>
        ))}
      </div>

      {/* Expanded detail for selected item */}
      <AnimatePresence>
        {activeIdx !== null && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }}
            style={{ overflow: "hidden" }}
          >
            <div style={{
              marginTop: 10, background: `${theme.primary}08`, borderRadius: 12,
              border: `1px solid ${theme.primary}25`, padding: "14px 18px",
            }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginBottom: 6 }}>
                {WOW_ITEMS[activeIdx].icon} {WOW_ITEMS[activeIdx].title}
              </div>
              <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.6 }}>
                {WOW_ITEMS[activeIdx].detail}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── Vendor Profile Page ───────────────────────────────────────────────────────

function VendorProfilePage({ entry, agent, theme, onBack, onReview }: {
  entry: SegmentedBuyer
  agent: AgentProfile
  theme: AgencyTheme
  onBack: () => void
  onReview: (sms: string, emailSubject: string, emailBody: string[]) => void
}) {
  const [generating, setGenerating] = useState(false)
  const [overrideValue, setOverrideValue] = useState<number | null>(null)
  const [editingValue, setEditingValue] = useState(false)
  const [editValueInput, setEditValueInput] = useState("")
  const [voiceNotes, setVoiceNotes] = useState("")  // appended to CRM notes for generation
  const [showNegotiationCoach, setShowNegotiationCoach] = useState(false)
  const [showPrintAppraisal, setShowPrintAppraisal] = useState(false)
  // NotesBridge: populated from API response after generation
  const [extractedHook, setExtractedHook] = useState<string | null>(null)
  const [personalisationLine, setPersonalisationLine] = useState<string | null>(null)

  // Voice memo — lets agent dictate extra context about this contact before generating
  const vendorVoice = useVoiceMemo({
    onTranscript: (t) => setVoiceNotes(prev => prev ? prev + " " + t : t),
  })

  const { buyer, segment } = entry
  const pl = PIPELINE_LABELS[segment.pipeline]
  const fname = buyer.name.split("&")[0].split(" ")[0].trim()
  const agentFirst = agent.name.split(" ")[0]

  // Is this a secondary (not-yet-ready) contact? Show relationship strategies instead of just generate.
  const isSecondary = segment.pipeline === "renter-to-buyer" || segment.pipeline === "investor-to-rebalance"
    || (segment.pipeline === "owner-to-seller" && segment.confidence < 50)

  // Recalculate financials if user has overridden the value estimate
  const fin = overrideValue !== null
    ? calculateFinancials(buyer.purchasePrice, buyer.purchaseDate, overrideValue, buyer.deposit)
    : entry.financials

  const stripDashes = (s: string) => s.replace(/—|–|--/g, ",").replace(/ {2,}/g, " ").trim()

  const startEditValue = () => {
    setEditValueInput(String(fin.currentEstimate))
    setEditingValue(true)
  }
  const commitEditValue = () => {
    const n = parseInt(editValueInput.replace(/\D/g, ""), 10)
    if (!isNaN(n) && n > 0) setOverrideValue(n)
    setEditingValue(false)
  }

  const handleGenerate = async () => {
    setGenerating(true)

    const triggerSummary = segment.triggers.map(t => t.label).join("; ")

    // Find comparable recent sales in same suburb from agent's portfolio
    const { sold: agentSoldProps } = getPortfolioForAgent(agent)
    const suburbComps = agentSoldProps
      .filter(p => p.suburb.toLowerCase() === buyer.suburb.toLowerCase() && p.soldDate)
      .slice(0, 2)
      .map(p => `${p.address}, ${p.suburb}: sold ${fmt(p.price)} (${p.soldDate})`)

    const payload = {
      agentName: agent.name,
      agentAgency: agent.agency,
      agentPhone: agent.phone,
      voiceContext: buildVoiceContext(agent.voiceProfile, loadCorpus()),
      buyerName: buyer.name,
      buyerPhone: buyer.phone,
      buyerStatus: buyer.status,
      purchaseAddress: buyer.purchaseAddress,
      suburb: buyer.suburb,
      purchaseYear: buyer.purchaseDate.slice(0, 4),
      purchasePrice: fin.purchasePrice,
      currentEstimate: fin.currentEstimate,
      equityGain: fin.equityGain,
      equityGainPct: fin.equityGainPct,
      yearsHeld: fin.yearsHeld,
      annualAppreciation: fin.annualAppreciation,
      cashOnCashReturn: fin.cashOnCashReturn,
      cgtSavingsBy2027: fin.cgtSavingsBy2027,
      netProceeds: fin.netProceeds,
      pipelineLabel: pl.label,
      triggerSummary,
      // Combine base CRM notes with any voice-dictated notes from this session
      crmNotes: [buyer.notes ?? "", voiceNotes].filter(Boolean).join("\n\nVoice note: "),
      soldComps: suburbComps.join("; "),
      // Sheet col R: if agent pre-wrote the hook, send it directly (bypasses OpenAI extraction)
      parsedPersonalisation: (buyer as { personalisationHook?: string }).personalisationHook ?? undefined,
    }

    // Template fallback
    const templateFallback = () => {
      const addr = shortAddr(buyer.purchaseAddress)
      const estStr = fmtDollar(fin.currentEstimate)
      const equityStr = fmtDollar(fin.equityGain)
      const signoff = buyer.status === "investor" ? "Kind regards" : "Cheers"
      const smsRaw = `Hi ${fname}, ${agentFirst} from ${agent.agency}. ${addr} is now worth ~${estStr} (${equityStr} equity since ${payload.purchaseYear}). Worth a quick chat? ${signoff}, ${agentFirst}`
      const sms = stripDashes(smsRaw.length > 160 ? smsRaw.slice(0, 157) + "..." : smsRaw)
      const emailSubject = stripDashes(`Market update on ${buyer.purchaseAddress}, ${fname}`)
      const cgtLine = fin.cgtSavingsBy2027 > 0 ? ` The current 50% CGT discount saves you approximately ${fmtDollar(fin.cgtSavingsBy2027)} if you sell before July 2027.` : ""
      const emailBody = [
        `Hi ${fname}, ${agentFirst} from ${agent.agency} here. Quick update on ${buyer.suburb}.`,
        `Your property at ${buyer.purchaseAddress} has grown to approximately ${estStr} since you purchased in ${payload.purchaseYear}. That is ${equityStr} in equity.${cgtLine}`,
        `I would love to offer a complimentary, no-obligation appraisal if you are curious. Takes about 20 minutes, happy to come to you. No pressure at all.\n\n${signoff},\n${agentFirst}`,
      ].map(stripDashes)
      setGenerating(false)
      onReview(sms, emailSubject, emailBody)
    }

    try {
      const res = await Promise.race([
        fetch(apiUrl("/api/vendor-generate"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }).then(r => r.json()),
        new Promise<never>((_, reject) => setTimeout(() => reject(new Error("timeout")), 14000)),
      ]) as {
        sms?: string
        email?: { subject?: string; body?: string[] }
        personalisationHook?: string | null
        personalisationLine?: string | null
      }

      const sms = res.sms ?? ""
      const emailSubject = res.email?.subject ?? ""
      const emailBody: string[] = res.email?.body ?? []
      if (!sms && !emailSubject) throw new Error("empty")

      // Capture NotesBridge data — show the transformation BEFORE navigating to review
      if (res.personalisationHook) setExtractedHook(res.personalisationHook)
      if (res.personalisationLine) setPersonalisationLine(res.personalisationLine)

      setGenerating(false)

      // Pause so the user sees the NotesBridge "What AI saw → As written to" animation
      // before the review screen replaces the page (3.5s = typewriter + moment to read)
      await new Promise(r => setTimeout(r, res.personalisationLine ? 3500 : 400))
      onReview(stripDashes(sms), stripDashes(emailSubject), emailBody.map(stripDashes))
    } catch {
      templateFallback()
    }
  }

  const equityPct = Math.round((fin.equityGain / fin.purchasePrice) * 100)
  const equityBarWidth = Math.min(equityPct, 100)

  // Comparable sales + range — used by angle-based outreach picker
  const comps = generateComparables({ suburb: buyer.suburb, propertyType: buyer.propertyType as "House"|"Unit"|"Townhouse", beds: buyer.beds, land: buyer.land ?? 500, buyerId: buyer.id })
  const range = buildAppraisalRange(comps, buyer.suburb)

  return (
    <div style={{ maxWidth: 1020, margin: "0 auto", padding: "88px 28px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{ background: "transparent", border: "none", cursor: "pointer", color: theme.primary, fontSize: 18, marginBottom: 20, padding: 0 }}>←</button>

      <div style={{ display: "flex", gap: 28 }}>
        {/* LEFT — Contact details + financial snapshot */}
        <div style={{ flex: "0 0 58%", display: "flex", flexDirection: "column", gap: 18 }}>

          {/* Identity card */}
          <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: C.text, letterSpacing: -0.5 }}>{buyer.name}</div>
              <div style={{
                fontSize: 10, padding: "3px 10px", borderRadius: 8,
                background: pl.color + "18", color: pl.color, fontWeight: 700,
              }}>
                {pl.icon} {pl.label}
              </div>
            </div>
            <div style={{ fontSize: 13, color: theme.primary, fontWeight: 600, marginBottom: 14 }}>
              {buyer.purchaseAddress}, {buyer.suburb}
            </div>
            <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
              {[
                { label: "Purchased", value: buyer.purchaseDate.slice(0, 4) },
                { label: "Purchase price", value: fmtDollar(buyer.purchasePrice) },
                { label: "Hold period", value: `${fin.yearsHeld} yrs` },
                { label: "Type", value: `${buyer.beds}bd ${buyer.baths}ba ${buyer.propertyType}` },
                buyer.land ? { label: "Land", value: `${buyer.land}sqm` } : null,
                { label: "Status", value: formatBuyerStatus(buyer.status) },
              ].filter(Boolean).map(item => (
                <div key={item!.label}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 2 }}>{item!.label}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{item!.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Financial Snapshot */}
          <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted, textTransform: "uppercase", marginBottom: 16 }}>
              Financial snapshot
            </div>

            {/* Equity bar */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <span style={{ fontSize: 12, color: C.muted }}>Purchased {fmtDollar(fin.purchasePrice)}</span>
                {editingValue ? (
                  <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                    <input
                      autoFocus
                      value={editValueInput}
                      onChange={e => setEditValueInput(e.target.value)}
                      onBlur={commitEditValue}
                      onKeyDown={e => { if (e.key === "Enter") commitEditValue(); if (e.key === "Escape") setEditingValue(false) }}
                      style={{
                        width: 110, padding: "3px 8px", background: C.bg3, border: `1px solid ${theme.primary}`,
                        borderRadius: 6, color: C.text, fontSize: 12, fontFamily: FONT,
                      }}
                    />
                  </div>
                ) : (
                  <button
                    onClick={startEditValue}
                    title="Click to override estimate"
                    style={{
                      background: "transparent", border: "none", cursor: "pointer", padding: 0,
                      display: "flex", alignItems: "center", gap: 4,
                    }}
                  >
                    <span style={{ fontSize: 12, color: C.green, fontWeight: 700 }}>Now {fmtDollar(fin.currentEstimate)}</span>
                    {overrideValue && <span style={{ fontSize: 9, color: theme.primary, background: theme.primary + "18", padding: "1px 5px", borderRadius: 4 }}>custom</span>}
                    <span style={{ fontSize: 9, color: C.faint }}>✏️</span>
                  </button>
                )}
              </div>
              <div style={{ height: 10, background: C.bg3, borderRadius: 6, overflow: "hidden" }}>
                <div style={{
                  height: "100%", borderRadius: 6, width: `${equityBarWidth}%`,
                  background: `linear-gradient(90deg, ${theme.gradient[0]}, ${C.green})`,
                  transition: "width 0.8s ease",
                }} />
              </div>
              <div style={{ fontSize: 11, color: C.faint, marginTop: 4, textAlign: "right" }}>
                {fmtPct(fin.equityGainPct)} equity growth ({fmtPct(fin.annualAppreciation)} p.a.)
              </div>
            </div>

            {/* Key metrics grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {[
                { label: "Equity gain", value: fmtDollar(fin.equityGain), color: C.green },
                { label: "Est. current value", value: fmtDollar(fin.currentEstimate), color: C.text },
                { label: "Annual growth", value: fmtPct(fin.annualAppreciation), color: C.blue },
                fin.cashOnCashReturn ? { label: "Cash-on-cash return", value: `${fin.cashOnCashReturn}%`, color: C.green } : null,
                fin.cgtDiscount ? { label: "Est. CGT (50% disc.)", value: fmtDollar(fin.estimatedCGT), color: C.orange } : null,
                fin.cgtSavingsBy2027 > 0 ? { label: "CGT savings by Jul 2027", value: fmtDollar(fin.cgtSavingsBy2027), color: C.red ?? "#ef4444" } : null,
                { label: "Selling costs (est.)", value: fmtDollar(fin.sellingCosts), color: C.muted },
                { label: "Net proceeds (est.)", value: fmtDollar(fin.netProceeds), color: C.green },
              ].filter(Boolean).map(m => (
                <div key={m!.label} style={{
                  background: C.bg3, borderRadius: 10, padding: "10px 12px",
                  border: `1px solid ${C.border}`,
                }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 4 }}>{m!.label}</div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: m!.color }}>{m!.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Vendor Appraisal */}
          <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
            <VendorAppraisalPanel buyer={buyer} theme={theme} />
            <div style={{ marginTop: 14, display: "flex", justifyContent: "flex-end" }}>
              <button onClick={() => setShowPrintAppraisal(true)}
                style={{ padding: "8px 16px", borderRadius: 10, border: `1px solid ${theme.primary}40`, background: `${theme.primary}10`, color: theme.primary, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: FONT, display: "flex", alignItems: "center", gap: 6 }}>
                🖨️ Print Appraisal Report
              </button>
            </div>
          </div>

          {/* CRM Notes + Voice Memo Recorder */}
          <div style={{ background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`, padding: "14px 18px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, letterSpacing: 1, textTransform: "uppercase" }}>CRM Notes</div>
              {/* Voice memo button */}
              {vendorVoice.supported && (
                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                  {vendorVoice.phase === "idle" && (
                    <button
                      onClick={vendorVoice.start}
                      style={{
                        fontSize: 10, fontWeight: 700, padding: "3px 10px", borderRadius: 6,
                        background: theme.primary + "15", color: theme.primary,
                        border: `1px solid ${theme.primary}30`, cursor: "pointer", fontFamily: FONT,
                        display: "flex", alignItems: "center", gap: 4,
                      }}
                    >
                      🎙️ Add voice note
                    </button>
                  )}
                  {vendorVoice.phase === "recording" && (
                    <button
                      onClick={vendorVoice.stop}
                      style={{
                        fontSize: 10, fontWeight: 700, padding: "3px 10px", borderRadius: 6,
                        background: "#ef444420", color: "#ef4444",
                        border: "1px solid #ef444440", cursor: "pointer", fontFamily: FONT,
                        display: "flex", alignItems: "center", gap: 4,
                      }}
                    >
                      <motion.span animate={{ opacity: [1, 0] }} transition={{ duration: 0.6, repeat: Infinity }}>●</motion.span>
                      Stop ({vendorVoice.seconds}s)
                    </button>
                  )}
                  {vendorVoice.phase === "done" && (
                    <button onClick={vendorVoice.reset} style={{
                      fontSize: 10, color: C.faint, background: "none", border: "none", cursor: "pointer",
                    }}>Reset</button>
                  )}
                </div>
              )}
            </div>
            {buyer.notes && <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.55 }}>{buyer.notes}</div>}
            {/* Live transcript while recording */}
            {vendorVoice.phase === "recording" && vendorVoice.liveTranscript && (
              <div style={{ fontSize: 12, color: theme.primary, fontStyle: "italic", marginTop: 8, padding: "8px 10px", background: theme.primary + "0a", borderRadius: 6, lineHeight: 1.5 }}>
                🎙️ {vendorVoice.liveTranscript}
              </div>
            )}
            {/* Saved voice notes */}
            {voiceNotes && (
              <div style={{ fontSize: 12, color: C.text, marginTop: 8, padding: "8px 10px", background: theme.primary + "10", borderRadius: 6, lineHeight: 1.5, border: `1px solid ${theme.primary}20` }}>
                <span style={{ fontSize: 9, fontWeight: 700, color: theme.primary, textTransform: "uppercase", letterSpacing: 0.8 }}>🎙️ Voice note added · feeds into AI generation</span>
                <div style={{ marginTop: 4, color: C.muted }}>{voiceNotes}</div>
                {/* AI Brief parsed from voice */}
                <VoiceBriefCard transcript={voiceNotes} buyerName={buyer.name} buyerSuburb={buyer.suburb} theme={theme} />
              </div>
            )}
          </div>

          {/* Nurture Sequence Panel */}
          <NurtureSequencePanel entry={entry} agent={agent} theme={theme} />
        </div>

        {/* RIGHT — Triggers + pitch angles + generate */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 16 }}>

          {/* ⚡ NotesBridge — CRM notes → AI extraction → outreach sentence */}
          {buyer.notes && (
            <NotesBridgeCard
              notes={buyer.notes}
              prewrittenHook={(buyer as { personalisationHook?: string }).personalisationHook ?? null}
              extractedHook={extractedHook}
              personalisationLine={personalisationLine}
              fname={fname}
              generating={generating}
              theme={theme}
            />
          )}

          {/* Trigger events */}
          <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted, textTransform: "uppercase", marginBottom: 14 }}>
              Trigger events
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {segment.triggers.map((t, i) => {
                const uColor = t.urgency === "high" ? (C.red ?? "#ef4444") : t.urgency === "medium" ? C.orange : C.faint
                return (
                  <div key={i} style={{
                    display: "flex", gap: 10, padding: "10px 12px", borderRadius: 10,
                    background: uColor + "10", border: `1px solid ${uColor}25`,
                  }}>
                    <span style={{
                      fontSize: 8, fontWeight: 800, color: uColor, textTransform: "uppercase",
                      background: uColor + "20", padding: "2px 6px", borderRadius: 4, alignSelf: "flex-start",
                    }}>{t.urgency}</span>
                    <span style={{ fontSize: 12, color: C.muted, lineHeight: 1.4 }}>{t.label}</span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* AI pitch angles */}
          {segment.pitchAngles.length > 0 && (
            <div style={{ background: C.bg2, borderRadius: 16, border: `1px solid ${C.border}`, padding: "20px 24px" }}>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: C.muted, textTransform: "uppercase", marginBottom: 14 }}>
                Pitch angles for {fname}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {segment.pitchAngles.map((angle, i) => (
                  <div key={i} style={{
                    display: "flex", gap: 10, padding: "10px 12px", borderRadius: 10,
                    background: C.bg3, border: `1px solid ${C.border}`,
                  }}>
                    <span style={{ fontSize: 16, flexShrink: 0 }}>💡</span>
                    <span style={{ fontSize: 12, color: C.muted, lineHeight: 1.45 }}>{angle}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Secondary buyer engagement strategies */}
          {isSecondary && <SecondaryEngagementCard entry={entry} theme={theme} />}

          {/* Negotiation Coach button */}
          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }} onClick={() => setShowNegotiationCoach(true)}
            style={{ width: "100%", padding: "12px", borderRadius: 12, border: `1px solid ${theme.primary}40`, background: `${theme.primary}10`, color: theme.primary, fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: FONT, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            🤝 Negotiation Coach: call script for {fname}
          </motion.button>

          {/* Contact info */}
          <div style={{ background: C.bg2, borderRadius: 14, border: `1px solid ${C.border}`, padding: "16px 20px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 }}>Contact</div>
            <a href={`tel:${buyer.phone}`} style={{ fontSize: 14, color: theme.primary, fontWeight: 600, textDecoration: "none", display: "block", marginBottom: 6 }}>{buyer.phone}</a>
            {buyer.email && <a href={`mailto:${buyer.email}`} style={{ fontSize: 13, color: theme.primary, fontWeight: 600, textDecoration: "none" }}>{buyer.email}</a>}
            {buyer.lastContactDate && (
              <div style={{ fontSize: 10, color: C.faint, marginTop: 8 }}>
                Last contacted: {buyer.lastContactDate}
              </div>
            )}
            {buyer.lastMessage && (
              <div style={{ fontSize: 10, color: C.faint, marginTop: 4, fontStyle: "italic", lineHeight: 1.4 }}>
                "{buyer.lastMessage.slice(0, 120)}{buyer.lastMessage.length > 120 ? "…" : ""}"
              </div>
            )}
          </div>

          {/* Voice note hint if none recorded yet */}
          {!voiceNotes && vendorVoice.phase === "idle" && (
            <div style={{ textAlign: "center", fontSize: 10, color: C.faint }}>
              🎙️ Tap "Add voice note" in CRM Notes above to enrich AI personalisation
            </div>
          )}

          {/* Angle-based outreach picker */}
          {(() => {
            const year = buyer.purchaseDate.slice(0, 4)
            const signoff = buyer.status === "investor" ? "Kind regards" : "Cheers"

            const angles = [
              // CGT Deadline — only if meaningful tax savings
              fin.cgtSavingsBy2027 > 5000 && {
                id: "cgt",
                icon: "⏰",
                title: "CGT Deadline",
                hook: `Save ${fmtDollar(fin.cgtSavingsBy2027)} in tax`,
                sub: "Before July 2027 cutoff",
                color: "#ef4444",
                buildOutreach: () => {
                  const smsRaw = `Hi ${fname}, ${agentFirst} from ${agent.agency}. Selling before July 2027 saves you ~${fmtDollar(fin.cgtSavingsBy2027)} in tax. Happy to run the numbers. ${signoff}, ${agentFirst}`
                  const sms = stripDashes(smsRaw.slice(0, 160))
                  const emailSubject = `Your CGT window, ${fname}`
                  const emailBody = [
                    `Hi ${fname}, ${agentFirst} from ${agent.agency} here. Quick one on your numbers at ${shortAddr(buyer.purchaseAddress)}.`,
                    `You've held your place since ${year} and the 50% CGT discount applies right now. Selling before 1 July 2027 saves you roughly ${fmtDollar(fin.cgtSavingsBy2027)} in tax compared to waiting. Your place is estimated at around ${fmtDollar(fin.currentEstimate)}.`,
                    `Happy to do a quick no-obligation appraisal. Twenty minutes, I'll come to you. No pressure at all.\n\n${signoff},\n${agentFirst}`,
                  ].map(stripDashes)
                  return { sms, emailSubject, emailBody }
                },
              },
              // Equity Position — always show if meaningful
              fin.equityGain > 100000 && {
                id: "equity",
                icon: "💰",
                title: "Equity Position",
                hook: `${fmtDollar(fin.equityGain)} in equity`,
                sub: `Built since ${year}`,
                color: "#66bb6a",
                buildOutreach: () => {
                  const smsRaw = `Hi ${fname}, ${agentFirst} from ${agent.agency}. Your place has grown ${fmtDollar(fin.equityGain)} since ${year}. Worth knowing your options. ${signoff}, ${agentFirst}`
                  const sms = stripDashes(smsRaw.slice(0, 160))
                  const emailSubject = `Your equity position, ${fname}`
                  const emailBody = [
                    `Hi ${fname}, ${agentFirst} from ${agent.agency} here.`,
                    `Ran the numbers on your place at ${shortAddr(buyer.purchaseAddress)}. You've built roughly ${fmtDollar(fin.equityGain)} in equity since ${year}. Your property is sitting at around ${fmtDollar(fin.currentEstimate)} now. A lot of people in ${buyer.suburb} don't realise what position they're in.`,
                    `Happy to do a complimentary appraisal. Twenty minutes, I'll come to you. No obligation, just so you know your options.\n\n${signoff},\n${agentFirst}`,
                  ].map(stripDashes)
                  return { sms, emailSubject, emailBody }
                },
              },
              // Recent comparable sale — from top comp
              {
                id: "comps",
                icon: "🏡",
                title: "Recent Sale",
                hook: `${comps[0].address}: ${fmtDollar(comps[0].soldPrice)}`,
                sub: comps[0].soldDate,
                color: "#ffa726",
                buildOutreach: () => {
                  const smsRaw = `Hi ${fname}, ${agentFirst} here. A ${comps[0].beds}-bed in ${buyer.suburb} just sold for ${fmtDollar(comps[0].soldPrice)}. Your place stacks up really well. ${signoff}, ${agentFirst}`
                  const sms = stripDashes(smsRaw.slice(0, 160))
                  const emailSubject = `Recent ${buyer.suburb} sale relevant to your place, ${fname}`
                  const emailBody = [
                    `Hi ${fname}, ${agentFirst} from ${agent.agency} here.`,
                    `A comparable ${comps[0].beds}-bedroom property at ${comps[0].address} just sold for ${fmtDollar(comps[0].soldPrice)} on ${comps[0].soldDate}. That puts your place — bought for ${fmtDollar(buyer.purchasePrice)} in ${year} — in a really strong position at roughly ${fmtDollar(fin.currentEstimate)}.`,
                    `Happy to put together a quick comps report and walk you through it. No obligation at all. Let me know if it's worth a look.\n\n${signoff},\n${agentFirst}`,
                  ].map(stripDashes)
                  return { sms, emailSubject, emailBody }
                },
              },
              // Market Timing — suburb conditions
              {
                id: "timing",
                icon: "📈",
                title: "Market Timing",
                hook: `${range.clearanceRate}% clearance rate`,
                sub: `Avg ${range.daysOnMarket} days on market`,
                color: theme.primary,
                buildOutreach: () => {
                  const smsRaw = `Hi ${fname}, ${agentFirst} here — ${buyer.suburb} is running at ${range.clearanceRate}% clearance. Good time to know your options. ${signoff}, ${agentFirst}`
                  const sms = stripDashes(smsRaw.slice(0, 160))
                  const emailSubject = `${buyer.suburb} market is moving, ${fname}`
                  const emailBody = [
                    `Hi ${fname}, ${agentFirst} from ${agent.agency} here. Quick update on ${buyer.suburb}.`,
                    `Clearance rate is at ${range.clearanceRate}% with properties averaging just ${range.daysOnMarket} days on market. Strong seller conditions. Based on recent sales, your place is estimated at around ${fmtDollar(fin.currentEstimate)} — that's ${fmtDollar(fin.equityGain)} up since you bought in ${year}.`,
                    `If you've had any thoughts about listing, it's a decent window. Happy to do a quick appraisal — 20 minutes, I'll come to you. No pressure at all.\n\n${signoff},\n${agentFirst}`,
                  ].map(stripDashes)
                  return { sms, emailSubject, emailBody }
                },
              },
            ].filter(Boolean) as Array<{ id: string; icon: string; title: string; hook: string; sub: string; color: string; buildOutreach: () => { sms: string; emailSubject: string; emailBody: string[] } }>

            return (
              <div>
                <div style={{ fontSize: 10, fontWeight: 700, color: C.faint, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10 }}>
                  Choose an outreach angle
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  {angles.map(angle => (
                    <motion.button
                      key={angle.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        const { sms, emailSubject, emailBody } = angle.buildOutreach()
                        onReview(sms, emailSubject, emailBody)
                      }}
                      style={{
                        background: `${angle.color}12`,
                        border: `1.5px solid ${angle.color}40`,
                        borderRadius: 12, padding: "12px 14px",
                        cursor: "pointer", textAlign: "left", fontFamily: FONT,
                      }}
                    >
                      <div style={{ fontSize: 18, marginBottom: 5 }}>{angle.icon}</div>
                      <div style={{ fontSize: 11, fontWeight: 800, color: C.text, marginBottom: 2, letterSpacing: -0.2 }}>{angle.title}</div>
                      <div style={{ fontSize: 12, fontWeight: 700, color: angle.color, lineHeight: 1.3 }}>{angle.hook}</div>
                      <div style={{ fontSize: 10, color: C.faint, marginTop: 2 }}>{angle.sub}</div>
                    </motion.button>
                  ))}
                </div>
                <div style={{ textAlign: "center", fontSize: 10, color: C.faint, marginTop: 8 }}>
                  {voiceNotes ? "✅ Voice note included · tap an angle to generate" : "Tap an angle · SMS + email in your voice, instantly"}
                </div>
                <motion.button whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.98 }} onClick={handleGenerate} disabled={generating}
                  style={{ width: "100%", marginTop: 8, padding: "10px 14px", borderRadius: 12, border: `1px solid ${theme.primary}30`, background: `${theme.primary}08`, color: generating ? C.faint : theme.primary, fontSize: 12, fontWeight: 700, cursor: generating ? "default" : "pointer", fontFamily: FONT }}>
                  {generating ? "✨ Generating AI outreach..." : "✨ Generate with AI (full personalisation)"}
                </motion.button>
              </div>
            )
          })()}
        </div>
      </div>

      {/* Negotiation Coach Modal */}
      <AnimatePresence>
        {showNegotiationCoach && <NegotiationCoachModal entry={entry} agent={agent} theme={theme} onClose={() => setShowNegotiationCoach(false)} />}
      </AnimatePresence>

      {/* Printable Appraisal Modal */}
      <AnimatePresence>
        {showPrintAppraisal && <PrintableAppraisalModal entry={entry} agent={agent} theme={theme} onClose={() => setShowPrintAppraisal(false)} />}
      </AnimatePresence>
    </div>
  )
}

// ── Vendor Review Panel ───────────────────────────────────────────────────────

function VendorReviewPanel({ entry, agent, theme, sms: initSMS, emailSubject: initSubject, emailBody: initBody, onBack }: {
  entry: SegmentedBuyer
  agent: AgentProfile
  theme: AgencyTheme
  sms: string
  emailSubject: string
  emailBody: string[]
  onBack: () => void
}) {
  const [sms, setSMS] = useState(initSMS)
  const [subject, setSubject] = useState(initSubject)
  const [bodyText, setBodyText] = useState(initBody.join("\n\n"))
  const [editMode, setEditMode] = useState<"sms" | "email" | null>(null)
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)
  const [sendingToSelf, setSendingToSelf] = useState(false)
  const [sentToSelf, setSentToSelf] = useState(false)
  const [deliveryNote, setDeliveryNote] = useState("")
  const [appraisalBooked, setAppraisalBooked] = useState(false)
  const [showNurture, setShowNurture] = useState(false)

  const { buyer, financials: fin, segment } = entry
  const pl = PIPELINE_LABELS[segment.pipeline]
  const fname = buyer.name.split("&")[0].split(" ")[0].trim()
  const bubbleColor = theme?.primary ?? "rgb(0,122,255)"
  const avatarGrad = `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`

  const handleSend = async () => {
    setSending(true)
    try {
      const deliveryRes = await fetch(apiUrl("/api/send"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: `vendor_${buyer.id}`,
          leadName: buyer.name,
          phone: buyer.phone,
          email: buyer.email ?? "",
          agentEmail: agent.email,
          agentName: agent.name,
          agentAgency: agent.agency,
          agentPhone: agent.phone,
          agencyColor: theme.primary,
          agencyTagline: agent.tagline,
          propertyAddress: `${buyer.purchaseAddress}, ${buyer.suburb}`,
          priceGuide: fmtDollar(fin.currentEstimate),
          sms, subject,
          emailBody: bodyText.split("\n\n").filter(p => p.trim()).join("\n\n"),
          channel: "both",
          pipeline: segment.pipeline,
          nurtureContext: {
            agentName: agent.name,
            agentAgency: agent.agency,
            agentEmail: agent.email,
            agentPhone: agent.phone,
            agencyColor: theme.primary,
            agencyTagline: agent.tagline,
            pipeline: segment.pipeline,
          },
        }),
      }).then(r => r.json()).catch(() => null)
      const delivered = deliveryRes?.ok === true
      setDeliveryNote(delivered ? "Sent via Twilio + Gmail" : "Saved to Sheets (configure Twilio/Gmail for direct delivery)")

      // Write today's date + last message back to the Past Buyers sheet tab
      await updateLastContactDate(buyer.id, undefined, sms || bodyText.split("\n\n")[0]?.slice(0, 200))
    } catch {}
    setSending(false)
    setSent(true)
  }

  const handleSendToSelf = async () => {
    setSendingToSelf(true)
    try {
      await fetch(apiUrl("/api/send"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadId: "self_demo",
          leadName: "Yourself (demo)",
          phone: agent.phone,
          email: agent.email,
          agentEmail: agent.email,
          agentName: agent.name,
          agentAgency: agent.agency,
          agentPhone: agent.phone,
          agencyColor: theme.primary,
          agencyTagline: agent.tagline,
          propertyAddress: `${buyer.purchaseAddress}, ${buyer.suburb}`,
          priceGuide: fmtDollar(fin.currentEstimate),
          sms, subject,
          emailBody: bodyText.split("\n\n").filter(p => p.trim()).join("\n\n"),
          channel: "both",
        }),
      })
      setSentToSelf(true)
    } catch {}
    setSendingToSelf(false)
  }

  if (sent) {
    return (
      <div style={{
        minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center",
        padding: 24, fontFamily: FONT,
      }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          style={{ textAlign: "center", maxWidth: 520 }}
        >
          <div style={{ fontSize: 56, marginBottom: 16 }}>✓</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: C.text, letterSpacing: -0.5, marginBottom: 8 }}>
            Vendor outreach approved for {fname}
          </div>
          {deliveryNote && (
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 24, padding: "6px 14px",
              background: C.bg3, borderRadius: 8, display: "inline-block" }}>
              {deliveryNote}
            </div>
          )}
          <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
            <button onClick={onBack} style={{
              padding: "12px 28px", borderRadius: 12, border: "none",
              background: `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
              color: "white", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: FONT,
            }}>
              Back to pipeline
            </button>
            <a href={`tel:${buyer.phone}`} style={{
              padding: "12px 28px", borderRadius: 12, textDecoration: "none",
              border: `1px solid ${theme.primary}44`,
              color: theme.primary, fontSize: 14, fontWeight: 700, fontFamily: FONT,
            }}>
              📞 Call {fname} now
            </a>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: "80px 32px 48px", fontFamily: FONT }}>
      <button onClick={onBack} style={{
        background: "transparent", border: "none", cursor: "pointer",
        color: theme.primary, fontSize: 18, fontFamily: FONT,
        display: "flex", alignItems: "center", marginBottom: 24, padding: 0, lineHeight: 1,
      }}>←</button>

      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, color: theme.primary, textTransform: "uppercase", marginBottom: 4 }}>
          Review outreach
        </div>
        <div style={{ fontSize: 24, fontWeight: 800, color: C.text, letterSpacing: -0.8 }}>
          {fname}'s personalised vendor messages
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 6 }}>
          <div style={{ fontSize: 13, color: C.muted }}>{buyer.purchaseAddress}, {buyer.suburb}</div>
          <div style={{
            fontSize: 10, padding: "2px 8px", borderRadius: 6,
            background: pl.color + "18", color: pl.color, fontWeight: 700,
          }}>
            {pl.icon} {pl.shortLabel}
          </div>
          <div style={{ fontSize: 13, color: C.green, fontWeight: 600 }}>{fmtDollar(fin.equityGain)} equity</div>
        </div>
        <div style={{ fontSize: 13, color: C.muted, marginTop: 4 }}>
          Edit either message before approving. Clicking Send saves both to Google Sheets for delivery.
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 24 }}>
        {/* SMS — iMessage style */}
        <div>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            marginBottom: 10,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase" }}>SMS</div>
            <button onClick={() => setEditMode(editMode === "sms" ? null : "sms")} style={{
              background: "transparent", border: "none", cursor: "pointer",
              color: theme.primary, fontSize: 12, fontFamily: FONT, fontWeight: 600,
            }}>
              {editMode === "sms" ? "Done" : "Edit"}
            </button>
          </div>
          {editMode === "sms" ? (
            <textarea
              autoFocus
              value={sms}
              onChange={e => setSMS(e.target.value)}
              maxLength={160}
              style={{
                width: "100%", minHeight: 120, background: C.bg3,
                border: `1px solid ${theme.primary}44`, borderRadius: 12,
                padding: "12px 14px", color: C.text, fontSize: 13,
                fontFamily: FONT, lineHeight: 1.5, resize: "vertical", outline: "none",
                boxSizing: "border-box",
              }}
            />
          ) : (
            <div style={{ background: "rgb(24,24,24)", borderRadius: 20, padding: 16 }}>
              <div style={{ textAlign: "center", marginBottom: 12 }}>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>iMessage</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.9)" }}>{fname}</div>
              </div>
              <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                <div style={{
                  maxWidth: "80%", padding: "9px 13px",
                  borderRadius: "16px 16px 4px 16px",
                  background: bubbleColor,
                  fontSize: 13, color: "white", lineHeight: 1.45,
                }}>
                  {sms}
                </div>
                <div style={{
                  width: 30, height: 30, borderRadius: "50%",
                  background: avatarGrad,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 11, fontWeight: 700, color: "white", flexShrink: 0, alignSelf: "flex-end",
                }}>
                  {agent.name.charAt(0)}
                </div>
              </div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", textAlign: "right", marginTop: 6 }}>
                {sms.length}/160 chars
              </div>
            </div>
          )}
        </div>

        {/* Email — Gmail style */}
        <div>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            marginBottom: 10,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, letterSpacing: 1, textTransform: "uppercase" }}>Email</div>
            <button onClick={() => setEditMode(editMode === "email" ? null : "email")} style={{
              background: "transparent", border: "none", cursor: "pointer",
              color: theme.primary, fontSize: 12, fontFamily: FONT, fontWeight: 600,
            }}>
              {editMode === "email" ? "Done" : "Edit"}
            </button>
          </div>
          {editMode === "email" ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <input
                value={subject}
                onChange={e => setSubject(e.target.value)}
                placeholder="Subject line..."
                style={{
                  background: C.bg3, border: `1px solid ${theme.primary}44`,
                  borderRadius: 8, padding: "9px 12px", color: C.text,
                  fontSize: 13, fontFamily: FONT, outline: "none",
                }}
              />
              <textarea
                value={bodyText}
                onChange={e => setBodyText(e.target.value)}
                placeholder="Email body..."
                style={{
                  background: C.bg3, border: `1px solid ${theme.primary}44`,
                  borderRadius: 8, padding: "10px 12px", color: C.text,
                  fontSize: 13, fontFamily: FONT, lineHeight: 1.5,
                  resize: "vertical", minHeight: 160, outline: "none",
                }}
              />
            </div>
          ) : (
            <div style={{
              background: "white", borderRadius: 12, overflow: "hidden",
              boxShadow: "0 4px 24px rgba(0,0,0,0.3)",
            }}>
              <div style={{ background: "#f1f3f4", padding: "10px 16px", borderBottom: "1px solid #e0e0e0" }}>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 2 }}>
                  <span style={{ fontWeight: 500, color: "#333" }}>From: </span>{agent.email}
                </div>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 2 }}>
                  <span style={{ fontWeight: 500, color: "#333" }}>To: </span>{buyer.email ?? `${fname.toLowerCase()}@email.com`}
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#111", marginTop: 4 }}>{subject}</div>
              </div>
              <div style={{ padding: "16px 20px" }}>
                {bodyText.split("\n\n").filter(p => p.trim()).map((p, i, arr) => (
                  <p key={i} style={{ fontSize: 13, color: "#333", lineHeight: 1.6, marginBottom: i < arr.length - 1 ? 12 : 0 }}>{p}</p>
                ))}
                <div style={{
                  marginTop: 20, paddingTop: 16, borderTop: `2px solid ${theme.primary}`,
                  fontSize: 12, color: "#666",
                  display: "flex", gap: 10, alignItems: "center",
                }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                    background: avatarGrad,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 11, fontWeight: 800, color: "white",
                  }}>
                    {theme.logo}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: "#111", fontSize: 13 }}>{agent.name}</div>
                    <div style={{ color: theme.primary, fontWeight: 600 }}>{agent.agency}</div>
                    <div style={{ color: "#888", fontSize: 11 }}>{agent.email}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Approve and Send */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.97 }}
        onClick={handleSend}
        disabled={sending}
        style={{
          width: "100%", padding: "15px",
          borderRadius: 14, border: "none",
          background: sending ? C.bg3 : `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
          color: sending ? C.muted : "white",
          fontSize: 16, fontWeight: 700, cursor: sending ? "default" : "pointer",
          fontFamily: FONT, letterSpacing: -0.3,
          boxShadow: sending ? "none" : `0 6px 24px ${theme.glow}`,
        }}
      >
        {sending ? "Saving to Sheet..." : "Approve and Send"}
      </motion.button>
      <div style={{ textAlign: "center", fontSize: 11, color: C.faint, marginTop: 10 }}>
        Saves the approved SMS and email to Google Sheets for delivery via Twilio and Gmail.
      </div>

      <button
        onClick={handleSendToSelf}
        disabled={sendingToSelf || sentToSelf}
        style={{
          width: "100%", padding: "13px",
          borderRadius: 14, marginTop: 12,
          background: "transparent",
          border: `1px solid ${theme.primary}55`,
          color: sentToSelf ? C.green : theme.primary,
          fontSize: 14, fontWeight: 600, cursor: sendingToSelf || sentToSelf ? "default" : "pointer",
          fontFamily: FONT, letterSpacing: -0.2,
        }}
      >
        {sentToSelf ? "✓ Sent to your phone, check it now" : sendingToSelf ? "Sending..." : "📱 Send to my phone"}
      </button>
      <div style={{ textAlign: "center", fontSize: 11, color: C.faint, marginTop: 6 }}>
        Experience what your vendors feel
      </div>

      {/* Appraisal booked */}
      <div style={{ marginTop: 28, padding: "18px 20px", borderRadius: 14, background: C.bg2, border: `1px solid ${C.border}` }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.text, marginBottom: 10 }}>
          Did {fname} agree to an appraisal?
        </div>
        <button
          onClick={() => setAppraisalBooked(true)}
          disabled={appraisalBooked}
          style={{
            padding: "10px 20px", borderRadius: 10,
            border: `1px solid ${appraisalBooked ? C.green + "44" : theme.primary + "44"}`,
            background: appraisalBooked ? C.green + "22" : theme.dim,
            color: appraisalBooked ? C.green : theme.primary,
            fontSize: 13, fontWeight: 700, cursor: appraisalBooked ? "default" : "pointer",
            fontFamily: FONT,
          }}
        >
          {appraisalBooked ? "Appraisal booked" : "Mark appraisal booked"}
        </button>
        {appraisalBooked && (
          <div style={{ fontSize: 11, color: C.green, marginTop: 8 }}>
            Pipeline status updated. Follow up within 48 hrs to confirm time.
          </div>
        )}
      </div>

      {/* 30-day vendor nurture sequence */}
      <div style={{ marginTop: 20, padding: "18px 20px", borderRadius: 14, background: C.bg2, border: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>30-day vendor nurture sequence</div>
          <button onClick={() => setShowNurture(v => !v)} style={{
            background: "transparent", border: "none", cursor: "pointer",
            color: theme.primary, fontSize: 12, fontFamily: FONT, fontWeight: 600,
          }}>
            {showNurture ? "Hide" : "Preview →"}
          </button>
        </div>
        <div style={{ fontSize: 11, color: C.muted }}>
          Automated follow-up cadence if {fname} doesn't respond to your first outreach.
        </div>
        {showNurture && (() => {
          const nurtureSteps = [
            { day: 0,  label: "Day 0 — Initial outreach", color: theme.primary, note: "SMS + email sent (see above)" },
            { day: 7,  label: "Day 7 — Market pulse",    color: C.blue,
              sms: `Hi ${fname}, just a quick market update — a comparable home in ${buyer.suburb} sold well above guide this week. Worth a conversation? ${agent.name.split(" ")[0]}` },
            { day: 14, label: "Day 14 — Value reminder", color: C.green,
              sms: `Hi ${fname}, ${agent.name.split(" ")[0]} here. Equity in ${buyer.suburb} is up ${Math.round(fin.equityGainPct)}% since you bought — happy to run through the numbers if useful.` },
            { day: 30, label: "Day 30 — Soft close",     color: C.orange,
              sms: `Hi ${fname}, touching base on ${buyer.purchaseAddress.split(",")[0]}. If timing isn't right yet, no problem — happy to keep you updated on the market. ${agent.name.split(" ")[0]}` },
          ]
          return (
            <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 10 }}>
              {nurtureSteps.map(step => (
                <div key={step.day} style={{
                  padding: "12px 14px", borderRadius: 10,
                  background: C.bg3, border: `1px solid ${step.color}22`,
                }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: step.color, marginBottom: step.sms ? 6 : 0 }}>
                    {step.label}
                  </div>
                  {step.note && <div style={{ fontSize: 11, color: C.faint }}>{step.note}</div>}
                  {step.sms && (
                    <div style={{ fontSize: 12, color: C.muted, lineHeight: 1.5, fontStyle: "italic" }}>
                      "{step.sms}"
                    </div>
                  )}
                </div>
              ))}
            </div>
          )
        })()}
      </div>
    </div>
  )
}

// ── Main DemoView ─────────────────────────────────────────────────────────────

export default function DemoView({
  agent,
  theme = DEFAULT_THEME,
  mode = "buyer",
  onSettings,
  onRegisterBack,
  showInbox: showInboxProp,
  onShowInboxChange,
  onBadgeChange,
}: {
  agent: AgentProfile
  theme?: AgencyTheme
  mode?: DemoMode
  onSettings?: () => void
  onRegisterBack?: (fn: (() => void) | null) => void
  showInbox?: boolean
  onShowInboxChange?: (v: boolean) => void
  onBadgeChange?: (n: number) => void
}) {
  const homeStage: Stage = mode === "vendor" ? { kind: "vendorPortfolio" } : { kind: "portfolio" }
  const [stage, setStage] = useState<Stage>(homeStage)

  // Reset to home stage when mode switches (buyer ↔ vendor)
  useEffect(() => {
    setStage(mode === "vendor" ? { kind: "vendorPortfolio" } : { kind: "portfolio" })
  }, [mode])
  const [, setUnreadRepliesInternal] = useState(0)
  const setUnreadReplies = (n: number) => { setUnreadRepliesInternal(n); onBadgeChange?.(n) }
  const [showInboxInternal, setShowInboxInternal] = useState(false)
  const showInbox = showInboxProp ?? showInboxInternal
  const setShowInbox = (v: boolean) => { setShowInboxInternal(v); onShowInboxChange?.(v) }
  const [inboxThreads, setInboxThreads] = useState<Array<{ leadId: string; leadName: string; phone: string; propertyAddress: string; email: string; lastReplyAt: string; messages: Array<{ role: string; body: string; ts: string }> }>>([])
  const [selectedThreadPhone, setSelectedThreadPhone] = useState<string | null>(null)
  const [replyDraft, setReplyDraft] = useState<{ draft: string; intent: string; reasoning: string } | null>(null)
  const [replyText, setReplyText] = useState("")
  const [draftingReply, setDraftingReply] = useState(false)
  const [sendingReply, setSendingReply] = useState(false)
  const [seedingDemo, setSeedingDemo] = useState(false)

  // Poll for unread SMS replies every 30 seconds
  useEffect(() => {
    const poll = () => {
      fetch(apiUrl("/api/conversations"))
        .then(r => r.json())
        .then((d: { unread: number; threads: typeof inboxThreads }) => {
          setUnreadReplies(d.unread ?? 0)
          setInboxThreads(d.threads ?? [])
        })
        .catch(() => {})
    }
    poll()
    const id = setInterval(poll, 30_000)
    return () => clearInterval(id)
  }, [])

  // Ctrl+Z or Cmd+Shift+R — instant reset to portfolio during live demo
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const isReset =
        (e.ctrlKey && !e.metaKey && e.key === "z") ||
        ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === "R")
      if (isReset) {
        e.preventDefault()
        setStage(homeStage)
      }
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [])

  const isPortfolio = stage.kind === "portfolio" || stage.kind === "vendorPortfolio"

  // Register/deregister the Portfolio back-button in the nav bar
  useEffect(() => {
    if (isPortfolio) {
      onRegisterBack?.(null)
    } else {
      onRegisterBack?.(() => setStage(homeStage))
    }
    return () => onRegisterBack?.(null)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPortfolio])

  return (
    <>


      {/* Inbox drawer */}
      <AnimatePresence>
        {showInbox && (() => {
          const selectedThread = inboxThreads.find(t => t.phone === selectedThreadPhone) ?? null
          const leadMsgs = selectedThread?.messages.filter(m => m.role === "lead") ?? []
          const lastLeadMsg = leadMsgs[leadMsgs.length - 1]

          const handleDraftReply = async () => {
            if (!selectedThread || !lastLeadMsg) return
            setDraftingReply(true)
            setReplyDraft(null)
            try {
              const res = await fetch(apiUrl("/api/reply-agent"), {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  leadName:        selectedThread.leadName,
                  leadPhone:       selectedThread.phone,
                  propertyAddress: selectedThread.propertyAddress,
                  agentName:       agent.name,
                  agentAgency:     agent.agency,
                  thread:          selectedThread.messages,
                  latestReply:     lastLeadMsg.body,
                }),
              }).then(r => r.json())
              setReplyDraft(res)
              setReplyText(res.draft ?? "")
            } catch {
              const fallback = `Hi ${selectedThread.leadName.split(" ")[0]}, thanks for getting back to me. Happy to help - what would you like to know? ${agent.name.split(" ")[0]}`
              setReplyDraft({ draft: fallback, intent: "UNKNOWN", reasoning: "Network error - contingency framework used" })
              setReplyText(fallback)
            } finally {
              setDraftingReply(false)
            }
          }

          const handleSendReply = async () => {
            if (!selectedThread || !replyText.trim()) return
            setSendingReply(true)
            try {
              await fetch(apiUrl("/api/send"), {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  leadId:          selectedThread.leadId || selectedThread.phone,
                  leadName:        selectedThread.leadName,
                  phone:           selectedThread.phone,
                  email:           selectedThread.email,
                  agentEmail:      agent.email,
                  agentName:       agent.name,
                  agentAgency:     agent.agency,
                  agentPhone:      agent.phone,
                  agencyColor:     theme.primary,
                  agencyTagline:   agent.tagline,
                  propertyAddress: selectedThread.propertyAddress,
                  sms:             replyText,
                  subject:         "",
                  emailBody:       "",
                  channel:         "sms",
                }),
              })
              // Refresh threads after sending
              const updated = await fetch(apiUrl("/api/conversations")).then(r => r.json())
              setInboxThreads(updated.threads ?? [])
              setUnreadReplies(updated.unread ?? 0)
              setReplyDraft(null)
              setReplyText("")
            } finally {
              setSendingReply(false)
            }
          }

          const intentColors: Record<string, string> = {
            INTEREST: "#22c55e", QUESTION: "#3b82f6", OBJECTION: "#f59e0b",
            BOOKING: "#8b5cf6", OPT_OUT: "#ef4444", UNKNOWN: C.muted,
          }

          return (
            <motion.div
              key="inbox"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 24 }}
              style={{
                position: "fixed", top: 60, right: 16, zIndex: 199,
                width: 360, maxHeight: "78vh",
                display: "flex", flexDirection: "column",
                background: C.bg2, border: `1px solid ${C.border}`,
                borderRadius: 14, fontFamily: FONT,
                boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
              }}
            >
              {/* Header */}
              <div style={{ padding: "12px 14px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
                {selectedThread ? (
                  <button onClick={() => { setSelectedThreadPhone(null); setReplyDraft(null); setReplyText("") }}
                    style={{ background: "none", border: "none", color: theme.primary, cursor: "pointer", fontSize: 14, padding: "0 4px 0 0", fontFamily: FONT }}>
                    ←
                  </button>
                ) : null}
                <div style={{ flex: 1, fontSize: 13, fontWeight: 700, color: C.text }}>
                  {selectedThread ? selectedThread.leadName : "SMS Replies"}
                </div>
                {!selectedThread && (
                  <button
                    disabled={seedingDemo}
                    onClick={async () => {
                      setSeedingDemo(true)
                      try {
                        await fetch(apiUrl("/api/conversations/seed-demo"), { method: "POST" })
                        const updated = await fetch(apiUrl("/api/conversations")).then(r => r.json())
                        setInboxThreads(updated.threads ?? [])
                        setUnreadReplies(updated.unread ?? 0)
                      } finally { setSeedingDemo(false) }
                    }}
                    style={{
                      padding: "3px 9px", borderRadius: 6, fontSize: 10, fontWeight: 700,
                      background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)",
                      color: "#f59e0b", cursor: "pointer", fontFamily: FONT,
                    }}
                  >
                    {seedingDemo ? "…" : "Simulate reply"}
                  </button>
                )}
                <button onClick={() => { setShowInbox(false); setSelectedThreadPhone(null); setReplyDraft(null) }}
                  style={{ background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: 16, padding: 0 }}>×</button>
              </div>

              {/* Thread list */}
              {!selectedThread && (
                <div style={{ overflowY: "auto", flex: 1 }}>
                  {inboxThreads.length === 0 ? (
                    <div style={{ padding: "24px 16px", textAlign: "center", color: C.muted, fontSize: 12 }}>
                      No replies yet. Hit "Simulate reply" to demo the inbox flow.
                    </div>
                  ) : inboxThreads.map(t => {
                    const last = t.messages[t.messages.length - 1]
                    const isUnread = t.messages.some(m => m.role === "lead") &&
                      new Date(t.lastReplyAt) > new Date(Date.now() - 24 * 60 * 60 * 1000)
                    return (
                      <div key={t.phone}
                        onClick={() => { setSelectedThreadPhone(t.phone); setReplyDraft(null); setReplyText(""); fetch(apiUrl(`/api/conversations/${encodeURIComponent(t.phone)}/read`), { method: "POST" }) }}
                        style={{
                          padding: "12px 14px", borderBottom: `1px solid ${C.border}`,
                          background: isUnread ? "rgba(245,158,11,0.05)" : "transparent",
                          cursor: "pointer",
                        }}
                      >
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                          <div style={{ fontSize: 13, fontWeight: 700, color: isUnread ? "#f59e0b" : C.text, display: "flex", alignItems: "center", gap: 5 }}>
                            {isUnread && <span style={{ marginRight: 2 }}>●</span>}{t.leadName}
                            {t.leadId?.startsWith("vendor_") && (
                              <span style={{ fontSize: 9, color: theme.primary, fontWeight: 700, background: theme.dim, padding: "1px 5px", borderRadius: 4, letterSpacing: 0.3 }}>VENDOR</span>
                            )}
                          </div>
                          <div style={{ fontSize: 10, color: C.faint }}>
                            {new Date(t.lastReplyAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                        <div style={{ fontSize: 11, color: C.muted, marginBottom: 4, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {t.propertyAddress || t.phone}
                        </div>
                        {last && (
                          <div style={{ fontSize: 12, color: last.role === "lead" ? C.text : C.faint, fontStyle: last.role === "agent" ? "italic" : "normal" }}>
                            {last.role === "agent" ? "You: " : ""}{last.body.slice(0, 90)}{last.body.length > 90 ? "…" : ""}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}

              {/* Thread expand view */}
              {selectedThread && (
                <div style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0 }}>
                  {/* Property tag */}
                  <div style={{ padding: "6px 14px", borderBottom: `1px solid ${C.border}`, fontSize: 11, color: C.muted, flexShrink: 0 }}>
                    {selectedThread.propertyAddress}
                  </div>

                  {/* Message bubbles */}
                  <div style={{ overflowY: "auto", flex: 1, padding: "12px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
                    {selectedThread.messages.map((m, i) => (
                      <div key={i} style={{ display: "flex", justifyContent: m.role === "agent" ? "flex-end" : "flex-start" }}>
                        <div style={{
                          maxWidth: "80%", padding: "8px 11px",
                          borderRadius: m.role === "agent" ? "12px 12px 2px 12px" : "12px 12px 12px 2px",
                          background: m.role === "agent" ? theme.primary + "33" : C.bg3,
                          border: `1px solid ${m.role === "agent" ? theme.primary + "44" : C.border}`,
                          fontSize: 12, color: C.text, lineHeight: 1.5,
                        }}>
                          {m.body}
                          <div style={{ fontSize: 9, color: C.faint, marginTop: 3, textAlign: m.role === "agent" ? "right" : "left" }}>
                            {new Date(m.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* AI Reply section */}
                  <div style={{ borderTop: `1px solid ${C.border}`, padding: "12px 14px", flexShrink: 0 }}>
                    {!replyDraft ? (
                      <button
                        onClick={handleDraftReply}
                        disabled={draftingReply}
                        style={{
                          width: "100%", padding: "9px 0", borderRadius: 8, border: "none",
                          background: draftingReply ? C.bg3 : `linear-gradient(135deg, ${theme.gradient[0]}, ${theme.gradient[1]})`,
                          color: draftingReply ? C.muted : "white",
                          fontSize: 12, fontWeight: 700, fontFamily: FONT, cursor: draftingReply ? "default" : "pointer",
                        }}
                      >
                        {draftingReply ? "Drafting AI reply…" : "✦ Draft AI Reply"}
                      </button>
                    ) : (
                      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{
                            padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 700,
                            background: (intentColors[replyDraft.intent] ?? C.muted) + "22",
                            color: intentColors[replyDraft.intent] ?? C.muted,
                            border: `1px solid ${(intentColors[replyDraft.intent] ?? C.muted) + "44"}`,
                          }}>{replyDraft.intent}</span>
                          <span style={{ fontSize: 10, color: C.faint, flex: 1 }}>{replyDraft.reasoning}</span>
                          <button onClick={handleDraftReply} style={{ background: "none", border: "none", color: theme.primary, fontSize: 10, cursor: "pointer", fontFamily: FONT }}>Redraft</button>
                        </div>
                        <textarea
                          value={replyText}
                          onChange={e => setReplyText(e.target.value)}
                          rows={3}
                          style={{
                            width: "100%", background: C.bg3, border: `1px solid ${C.border}`,
                            borderRadius: 8, padding: "8px 10px", color: C.text, fontSize: 12,
                            fontFamily: FONT, lineHeight: 1.5, resize: "none", outline: "none",
                            boxSizing: "border-box",
                          }}
                        />
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <span style={{ fontSize: 10, color: replyText.length > 160 ? "#ef4444" : C.faint }}>{replyText.length}/160</span>
                          <button
                            onClick={handleSendReply}
                            disabled={sendingReply || !replyText.trim()}
                            style={{
                              padding: "7px 18px", borderRadius: 8, border: "none",
                              background: sendingReply || !replyText.trim() ? C.bg3 : theme.primary,
                              color: sendingReply || !replyText.trim() ? C.muted : "white",
                              fontSize: 12, fontWeight: 700, fontFamily: FONT,
                              cursor: sendingReply || !replyText.trim() ? "default" : "pointer",
                            }}
                          >
                            {sendingReply ? "Sending…" : "Send Reply"}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          )
        })()}
      </AnimatePresence>

    <AnimatePresence mode="wait">
      {stage.kind === "portfolio" && (
        <motion.div key="portfolio" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <PortfolioPage
            onSelectActive={(property, soldLeads) =>
              setStage({ kind: "matching", property, soldLeads })
            }
            onSelectSold={(soldProperty, leads) =>
              setStage({ kind: "soldLeads", soldProperty, leads })
            }
            onAuctionSaved={(property, leads) =>
              setStage({ kind: "missedOut", auctionProperty: property, leads })
            }
            onSettings={onSettings}
            agent={agent}
            theme={theme}
          />
        </motion.div>
      )}

      {/* ── Vendor Prospecting Stages ─────────────────────────────────────── */}
      {stage.kind === "vendorPortfolio" && (
        <motion.div key="vendorPortfolio" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <VendorPortfolioPage
            agent={agent}
            theme={theme}
            onAnalyse={segmented =>
              setStage({ kind: "vendorDashboard", segmented })
            }
          />
        </motion.div>
      )}

      {stage.kind === "vendorDashboard" && (
        <motion.div key="vendorDashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <VendorDashboardPage
            segmented={stage.segmented}
            onBack={() => setStage({ kind: "vendorPortfolio" })}
            theme={theme}
            agent={agent}
            onSelectEntry={entry =>
              setStage({ kind: "vendorProfile", entry })
            }
          />
        </motion.div>
      )}

      {stage.kind === "vendorProfile" && (
        <motion.div key="vendorProfile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <VendorProfilePage
            entry={stage.entry}
            agent={agent}
            theme={theme}
            onBack={() => {
              // Re-run segmentation to go back to dashboard
              const buyers = getPastBuyersForAgent(agent)
              const financialsMap = new Map<number, FinancialSnapshot>()
              for (const b of buyers) {
                const est = CURRENT_VALUE_ESTIMATES[b.id]
                if (!est) continue
                financialsMap.set(b.id, calculateFinancials(b.purchasePrice, b.purchaseDate, est, b.deposit))
              }
              setStage({ kind: "vendorDashboard", segmented: batchSegment(buyers, financialsMap) })
            }}
            onReview={(sms, emailSubject, emailBody) =>
              setStage({ kind: "vendorReview", entry: stage.entry, sms, emailSubject, emailBody })
            }
          />
        </motion.div>
      )}

      {stage.kind === "vendorReview" && (
        <motion.div key="vendorReview" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <VendorReviewPanel
            entry={stage.entry}
            agent={agent}
            theme={theme}
            sms={stage.sms}
            emailSubject={stage.emailSubject}
            emailBody={stage.emailBody}
            onBack={() => setStage({ kind: "vendorProfile", entry: stage.entry })}
          />
        </motion.div>
      )}

      {stage.kind === "soldLeads" && (
        <motion.div key="soldLeads" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <SoldLeadsPage
            soldProperty={stage.soldProperty}
            leads={stage.leads}
            onBack={() => setStage({ kind: "portfolio" })}
            onSelectLead={(scoredLead, property) =>
              setStage({
                kind: "profile",
                property,
                lead: scoredLead,
                soldSLM: loadSLMForProperty(stage.soldProperty.id),
                allLeads: [scoredLead],
              })
            }
            theme={theme}
          />
        </motion.div>
      )}

      {stage.kind === "matching" && (
        <motion.div key="matching" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <MatchingScreen
            property={stage.property}
            soldLeads={stage.soldLeads}
            theme={theme}
            onComplete={allLeads =>
              setStage({ kind: "leads", property: stage.property, allLeads })
            }
          />
        </motion.div>
      )}

      {stage.kind === "leads" && (
        <motion.div key="leads" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <LeadsPage
            property={stage.property}
            allLeads={stage.allLeads}
            onBack={() => setStage({ kind: "portfolio" })}
            onSelect={lead =>
              setStage({
                kind: "profile",
                property: stage.property,
                lead,
                soldSLM: loadSLMForProperty(lead.fromPropertyId),
                allLeads: stage.allLeads,
              })
            }
            theme={theme}
          />
        </motion.div>
      )}

      {stage.kind === "profile" && (
        <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <ProfilePage
            property={stage.property}
            lead={stage.lead}
            soldSLM={stage.soldSLM}
            onBack={() =>
              setStage({
                kind: "leads",
                property: stage.property,
                allLeads: stage.allLeads,
              })
            }
            onGenerate={transcript => {
              // Log voice note to Sheets immediately when agent taps Generate
              if (transcript.trim()) {
                postEvent({
                  leadId: stage.lead.id, leadName: stage.lead.name,
                  propertyAddress: stage.property.address + ", " + stage.property.suburb,
                  fromProperty: stage.soldSLM.address,
                  eventType: "voice_note",
                  transcript,
                })
              }
              setStage({
                kind: "generating",
                property: stage.property,
                lead: stage.lead,
                soldSLM: stage.soldSLM,
                transcript,
                allLeads: stage.allLeads,
              })
            }}
            theme={theme}
          />
        </motion.div>
      )}

      {stage.kind === "generating" && (
        <motion.div key="generating" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <GeneratingScreen
            property={stage.property}
            lead={stage.lead}
            soldSLM={stage.soldSLM}
            transcript={stage.transcript}
            agent={agent}
            theme={theme}
            onComplete={(sms, emailSubject, emailBody) =>
              setStage({
                kind: "review",
                property: stage.property,
                lead: stage.lead,
                soldSLM: stage.soldSLM,
                transcript: stage.transcript,
                sms,
                emailSubject,
                emailBody,
                allLeads: stage.allLeads,
              })
            }
          />
        </motion.div>
      )}

      {stage.kind === "review" && (
        <motion.div key="review" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <ReviewPanel
            property={stage.property}
            lead={stage.lead}
            soldSLM={stage.soldSLM}
            agent={agent}
            theme={theme}
            transcript={stage.transcript}
            sms={stage.sms}
            emailSubject={stage.emailSubject}
            emailBody={stage.emailBody}
            onBack={() => setStage({ kind: "leads", property: stage.property, allLeads: stage.allLeads })}
          />
        </motion.div>
      )}
      {stage.kind === "missedOut" && (
        <motion.div key="missedOut" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0 }}>
          <MissedOutPage
            auctionProperty={stage.auctionProperty}
            leads={stage.leads}
            onBack={() => setStage({ kind: "portfolio" })}
            theme={theme}
            onSelectLead={(lead, property) =>
              setStage({
                kind: "profile",
                property,
                lead,
                soldSLM: loadSLMForProperty(stage.auctionProperty.id),
                allLeads: [lead],
              })
            }
          />
        </motion.div>
      )}
    </AnimatePresence>
    </>
  )
}
